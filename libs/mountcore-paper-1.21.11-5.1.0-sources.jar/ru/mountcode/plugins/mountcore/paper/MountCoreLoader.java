package ru.mountcode.plugins.mountcore.paper;

import io.papermc.paper.plugin.loader.PluginClasspathBuilder;
import io.papermc.paper.plugin.loader.PluginLoader;
import io.papermc.paper.plugin.loader.library.impl.MavenLibraryResolver;
import org.eclipse.aether.artifact.DefaultArtifact;
import org.eclipse.aether.graph.Dependency;
import org.eclipse.aether.repository.RemoteRepository;

public class MountCoreLoader implements PluginLoader {

    @Override
    public void classloader(PluginClasspathBuilder builder) {
        MavenLibraryResolver resolver = new MavenLibraryResolver();
        resolver.addDependency(new Dependency(new DefaultArtifact("org.jspecify", "jspecify", "jar", "1.0.0"), null));

        resolver.addDependency(new Dependency(new DefaultArtifact("com.zaxxer", "HikariCP", "jar", "7.0.2"), null));
        resolver.addDependency(new Dependency(new DefaultArtifact("org.liquibase", "liquibase-core", "jar", "5.0.1"), null));
        resolver.addDependency(new Dependency(new DefaultArtifact("org.jooq", "jooq", "jar", "3.20.11"), null));
        resolver.addDependency(new Dependency(new DefaultArtifact("org.jooq", "jooq-jpa-extensions", "jar", "3.20.11"), null));

        resolver.addDependency(new Dependency(new DefaultArtifact("com.h2database", "h2", "jar", "2.4.240"), null));
        resolver.addDependency(new Dependency(new DefaultArtifact("com.mysql", "mysql-connector-j", "jar", "9.4.0"), null));
        resolver.addDependency(new Dependency(new DefaultArtifact("org.postgresql", "postgresql", "jar", "42.7.8"), null));
        resolver.addDependency(new Dependency(new DefaultArtifact("org.mariadb.jdbc", "mariadb-java-client", "jar", "3.5.6"), null));
        resolver.addDependency(new Dependency(new DefaultArtifact("com.clickhouse", "clickhouse-jdbc", "jar", "0.9.6"), null));

        resolver.addDependency(new Dependency(new DefaultArtifact("org.snakeyaml", "snakeyaml-engine", "jar", "2.10"), null));

        resolver.addDependency(new Dependency(new DefaultArtifact("jakarta.persistence", "jakarta.persistence-api", "jar", "3.2.0"), null));

        resolver.addRepository(new RemoteRepository.Builder("central", "default", MavenLibraryResolver.MAVEN_CENTRAL_DEFAULT_MIRROR).build());

        builder.addLibrary(resolver);
    }
}

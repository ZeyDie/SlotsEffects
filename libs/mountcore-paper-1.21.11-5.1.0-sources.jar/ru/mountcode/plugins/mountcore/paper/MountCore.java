package ru.mountcode.plugins.mountcore.paper;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.jspecify.annotations.NonNull;
import ru.mountcode.plugins.mountcore.api.bootstrap.v1.PluginSettings;
import ru.mountcode.plugins.mountcore.paper.api.bootstrap.v1.MountPlugin;
import ru.mountcode.plugins.mountcore.paper.commands.CommandMountCore;

import java.nio.file.Path;

public class MountCore extends MountPlugin {

    @Override
    public void construct() {
        Bukkit.getConsoleSender().sendMessage(Component.text(" __   __                       _      ____").color(NamedTextColor.DARK_GREEN));
        Bukkit.getConsoleSender().sendMessage(Component.text("|  \\/  |  ___   _   _  _ __  | |_   / ___| ___   _ __  ___").color(NamedTextColor.DARK_GREEN));
        Bukkit.getConsoleSender().sendMessage(Component.text("| |\\/| | / _ \\ | | | || '_ \\ | __| | |    / _ \\ | '__|/ _ \\").color(NamedTextColor.DARK_GREEN));
        Bukkit.getConsoleSender().sendMessage(Component.text("| |  | || (_) || |_| || | | || |_  | |___| (_) || |  |  __/").color(NamedTextColor.DARK_GREEN));
        Bukkit.getConsoleSender().sendMessage(Component.text("|_|  |_| \\___/  \\__,_||_| |_| \\__|  \\____|\\___/ |_|   \\___|").color(NamedTextColor.DARK_GREEN));
        Bukkit.getConsoleSender().sendMessage(Component.text("Version: " + this.getPluginMetadata().version() + ", Author: EarWarm").color(NamedTextColor.DARK_GREEN));
        this.getModuleManager().registerTranslationModule();
    }

    @Override
    public void enable() {
        this.getCommandRegistrar().register(new CommandMountCore(this));
        Bukkit.getConsoleSender().sendMessage(Component.translatable("mountcore.enabled"));
    }

    @Override
    public void shutdown() {
        Bukkit.getConsoleSender().sendMessage(Component.translatable("mountcore.disabled"));
    }

    @Override
    public void reload() {

    }

    @Override
    public PluginSettings.PluginSettingsBuilder configurePluginSettings(PluginSettings.@NonNull PluginSettingsBuilder builder) {
        builder.stateLogging(false);
        builder.directory(Path.of("MountCore"));
        return builder;
    }
}

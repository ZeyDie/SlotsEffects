package ru.mountcode.plugins.mountcore.paper.commands;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import com.mojang.brigadier.tree.LiteralCommandNode;
import io.papermc.paper.command.brigadier.CommandSourceStack;
import io.papermc.paper.command.brigadier.Commands;
import io.papermc.paper.command.brigadier.MessageComponentSerializer;
import io.papermc.paper.plugin.configuration.PluginMeta;
import net.kyori.adventure.text.Component;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginLoadOrder;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;
import ru.mountcode.plugins.mountcore.api.bootstrap.v1.module.PluginModule;
import ru.mountcode.plugins.mountcore.api.command.v1.suggestion.DefaultSuggestionProvider;
import ru.mountcode.plugins.mountcore.paper.MountCore;
import ru.mountcode.plugins.mountcore.paper.api.bootstrap.v1.MountPlugin;
import ru.mountcode.plugins.mountcore.paper.api.command.v1.PaperBrigadierCommand;
import ru.mountcode.plugins.mountcore.paper.commands.arguments.MountPluginArgumentType;
import ru.mountcode.plugins.mountcore.paper.commands.arguments.PluginArgumentType;

import java.util.Collection;
import java.util.Optional;

public record CommandMountCore(MountCore plugin) implements PaperBrigadierCommand {

    private static final SimpleCommandExceptionType MODULE_NOT_FOUND =
            new SimpleCommandExceptionType(MessageComponentSerializer.message().serialize(
                    Component.translatable("mountcore.command.arguments.pluginmodule.not.found")
            ));

    private static final SimpleCommandExceptionType MODULE_NOT_RELOADABLE =
            new SimpleCommandExceptionType(MessageComponentSerializer.message().serialize(
                    Component.translatable("mountcore.command.arguments.pluginmodule.not.reloadable")
            ));


    @Override
    public @NonNull LiteralCommandNode<CommandSourceStack> construct(LiteralArgumentBuilder<CommandSourceStack> command) {
        return command
                .requires(source -> source.getSender().hasPermission("mountcore.commands.mountcore"))
                .then(Commands.literal("reload")
                        .requires(source -> source.getSender().hasPermission("mountcore.commands.mountcore.reload"))
                        .executes(context -> onPluginReload(
                                        context,
                                        this.plugin()
                                )
                        )
                        .then(Commands.argument("plugin", MountPluginArgumentType.mountPlugin(true))
                                .executes(context -> onPluginReload(
                                                context,
                                                MountPluginArgumentType.getMountPlugin(context, "plugin")
                                        )
                                )
                                .then(Commands.argument("module", StringArgumentType.string())
                                        .suggests((context, builder) -> {
                                            MountPlugin plugin = MountPluginArgumentType.getMountPlugin(context, "plugin");

                                            return DefaultSuggestionProvider.suggest(
                                                    plugin.getModuleManager().getReloadableModules(),
                                                    builder
                                            );
                                        })
                                        .executes(context -> onPluginModuleReload(
                                                        context,
                                                        MountPluginArgumentType.getMountPlugin(context, "plugin"),
                                                        StringArgumentType.getString(context, "module")
                                                )
                                        )
                                )
                        )
                )
                .then(Commands.literal("info")
                        .requires(source -> source.getSender().hasPermission("mountcore.commands.mountcore.info"))
                        .executes(context -> onPluginInfo(
                                        context,
                                        this.plugin()
                                )
                        )
                        .then(Commands.argument("plugin", PluginArgumentType.plugin())
                                .executes(context -> onPluginInfo(
                                                context,
                                                PluginArgumentType.getPlugin(context, "plugin")
                                        )
                                )
                        )
                )
                .build();
    }

    private int onPluginInfo(@NonNull CommandContext<CommandSourceStack> context, @NonNull Plugin plugin) {
        CommandSender sender = context.getSource().getSender();

        PluginMeta pluginMeta = plugin.getPluginMeta();

        Component modulesComponent = null;
        Component modulesCount = null;
        if (plugin instanceof MountPlugin mountPlugin) {
            Collection<PluginModule> modules = mountPlugin.getModuleManager().getModules();
            modulesCount = Component.text(modules.size());
            for (PluginModule pluginModule : modules) {
                if (modulesComponent == null) {
                    modulesComponent = Component.translatable(
                            "mountcore.commands.mountcore.info.module",
                            Component.text(pluginModule.getName()),
                            pluginModule.isReloadable() ? Component.translatable("mountcore.yes") : Component.translatable("mountcore.no"),
                            pluginModule.getDependencies().length != 0
                                    ? Component.text(String.join(", ", pluginModule.getDependencies()))
                                    : Component.translatable("mountcore.missing.few")
                    );
                    continue;
                }

                modulesComponent = modulesComponent.appendNewline().append(Component.translatable(
                                "mountcore.commands.mountcore.info.module",
                                Component.text(pluginModule.getName()),
                                pluginModule.isReloadable() ? Component.translatable("mountcore.yes") : Component.translatable("mountcore.no"),
                                pluginModule.getDependencies().length != 0
                                        ? Component.text(String.join(", ", pluginModule.getDependencies()))
                                        : Component.translatable("mountcore.missing.few")
                        )
                );
            }
        } else {
            modulesComponent = Component.empty();
            modulesCount = Component.translatable("mountcore.not.supported.few");
        }

        pluginMeta.getAuthors();
        sender.sendMessage(Component.translatable(
                "mountcore.commands.mountcore.info",
                Component.text(pluginMeta.getName()),
                Component.text(pluginMeta.getVersion()),
                pluginMeta.getWebsite() != null
                        ? Component.text(pluginMeta.getWebsite())
                        : Component.translatable("mountcore.not.specified"),
                !pluginMeta.getAuthors().isEmpty()
                        ? Component.text(String.join(", ", pluginMeta.getAuthors()))
                        : Component.translatable("mountcore.not.specified"),
                !pluginMeta.getContributors().isEmpty()
                        ? Component.text(String.join(", ", pluginMeta.getContributors()))
                        : Component.translatable("mountcore.not.specified"),
                pluginMeta.getDescription() != null && !pluginMeta.getDescription().isBlank()
                        ? Component.text(pluginMeta.getDescription())
                        : Component.translatable("mountcore.missing.one"),
                pluginMeta.getAPIVersion() != null
                        ? Component.text(pluginMeta.getAPIVersion())
                        : Component.translatable("mountcore.not.specified"),
                pluginMeta.getLoadOrder() == PluginLoadOrder.STARTUP
                        ? Component.translatable("mountcore.commands.mountcore.info.load.startup")
                        : Component.translatable("mountcore.commands.mountcore.info.load.postworld"),
                modulesCount,
                modulesComponent != null
                        ? modulesComponent
                        : Component.translatable("mountcore.missing.few"),
                plugin.isEnabled()
                        ? Component.translatable("mountcore.commands.mountcore.info.status.enabled")
                        : Component.translatable("mountcore.commands.mountcore.info.status.disabled")
        ));

        return Command.SINGLE_SUCCESS;
    }

    private int onPluginModuleReload(@NonNull CommandContext<CommandSourceStack> context, @NonNull MountPlugin plugin, @NonNull String module) throws CommandSyntaxException {
        CommandSender sender = context.getSource().getSender();

        Optional<PluginModule> optionalPluginModule = plugin.getModuleManager().getModule(module);
        if (optionalPluginModule.isEmpty()) {
            throw MODULE_NOT_FOUND.create();
        }

        if (!optionalPluginModule.get().isReloadable()) {
            throw MODULE_NOT_RELOADABLE.create();
        }

        sender.sendMessage(Component.translatable(
                        "mountcore.plugin.module.reloading",
                        Component.text(plugin.getPluginMetadata().name()),
                        Component.text(module)
                )
        );
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            throw new IllegalStateException(e);
        }
        try {
            if (!plugin.getModuleManager().reloadModule(module)) {
                sender.sendMessage(Component.translatable(
                                "mountcore.plugin.module.reloaded.fail",
                                Component.text(plugin.getPluginMetadata().name()),
                                Component.text(module)
                        )
                );
            }
            sender.sendMessage(Component.translatable(
                            "mountcore.plugin.module.reloaded.success",
                            Component.text(plugin.getPluginMetadata().name()),
                            Component.text(module)
                    )
            );
        } catch (Exception e) {
            this.plugin().logger().error("Error on reloading module {} in plugin {}", module, plugin.getPluginMetadata().displayName(), e);
            sender.sendMessage(Component.translatable(
                            "mountcore.plugin.module.reloaded.fail",
                            Component.text(plugin.getPluginMetadata().name()),
                            Component.text(module)
                    )
            );
        }

        return Command.SINGLE_SUCCESS;
    }

    private int onPluginReload(@NonNull CommandContext<CommandSourceStack> context, @NonNull MountPlugin plugin) {
        CommandSender sender = context.getSource().getSender();

        sender.sendMessage(Component.translatable("mountcore.plugin.reloading", Component.text(plugin.getPluginMetadata().displayName())));
        try {
            plugin.onReload();
            sender.sendMessage(Component.translatable("mountcore.plugin.reloaded.success", Component.text(plugin.getPluginMetadata().displayName())));
        } catch (Exception e) {
            this.plugin().logger().error("Error on reloading plugin {}", plugin.getPluginMetadata().displayName(), e);
            sender.sendMessage(Component.translatable("mountcore.plugin.reloaded.fail", Component.text(plugin.getPluginMetadata().displayName())));
        }

        return Command.SINGLE_SUCCESS;
    }

    @Override
    public @NonNull String getName() {
        return "mountcore";
    }

    @Override
    public @Nullable String getDescription() {
        return "Command for managing MountCore and plugins";
    }
}

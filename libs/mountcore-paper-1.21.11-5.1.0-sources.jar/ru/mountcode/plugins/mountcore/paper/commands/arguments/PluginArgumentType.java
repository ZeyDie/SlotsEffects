package ru.mountcode.plugins.mountcore.paper.commands.arguments;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import io.papermc.paper.command.brigadier.MessageComponentSerializer;
import io.papermc.paper.command.brigadier.argument.CustomArgumentType;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;
import org.jspecify.annotations.NonNull;
import ru.mountcode.plugins.mountcore.api.command.v1.suggestion.DefaultSuggestionProvider;
import ru.mountcode.plugins.mountcore.paper.api.bootstrap.v1.MountPlugin;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public record PluginArgumentType(boolean requireEnabled) implements CustomArgumentType<Plugin, String> {

    private static final SimpleCommandExceptionType NOT_FOUND =
            new SimpleCommandExceptionType(MessageComponentSerializer.message().serialize(
                    Component.translatable("mountcore.command.arguments.mountplugin.not.found")
            ));
    private static final SimpleCommandExceptionType NOT_ENABLED =
            new SimpleCommandExceptionType(MessageComponentSerializer.message().serialize(
                    Component.translatable("mountcore.command.arguments.mountplugin.not.enabled")
            ));

    public static @NonNull PluginArgumentType plugin() {
        return plugin(false);
    }

    public static @NonNull PluginArgumentType plugin(boolean requireEnabled) {
        return new PluginArgumentType(requireEnabled);
    }

    public static @NonNull Plugin getPlugin(@NonNull CommandContext<?> context, @NonNull String name) {
        return context.getArgument(name, Plugin.class);
    }

    @Override
    public @NonNull Plugin parse(@NonNull StringReader reader) throws CommandSyntaxException {
        String pluginName = reader.readString();
        if (pluginName == null) {
            throw NOT_FOUND.create();
        }

        Plugin plugin = Bukkit.getPluginManager().getPlugin(pluginName);
        if (plugin == null) {
            throw NOT_FOUND.create();
        }

        if (this.requireEnabled && !plugin.isEnabled()) {
            throw NOT_ENABLED.create();
        }

        return plugin;
    }

    @Override
    public @NonNull ArgumentType<String> getNativeType() {
        return StringArgumentType.word();
    }

    @Override
    public <S> @NonNull CompletableFuture<Suggestions> listSuggestions(@NonNull CommandContext<S> context, @NonNull SuggestionsBuilder builder) {
        List<String> plugins = new ArrayList<>();

        for (Plugin plugin : Bukkit.getPluginManager().getPlugins()) {
            if (this.requireEnabled && !plugin.isEnabled()) {
                continue;
            }

            plugins.add(plugin.getPluginMeta().getName());
        }

        return DefaultSuggestionProvider.suggest(plugins, builder);
    }
}

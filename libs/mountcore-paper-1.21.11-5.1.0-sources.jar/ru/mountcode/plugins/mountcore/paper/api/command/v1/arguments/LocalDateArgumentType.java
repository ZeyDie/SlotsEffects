package ru.mountcode.plugins.mountcore.paper.api.command.v1.arguments;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.Dynamic2CommandExceptionType;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import io.papermc.paper.command.brigadier.MessageComponentSerializer;
import io.papermc.paper.command.brigadier.argument.CustomArgumentType;
import net.kyori.adventure.text.Component;
import org.jspecify.annotations.NonNull;
import ru.mountcode.plugins.mountcore.api.time.v1.DateTimeParser;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.concurrent.CompletableFuture;

public class LocalDateArgumentType implements CustomArgumentType<@NonNull LocalDate, @NonNull String> {

    private static final SimpleCommandExceptionType INVALID_DATE =
            new SimpleCommandExceptionType(MessageComponentSerializer.message().serialize(
                    Component.translatable("mountcore.command.arguments.date.invalid")
            ));

    private static final Dynamic2CommandExceptionType OUT_OF_RANGE =
            new Dynamic2CommandExceptionType((min, max) -> MessageComponentSerializer.message().serialize(
                    Component.translatable("mountcore.command.arguments.date.range", Component.text((String) min), Component.text((String) max))
            ));

    private final LocalDate minDate;
    private final LocalDate maxDate;

    public LocalDateArgumentType(LocalDate minDate, LocalDate maxDate) {
        this.minDate = minDate;
        this.maxDate = maxDate;
    }

    @Override
    public @NonNull LocalDate parse(@NonNull StringReader reader) throws CommandSyntaxException {
        final int start = reader.getCursor();
        while (reader.canRead()) {
            reader.skip();
        }
        String input = reader.getString().substring(start, reader.getCursor());

        LocalDate date;
        try {
            date = DateTimeParser.parseDate(input);
        } catch (DateTimeParseException e) {
            throw INVALID_DATE.createWithContext(reader);
        }

        if (minDate != null && date.isAfter(minDate)) {
            throw OUT_OF_RANGE.create(minDate, maxDate != null ? maxDate : "∞");
        }

        if (maxDate != null && date.isBefore(maxDate)) {
            throw OUT_OF_RANGE.create(minDate != null ? minDate : "-∞", maxDate);
        }

        return date;
    }

    @Override
    public @NonNull ArgumentType<@NonNull String> getNativeType() {
        return StringArgumentType.word();
    }

    @Override
    public <S> @NonNull CompletableFuture<Suggestions> listSuggestions(@NonNull CommandContext<S> context, @NonNull SuggestionsBuilder builder) {
        builder.suggest(LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy")));
        builder.suggest(LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd.MM.yyyy")));
        builder.suggest(LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
        return builder.buildFuture();
    }
}

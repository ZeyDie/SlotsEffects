package ru.mountcode.plugins.mountcore.paper.api.command.v1;

import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.context.CommandContext;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import net.kyori.adventure.text.Component;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;
import ru.mountcode.plugins.mountcore.paper.api.command.v1.arguments.DurationArgumentType;
import ru.mountcode.plugins.mountcore.paper.api.command.v1.arguments.LocalDateArgumentType;
import ru.mountcode.plugins.mountcore.paper.api.command.v1.arguments.LocalDateTimeArgumentType;
import ru.mountcode.plugins.mountcore.paper.api.command.v1.arguments.MiniMessageArgumentType;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * A utility class that provides factory and helper methods for creating and retrieving
 * custom Brigadier {@link ArgumentType} instances used within MountCore commands.
 * <p>
 * This class includes argument types for parsing {@link Duration} values and
 * {@link Component} messages using the MiniMessage format.
 * <p>
 * It simplifies command registration and argument retrieval by exposing reusable,
 * type-safe static methods compatible with the Brigadier command system.
 *
 * <p><b>Example usage:</b>
 * <pre>{@code
 * // Registering a command argument for a duration
 * LiteralArgumentBuilder<CommandSource> builder = Commands.literal("setCooldown")
 *     .then(Commands.argument("time", MountArgumentTypes.duration())
 *         .executes(context -> {
 *             Duration time = MountArgumentTypes.getDuration(context, "time");
 *             // Use the duration...
 *             return 1;
 *         }));
 * }</pre>
 *
 * @since 5.0.8
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class MountArgumentTypes {

    /**
     * Creates a {@link DurationArgumentType} that allows parsing any duration value.
     * The duration argument accepts various time formats supported by {@link DurationArgumentType}.
     * <p>
     * Example input values: {@code 10s}, {@code 5m}, {@code 2h 30m}.
     *
     * @return a new {@link ArgumentType} for parsing {@link Duration} values.
     * @since 5.0.8
     */
    public static @NonNull ArgumentType<Duration> duration() {
        return new DurationArgumentType();
    }

    /**
     * Creates a {@link DurationArgumentType} with specified minimum and maximum duration limits.
     * <p>
     * The provided constraints allow validating the user input during command execution.
     * Both parameters can be {@code null} if no bound is required.
     *
     * <p>Example usage:
     * <pre>{@code
     * argument("cooldown", MountArgumentTypes.duration(Duration.ofSeconds(10), Duration.ofHours(1)))
     * }</pre>
     *
     * @param minDuration the minimum allowed {@link Duration}, or {@code null} if unbounded
     * @param maxDuration the maximum allowed {@link Duration}, or {@code null} if unbounded
     * @return a new {@link ArgumentType} for bounded duration values.
     * @since 5.0.8
     */
    public static @NonNull ArgumentType<Duration> duration(@Nullable Duration minDuration, @Nullable Duration maxDuration) {
        return new DurationArgumentType(minDuration, maxDuration);
    }

    /**
     * Creates a {@link MiniMessageArgumentType} for parsing {@link Component} text using MiniMessage syntax.
     * <p>
     * This argument type allows passing formatted chat messages directly in commands.
     *
     * <p>Example usage:
     * <pre>{@code
     * argument("message", MountArgumentTypes.miniMessage())
     * }</pre>
     *
     * @return a new {@link ArgumentType} for parsing {@link Component} values.
     * @since 5.0.8
     */
    public static @NonNull ArgumentType<Component> miniMessage() {
        return new MiniMessageArgumentType();
    }

    /**
     * Creates an argument type that accepts any {@link LocalDate} value.
     *
     * @return argument type for any date
     * @since 5.0.9
     */
    public static @NonNull ArgumentType<LocalDate> date() {
        return new LocalDateArgumentType(null, null);
    }

    /**
     * Creates an argument type that accepts {@link LocalDate} values before the specified date.
     *
     * @param date the maximum allowed date
     * @return argument type for dates before the specified date
     * @since 5.0.9
     */
    public static @NonNull ArgumentType<LocalDate> dateBefore(LocalDate date) {
        return new LocalDateArgumentType(null, date);
    }

    /**
     * Creates an argument type that accepts {@link LocalDate} values after the specified date.
     *
     * @param date the minimum allowed date
     * @return argument type for dates after the specified date
     * @since 5.0.9
     */
    public static @NonNull ArgumentType<LocalDate> dateAfter(LocalDate date) {
        return new LocalDateArgumentType(date, null);
    }

    /**
     * Creates an argument type that accepts {@link LocalDate} values between the specified range.
     *
     * @param minDate the minimum allowed date
     * @param maxDate the maximum allowed date
     * @return argument type for dates within the given range
     * @since 5.0.9
     */
    public static @NonNull ArgumentType<LocalDate> dateBetween(LocalDate minDate, LocalDate maxDate) {
        return new LocalDateArgumentType(minDate, maxDate);
    }

    /**
     * Creates an argument type that accepts any {@link LocalDateTime} value.
     *
     * @return argument type for any date-time
     * @since 5.0.9
     */
    public static @NonNull ArgumentType<LocalDateTime> dateTime() {
        return new LocalDateTimeArgumentType(null, null);
    }

    /**
     * Creates an argument type that accepts {@link LocalDateTime} values before the specified date-time.
     *
     * @param date the maximum allowed date-time
     * @return argument type for date-times before the specified value
     * @since 5.0.9
     */
    public static @NonNull ArgumentType<LocalDateTime> dateTimeBefore(LocalDateTime date) {
        return new LocalDateTimeArgumentType(null, date);
    }

    /**
     * Creates an argument type that accepts {@link LocalDateTime} values after the specified date-time.
     *
     * @param date the minimum allowed date-time
     * @return argument type for date-times after the specified value
     * @since 5.0.9
     */
    public static @NonNull ArgumentType<LocalDateTime> dateTimeAfter(LocalDateTime date) {
        return new LocalDateTimeArgumentType(date, null);
    }

    /**
     * Creates an argument type that accepts {@link LocalDateTime} values within the specified range.
     *
     * @param minDate the minimum allowed date-time
     * @param maxDate the maximum allowed date-time
     * @return argument type for date-times within the given range
     * @since 5.0.9
     */
    public static @NonNull ArgumentType<LocalDateTime> dateTimeBetween(LocalDateTime minDate, LocalDateTime maxDate) {
        return new LocalDateTimeArgumentType(minDate, maxDate);
    }


    /**
     * Retrieves a parsed {@link Duration} argument from the given {@link CommandContext}.
     * <p>
     * This method should be used after command execution to access user-provided
     * duration values in Brigadier commands.
     *
     * <p>Example usage:
     * <pre>{@code
     * Duration duration = MountArgumentTypes.getDuration(context, "duration");
     * }</pre>
     *
     * @param context the command context containing parsed arguments
     * @param name    the argument name as defined in the command
     * @return the parsed {@link Duration} value
     * @since 5.0.8
     */
    public static @NonNull Duration getDuration(@NonNull CommandContext<?> context, @NonNull String name) {
        return context.getArgument(name, Duration.class);
    }

    /**
     * Retrieves a parsed {@link Component} argument from the given {@link CommandContext}.
     * <p>
     * This method should be used after command execution to access MiniMessage-formatted
     * components provided by the user.
     *
     * <p>Example usage:
     * <pre>{@code
     * Component message = MountArgumentTypes.getMiniMessage(context, "message");
     * }</pre>
     *
     * @param context the command context containing parsed arguments
     * @param name    the argument name as defined in the command
     * @return the parsed {@link Component} value
     * @since 5.0.8
     */
    public static @NonNull Component getMiniMessage(@NonNull CommandContext<?> context, @NonNull String name) {
        return context.getArgument(name, Component.class);
    }

    /**
     * Retrieves a parsed {@link LocalDate} argument from the command context.
     *
     * @param context the command context containing the parsed arguments
     * @param name the name of the argument to retrieve
     * @return the parsed {@link LocalDate} value
     * @since 5.0.9
     */
    public static @NonNull LocalDate getDate(@NonNull CommandContext<?> context, @NonNull String name) {
        return context.getArgument(name, LocalDate.class);
    }

    /**
     * Retrieves a parsed {@link LocalDateTime} argument from the command context.
     *
     * @param context the command context containing the parsed arguments
     * @param name the name of the argument to retrieve
     * @return the parsed {@link LocalDateTime} value
     * @since 5.0.9
     */
    public static @NonNull LocalDateTime getDateTime(@NonNull CommandContext<?> context, @NonNull String name) {
        return context.getArgument(name, LocalDateTime.class);
    }
}

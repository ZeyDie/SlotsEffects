package ru.mountcode.plugins.mountcore.paper.api.inventory.v1;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.bukkit.inventory.ItemStack;
import org.jspecify.annotations.Nullable;

/**
 * Utility class that provides helper methods for working with {@link ItemStack} objects.
 * <p>
 * This class is not meant to be instantiated.
 * </p>
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class ItemStackHelper {

    /**
     * Checks whether the given {@link ItemStack} is {@code null} or empty.
     *
     * @param itemStack the {@link ItemStack} to check; may be {@code null}
     * @return {@code true} if the given {@link ItemStack} is {@code null} or {@link ItemStack#isEmpty()},
     *         {@code false} otherwise
     */
    public static boolean isNullable(@Nullable ItemStack itemStack) {
        return itemStack == null || itemStack.isEmpty();
    }
}

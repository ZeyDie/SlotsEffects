package ru.mountcode.plugins.mountcore.paper.api.command.v1.arguments;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.Dynamic2CommandExceptionType;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import io.papermc.paper.command.brigadier.MessageComponentSerializer;
import io.papermc.paper.command.brigadier.argument.CustomArgumentType;
import net.kyori.adventure.text.Component;
import org.jspecify.annotations.NonNull;
import ru.mountcode.plugins.mountcore.api.time.v1.DateTimeParser;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.concurrent.CompletableFuture;

public class LocalDateTimeArgumentType implements CustomArgumentType<@NonNull LocalDateTime, @NonNull String> {

    private static final SimpleCommandExceptionType INVALID_DATE_TIME =
            new SimpleCommandExceptionType(MessageComponentSerializer.message().serialize(
                    Component.translatable("mountcore.command.arguments.date-time.invalid")
            ));

    private static final Dynamic2CommandExceptionType OUT_OF_RANGE =
            new Dynamic2CommandExceptionType((min, max) -> MessageComponentSerializer.message().serialize(
                    Component.translatable("mountcore.command.arguments.date-time.range", Component.text((String) min), Component.text((String) max))
            ));

    private final LocalDateTime minDateTime;
    private final LocalDateTime maxDateTime;

    public LocalDateTimeArgumentType(LocalDateTime minDateTime, LocalDateTime maxDateTime) {
        this.minDateTime = minDateTime;
        this.maxDateTime = maxDateTime;
    }

    @Override
    public @NonNull LocalDateTime parse(@NonNull StringReader reader) throws CommandSyntaxException {
        final int start = reader.getCursor();
        while (reader.canRead()) {
            reader.skip();
        }
        String input = reader.getString().substring(start, reader.getCursor());

        LocalDateTime dateTime;
        try {
            dateTime = DateTimeParser.parseDateTime(input);
        } catch (DateTimeParseException e) {
            throw INVALID_DATE_TIME.createWithContext(reader);
        }

        if (minDateTime != null && dateTime.isAfter(minDateTime)) {
            throw OUT_OF_RANGE.create(minDateTime, maxDateTime != null ? maxDateTime : "∞");
        }

        if (maxDateTime != null && dateTime.isBefore(maxDateTime)) {
            throw OUT_OF_RANGE.create(minDateTime != null ? minDateTime : "-∞", maxDateTime);
        }

        return dateTime;
    }

    @Override
    public @NonNull ArgumentType<@NonNull String> getNativeType() {
        return StringArgumentType.greedyString();
    }

    @Override
    public <S> @NonNull CompletableFuture<Suggestions> listSuggestions(@NonNull CommandContext<S> context, @NonNull SuggestionsBuilder builder) {
        builder.suggest(LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm")));
        builder.suggest(LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm")));
        builder.suggest(LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")));
        builder.suggest(LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")) + " Europe/Minsk");
        return builder.buildFuture();
    }
}

package ru.mountcode.plugins.mountcore.paper.api.command.v1.arguments;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import io.papermc.paper.command.brigadier.MessageComponentSerializer;
import io.papermc.paper.command.brigadier.argument.CustomArgumentType;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.ParsingException;
import org.jspecify.annotations.NonNull;
import ru.mountcode.plugins.mountcore.paper.api.command.v1.suggestion.MiniMessageTagSuggestionsProvider;

import java.util.Set;
import java.util.concurrent.CompletableFuture;

public class MiniMessageArgumentType implements CustomArgumentType<@NonNull Component, @NonNull String> {

    private static final SimpleCommandExceptionType INVALID_FORMAT =
            new SimpleCommandExceptionType(MessageComponentSerializer.message().serialize(
                    Component.translatable("mountcore.command.arguments.minimessage.invalid")
            ));

    private static final MiniMessage MINI_MESSAGE = MiniMessage.miniMessage();

    @Override
    public @NonNull Component parse(StringReader reader) throws CommandSyntaxException {
        final int start = reader.getCursor();
        while (reader.canRead()) {
            reader.skip();
        }
        String input = reader.getString().substring(start, reader.getCursor());

        try {
            return MINI_MESSAGE.deserialize(input);
        } catch (ParsingException e) {
            throw INVALID_FORMAT.createWithContext(reader);
        }
    }

    @Override
    public @NonNull ArgumentType<@NonNull String> getNativeType() {
        return StringArgumentType.greedyString();
    }

    @Override
    public <S> @NonNull CompletableFuture<Suggestions> listSuggestions(@NonNull CommandContext<S> context, @NonNull SuggestionsBuilder builder) {
        String remaining = builder.getRemaining().toLowerCase();
        Set<String> tags = MiniMessageTagSuggestionsProvider.getMiniMessageTags();

        // Если нет '<', предложим начать тег
        if (!remaining.contains("<")) {
            builder.suggest("<");
            return builder.buildFuture();
        }

        String afterBracket = remaining.substring(remaining.lastIndexOf('<') + 1);
        for (String tag : tags) {
            if (tag.startsWith(afterBracket)) {
                builder.suggest("<" + tag + (tag.contains(":") ? "" : ">"));
            }
        }

        // Поддержка HEX-цветов
        if (afterBracket.startsWith("#") || afterBracket.isEmpty()) {
            builder.suggest("<#ff0000>");
            builder.suggest("<#00ff00>");
            builder.suggest("<#0000ff>");
        }

        return builder.buildFuture();
    }
}

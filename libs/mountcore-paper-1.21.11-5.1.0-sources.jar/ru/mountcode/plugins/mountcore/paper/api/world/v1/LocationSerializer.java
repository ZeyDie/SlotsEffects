package ru.mountcode.plugins.mountcore.paper.api.world.v1;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;

/**
 * Utility class for serializing and deserializing {@link Location} objects to and from strings.
 * <p>
 * This serializer supports multiple flexible formats depending on the provided data:
 * <ul>
 *     <li>{@code x y z}</li>
 *     <li>{@code world x y z}</li>
 *     <li>{@code x y z yaw pitch}</li>
 *     <li>{@code world x y z yaw pitch}</li>
 * </ul>
 * <p>
 * The default delimiter is a space ({@code " "}), but custom delimiters can also be specified.
 * <p>
 * Both serialization and deserialization methods are {@code @NonNull}-safe and will throw
 * {@link IllegalArgumentException} if the input is invalid or cannot be parsed.
 * <p>
 * Example usage:
 * <pre>{@code
 *     World world = Bukkit.getWorld("world");
 *     Location loc = new Location(world, 100, 65, -20, 90, 0);
 *
 *     // Serialize
 *     String serialized = LocationSerializer.serialize(loc);
 *     // Result: "world 100.0 65.0 -20.0 90.0 0.0"
 *
 *     // Deserialize
 *     Location deserialized = LocationSerializer.deserialize("world 100 65 -20 90 0");
 * }</pre>
 *
 * @author EarWarm
 * @since 5.0.0
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class LocationSerializer {

    private static final String DELIMITER = " ";

    /**
     * Serializes a {@link Location} object into a string using the default delimiter ({@code " "}).
     * <p>
     * Example usage:
     * <pre>{@code
     * Location loc = new Location(Bukkit.getWorld("world"), 10, 64, -5);
     * String result = LocationSerializer.serialize(loc);
     * // "world 10.0 64.0 -5.0"
     * }</pre>
     *
     * @param location the {@link Location} to serialize; must not be {@code null}
     * @return a string representation of the given location
     * @throws IllegalArgumentException if the location is invalid
     */
    public static @NonNull String serialize(@NonNull Location location) {
        return serialize(location, DELIMITER);
    }

    /**
     * Serializes a {@link Location} object into a string using a custom delimiter.
     * <p>
     * The resulting format depends on whether the location includes world and rotation data.
     * <p>
     * Example usage:
     * <pre>{@code
     * Location loc = new Location(Bukkit.getWorld("world_nether"), 50, 70, 30, 180, 15);
     * String result = LocationSerializer.serialize(loc, ",");
     * // "world_nether,50.0,70.0,30.0,180.0,15.0"
     * }</pre>
     *
     * @param location  the {@link Location} to serialize; must not be {@code null}
     * @param delimiter the delimiter separating values; must not be {@code null}
     * @return a string representation of the given location
     * @throws IllegalArgumentException if the location is invalid
     */
    public static @NonNull String serialize(@NonNull Location location, @NonNull String delimiter) {
        StringBuilder sb = new StringBuilder();

        if (location.getWorld() != null) {
            sb.append(location.getWorld().getName()).append(delimiter);
        }

        sb.append(location.getX()).append(delimiter)
                .append(location.getY()).append(delimiter)
                .append(location.getZ());

        // Добавляем yaw/pitch только если они не равны нулю
        if (location.getYaw() != 0.0f || location.getPitch() != 0.0f) {
            sb.append(delimiter)
                    .append(location.getYaw()).append(delimiter)
                    .append(location.getPitch());
        }

        return sb.toString();
    }

    /**
     * Deserializes a location string into a {@link Location} using the default delimiter ({@code " "}).
     * <p>
     * If the world name is missing in the string, the provided {@code defaultWorld} will be used.
     *
     * Example usage:
     * <pre>{@code
     * World world = Bukkit.getWorld("world");
     * Location loc = LocationSerializer.deserialize("100 65 -20", world);
     * // new Location(world, 100, 65, -20)
     * }</pre>
     *
     * @param rawLocation  the serialized location string; must not be {@code null}
     * @param defaultWorld the {@link World} to use if none is specified; may be {@code null}
     * @return a {@link Location} parsed from the string
     * @throws IllegalArgumentException if the string format is invalid or the world cannot be found
     */
    public static @NonNull Location deserialize(@NonNull String rawLocation, @Nullable World defaultWorld) {
        return deserialize(rawLocation, defaultWorld, DELIMITER);
    }

    /**
     * Deserializes a location string into a {@link Location} using the default delimiter ({@code " "}).
     * <p>
     * If the world name is missing, {@code null} will be used as the world.
     *
     * Example usage:
     * <pre>{@code
     * Location loc = LocationSerializer.deserialize("world 100 65 -20 90 0");
     * // new Location(Bukkit.getWorld("world"), 100, 65, -20, 90, 0)
     * }</pre>
     *
     * @param rawLocation the serialized location string; must not be {@code null}
     * @return a {@link Location} parsed from the string
     * @throws IllegalArgumentException if the string format is invalid or the world cannot be found
     */
    public static @NonNull Location deserialize(@NonNull String rawLocation) {
        return deserialize(rawLocation, null, DELIMITER);
    }

    /**
     * Deserializes a location string into a {@link Location} using a custom delimiter.
     * <p>
     * The input must contain between 3 and 6 parts, depending on the format:
     * <ul>
     *     <li>{@code x y z}</li>
     *     <li>{@code world x y z}</li>
     *     <li>{@code x y z yaw pitch}</li>
     *     <li>{@code world x y z yaw pitch}</li>
     * </ul>
     *
     * Example usage:
     * <pre>{@code
     * World defaultWorld = Bukkit.getWorld("world");
     * Location loc = LocationSerializer.deserialize("world,100,65,-20,90,0", defaultWorld, ",");
     * // new Location(Bukkit.getWorld("world"), 100, 65, -20, 90, 0)
     * }</pre>
     *
     * @param rawLocation  the serialized location string; must not be {@code null}
     * @param defaultWorld the default {@link World} if none is specified; may be {@code null}
     * @param delimiter    the delimiter separating values; must not be {@code null}
     * @return a {@link Location} parsed from the string
     * @throws IllegalArgumentException if the format is invalid, the world cannot be found, or numbers cannot be parsed
     */
    public static @NonNull Location deserialize(@NonNull String rawLocation, @Nullable World defaultWorld, @NonNull String delimiter) {
        String[] parts = rawLocation.trim().split(delimiter);
        if (parts.length < 3) {
            throw new IllegalArgumentException("Invalid location format: expected at least 3 parts");
        }

        try {
            World world;
            double x, y, z;
            float yaw = 0f;
            float pitch = 0f;

            switch (parts.length) {
                case 3 -> {
                    // x y z
                    world = defaultWorld;
                    x = Double.parseDouble(parts[0]);
                    y = Double.parseDouble(parts[1]);
                    z = Double.parseDouble(parts[2]);
                }
                case 4 -> {
                    // world x y z
                    world = Bukkit.getWorld(parts[0]);
                    if (world == null) {
                        throw new IllegalArgumentException("World not found: " + parts[0]);
                    }
                    x = Double.parseDouble(parts[1]);
                    y = Double.parseDouble(parts[2]);
                    z = Double.parseDouble(parts[3]);
                }
                case 5 -> {
                    // x y z yaw pitch
                    world = defaultWorld;
                    x = Double.parseDouble(parts[0]);
                    y = Double.parseDouble(parts[1]);
                    z = Double.parseDouble(parts[2]);
                    yaw = Float.parseFloat(parts[3]);
                    pitch = Float.parseFloat(parts[4]);
                }
                case 6 -> {
                    // world x y z yaw pitch
                    world = Bukkit.getWorld(parts[0]);
                    if (world == null) {
                        throw new IllegalArgumentException("World not found: " + parts[0]);
                    }
                    x = Double.parseDouble(parts[1]);
                    y = Double.parseDouble(parts[2]);
                    z = Double.parseDouble(parts[3]);
                    yaw = Float.parseFloat(parts[4]);
                    pitch = Float.parseFloat(parts[5]);
                }
                default -> throw new IllegalArgumentException("Invalid location format: unexpected argument count " + parts.length);
            }

            return new Location(world, x, y, z, yaw, pitch);
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException("Invalid number format in location string: " + rawLocation, ex);
        }
    }

}

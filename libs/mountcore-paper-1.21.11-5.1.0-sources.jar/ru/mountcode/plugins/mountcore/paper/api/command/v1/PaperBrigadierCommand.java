package ru.mountcode.plugins.mountcore.paper.api.command.v1;

import io.papermc.paper.command.brigadier.CommandSourceStack;
import ru.mountcode.plugins.mountcore.api.command.v1.BrigadierCommand;

/**
 * {@inheritDoc}
 */
public interface PaperBrigadierCommand extends BrigadierCommand<CommandSourceStack> {
}

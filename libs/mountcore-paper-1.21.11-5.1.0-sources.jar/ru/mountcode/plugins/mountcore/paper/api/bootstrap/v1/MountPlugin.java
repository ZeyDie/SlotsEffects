package ru.mountcode.plugins.mountcore.paper.api.bootstrap.v1;

import io.papermc.paper.command.brigadier.CommandSourceStack;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;
import org.jspecify.annotations.NonNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.mountcode.plugins.mountcore.api.bootstrap.v1.IMountPlugin;
import ru.mountcode.plugins.mountcore.api.bootstrap.v1.PluginMetadata;
import ru.mountcode.plugins.mountcore.api.bootstrap.v1.PluginSettings;
import ru.mountcode.plugins.mountcore.api.bootstrap.v1.excpetions.PluginModuleReloadException;
import ru.mountcode.plugins.mountcore.api.bootstrap.v1.module.PluginModuleManager;
import ru.mountcode.plugins.mountcore.api.command.v1.CommandRegistrar;
import ru.mountcode.plugins.mountcore.paper.api.command.v1.PaperCommandRegistrar;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Represents the base abstract class for all MountCore Paper plugins.
 * <p>
 * This class provides a structured lifecycle management and standardized plugin initialization flow.
 * It integrates MountCore APIs with the Paper (Bukkit) platform, including:
 * <ul>
 *     <li>Automatic construction of {@link PluginMetadata}</li>
 *     <li>Automatic management of {@link PluginSettings}</li>
 *     <li>Automatic initialization of {@link PluginModuleManager}</li>
 * </ul>
 * It also provides hooks for plugin developers to define custom behavior during the plugin's lifecycle
 * (construction, enabling, reloading, and shutdown).
 *
 * <p>The following lifecycle order is followed:
 * <pre>
 *     onLoad() → construct() → onEnable() → enable() → onReload() → reload() → onDisable() → shutdown()
 * </pre>
 * <p>
 * Example usage:
 * <pre>{@code
 * public final class ExamplePlugin extends MountPlugin {
 *
 *     @Override
 *     public void construct() {
 *         logger().info("Example plugin constructed!");
 *     }
 *
 *     @Override
 *     public void enable() {
 *         logger().info("Example plugin enabled!");
 *     }
 *
 *     @Override
 *     public void reload() {
 *         logger().info("Example plugin reloaded!");
 *     }
 *
 *     @Override
 *     public void shutdown() {
 *         logger().info("Example plugin disabled!");
 *     }
 * }
 * }</pre>
 *
 * @since 5.0.0
 */
public abstract class MountPlugin extends JavaPlugin implements IMountPlugin {

    private Logger pluginLogger;

    private PluginMetadata pluginMetadata;
    private PluginSettings pluginSettings;
    private PluginModuleManager pluginModuleManager;
    private PaperCommandRegistrar commandRegistrar;

    /**
     * Called by Paper during plugin loading.
     * Initializes plugin metadata, settings, logger, and module manager before enabling.
     * This method is final to enforce consistent initialization behavior across all MountCore plugins.
     *
     * @since 5.0.0
     */
    @Override
    public final void onLoad() {
        // Constructing plugin meta
        this.pluginMetadata = PluginMetadata.builder()
                .name(getPluginMeta().getName())
                .version(getPluginMeta().getVersion())
                .build();

        // Constructing plugin logger
        this.pluginLogger = LoggerFactory.getLogger(this.getPluginMetadata().displayName());

        // Constructing command registrar
        this.commandRegistrar = new PaperCommandRegistrar();

        // Constructing plugin settings
        PluginSettings.PluginSettingsBuilder pluginSettingsBuilder = PluginSettings.builder();
        pluginSettingsBuilder.directory(Path.of("MountCore", this.getPluginMetadata().name()));

        this.pluginSettings = this.configurePluginSettings(pluginSettingsBuilder).build();

        // Constructing plugin module manager
        this.pluginModuleManager = new PluginModuleManager(this);

        // Calling plugin constructing handle
        this.construct();
    }

    /**
     * Handles plugin reloading logic. Can be triggered manually from the plugin.
     * <p>
     * By default, it reloads plugin modules and calls the {@link #reload()} hook for custom logic.
     *
     * @since 5.0.0
     */
    public final void onReload() {
        this.printState(Component.translatable("mountcore.plugin.reloading", Component.text(this.getPluginMetadata().displayName())));
        // Reloading plugin modules
        if (!this.getModuleManager().reloadModules()) {
            throw new PluginModuleReloadException("Error while reloading modules in " + this.getPluginMetadata().displayName() + " plugin");
        }
        // Calling plugin enable handle
        this.reload();
    }

    /**
     * Called by Paper when the plugin is enabled.
     * <p>
     * Triggers the {@link #enable()} hook for plugin-specific startup logic.
     *
     * @since 5.0.0
     */
    @Override
    public final void onEnable() {
        this.printState(Component.translatable("mountcore.plugin.loading", Component.text(this.getPluginMetadata().displayName())));
        // Calling plugin enable handle
        this.enable();

        // Register commands
        this.commandRegistrar.registerCommands(this);
    }

    /**
     * Called by Paper when the plugin is disabled.
     * <p>
     * Invokes {@link #shutdown()} to execute cleanup and shutdown logic.
     *
     * @since 5.0.0
     */
    @Override
    public final void onDisable() {
        this.printState(Component.translatable("mountcore.plugin.unloading", Component.text(this.getPluginMetadata().displayName())));
        // Calling plugin shutdown handle
        this.shutdown();
    }

    /**
     * Returns the plugin settings instance.
     *
     * @return plugin settings
     * @since 5.0.0
     */
    @Override
    public final @NonNull PluginSettings getSettings() {
        return this.pluginSettings;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public final @NonNull Path getPluginDirectory() {
        if (!Files.exists(this.getSettings().getDirectory())) {
            try {
                Files.createDirectories(this.getSettings().getDirectory());
            } catch (IOException e) {
                this.logger().error("Exception on creating plugin directory", e);
            }
        }

        return this.getSettings().getDirectory();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public final @NonNull PluginMetadata getPluginMetadata() {
        return this.pluginMetadata;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public final PluginModuleManager getModuleManager() {
        return this.pluginModuleManager;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Logger logger() {
        return this.pluginLogger;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void printState(Component component) {
        if (!this.getSettings().isStateLogging()) {
            return;
        }
        Bukkit.getConsoleSender().sendMessage(component);
    }

    @Override
    public CommandRegistrar<CommandSourceStack> getCommandRegistrar() {
        return this.commandRegistrar;
    }
}

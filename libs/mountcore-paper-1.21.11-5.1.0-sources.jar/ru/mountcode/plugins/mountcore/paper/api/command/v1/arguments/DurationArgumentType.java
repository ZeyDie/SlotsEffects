package ru.mountcode.plugins.mountcore.paper.api.command.v1.arguments;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.DynamicCommandExceptionType;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import io.papermc.paper.command.brigadier.MessageComponentSerializer;
import io.papermc.paper.command.brigadier.argument.CustomArgumentType;
import net.kyori.adventure.text.Component;
import org.jspecify.annotations.NonNull;
import ru.mountcode.plugins.mountcore.api.time.v1.DurationParser;
import ru.mountcode.plugins.mountcore.api.time.v1.format.DurationComponentFormatter;
import ru.mountcode.plugins.mountcore.api.time.v1.format.TimeContext;

import java.time.Duration;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public class DurationArgumentType implements CustomArgumentType<@NonNull Duration, @NonNull String> {

    private static final SimpleCommandExceptionType INVALID_DURATION =
            new SimpleCommandExceptionType(MessageComponentSerializer.message().serialize(
                    Component.translatable("mountcore.command.arguments.duration.invalid")
            ));

    private static final DynamicCommandExceptionType TOO_SHORT =
            new DynamicCommandExceptionType(
                    min -> MessageComponentSerializer.message().serialize(
                            Component.translatable("mountcore.command.arguments.duration.min", Component.text((String) min))
                    )
            );

    private static final DynamicCommandExceptionType TOO_LONG =
            new DynamicCommandExceptionType(
                    max -> MessageComponentSerializer.message().serialize(
                            Component.translatable("mountcore.command.arguments.duration.max", Component.text((String) max))
                    )
            );

    private static final List<String> SUGGESTIONS = List.of(
            "10s", "30s", "1m", "5m", "10m", "1h", "1h 30min", "1d"
    );

    private final Duration minDuration;
    private final Duration maxDuration;

    public DurationArgumentType() {
        minDuration = null;
        maxDuration = null;
    }

    public DurationArgumentType(Duration minDuration, Duration maxDuration) {
        this.minDuration = minDuration;
        this.maxDuration = maxDuration;
    }

    @Override
    public Duration parse(@NonNull StringReader reader) throws CommandSyntaxException {
        final int start = reader.getCursor();
        while (reader.canRead()) {
            reader.skip();
        }
        String input = reader.getString().substring(start, reader.getCursor());

        Duration duration;
        try {
            duration = DurationParser.parse(input);
        } catch (DateTimeParseException e) {
            throw INVALID_DURATION.createWithContext(reader);
        }

        if (minDuration != null && duration.compareTo(minDuration) < 0) {
            throw TOO_SHORT.createWithContext(reader, DurationComponentFormatter.format(minDuration, TimeContext.IN));
        }

        if (maxDuration != null && duration.compareTo(maxDuration) > 0) {
            throw TOO_LONG.createWithContext(reader, DurationComponentFormatter.format(maxDuration, TimeContext.IN));
        }

        return duration;
    }

    @Override
    public @NonNull ArgumentType<String> getNativeType() {
        return StringArgumentType.greedyString();
    }

    @Override
    public <S> @NonNull CompletableFuture<Suggestions> listSuggestions(@NonNull CommandContext<S> context, SuggestionsBuilder builder) {
        String remaining = builder.getRemaining().toLowerCase();
        for (String suggestion : SUGGESTIONS) {
            if (suggestion.startsWith(remaining)) {
                builder.suggest(suggestion);
            }
        }
        return builder.buildFuture();
    }
}

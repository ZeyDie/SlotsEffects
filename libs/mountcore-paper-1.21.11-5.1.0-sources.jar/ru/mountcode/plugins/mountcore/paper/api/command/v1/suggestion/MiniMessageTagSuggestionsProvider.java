package ru.mountcode.plugins.mountcore.paper.api.command.v1.suggestion;

import org.jspecify.annotations.NonNull;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public final class MiniMessageTagSuggestionsProvider {
    private static final Set<String> MINI_MESSAGE_TAGS = new HashSet<>();

    static {
        loadMiniMessageTags();
    }

    private MiniMessageTagSuggestionsProvider() {}

    /**
     * Loads standard MiniMessage tag names (colors, styles, decorations, click, hover, etc.)
     */
    private static void loadMiniMessageTags() {
        // Base colors
        MINI_MESSAGE_TAGS.addAll(Arrays.asList(
                "black", "dark_blue", "dark_green", "dark_aqua", "dark_red", "dark_purple", "gold",
                "gray", "dark_gray", "blue", "green", "aqua", "red", "light_purple", "yellow", "white"
        ));

        // Decorations / styles
        MINI_MESSAGE_TAGS.addAll(Arrays.asList(
                "bold", "italic", "underlined", "strikethrough", "obfuscated", "reset"
        ));

        // Interactivity tags
        MINI_MESSAGE_TAGS.addAll(Arrays.asList(
                "hover", "click", "insertion", "keybind", "font", "transition", "rainbow", "gradient"
        ));

        // Hover / click actions
        MINI_MESSAGE_TAGS.addAll(Arrays.asList(
                "hover:show_text", "hover:show_item", "hover:show_entity",
                "click:open_url", "click:run_command", "click:suggest_command", "click:copy_to_clipboard"
        ));

        // Misc tags
        MINI_MESSAGE_TAGS.addAll(Arrays.asList(
                "lang", "newline", "line", "score", "selector"
        ));
    }

    public static @NonNull Set<String> getMiniMessageTags() {
        return Collections.unmodifiableSet(MINI_MESSAGE_TAGS);
    }
}

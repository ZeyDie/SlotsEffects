package ru.mountcode.plugins.mountcore.paper.api.inventory.v1;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.jspecify.annotations.NonNull;

import java.util.*;

/**
 * Utility class that provides helper methods for working with {@link Inventory} and {@link ItemStack} objects.
 * <p>
 * This class contains common operations for counting, removing, and calculating available space for items
 * within player or generic inventories in a Paper (Bukkit) environment.
 * </p>
 * <p>
 * The class is non-instantiable and should only be used through its static methods.
 * </p>
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class InventoryHelper {

    /**
     * Counts the total number of items in the player's inventory that are similar to the specified {@link ItemStack}.
     *
     * @param player the player whose inventory should be checked; must not be {@code null}
     * @param searchedItemStack the item to search for; must not be {@code null}
     * @return the total count of similar items found in the player's inventory
     */
    public static int getItemCount(@NonNull Player player, @NonNull ItemStack searchedItemStack) {
        return getItemCount(player.getInventory(), searchedItemStack);
    }

    /**
     * Counts the total number of items in the given {@link Inventory} that are similar to the specified {@link ItemStack}.
     *
     * @param inventory the inventory to search; must not be {@code null}
     * @param searchedItemStack the item to search for; must not be {@code null}
     * @return the total count of similar items found in the inventory
     */
    public static int getItemCount(@NonNull Inventory inventory, @NonNull ItemStack searchedItemStack) {
        int amount = 0;
        for (ItemStack itemStack : inventory.getContents()) {
            if (!ItemStackHelper.isNullable(itemStack) && itemStack.isSimilar(searchedItemStack)) {
                amount += itemStack.getAmount();
            }
        }
        return amount;
    }

    /**
     * Removes the specified amount of the given item type from the provided {@link Inventory}.
     * <p>
     * The amount removed equals the amount of the given {@code removeItemStack}.
     * </p>
     *
     * @param inventory the inventory to modify; must not be {@code null}
     * @param removeItemStack the item type and base amount to remove; must not be {@code null}
     */
    public static void removeItem(@NonNull Inventory inventory, @NonNull ItemStack removeItemStack) {
        removeItem(inventory, removeItemStack, removeItemStack.getAmount());
    }

    /**
     * Removes a specific number of items similar to the given {@link ItemStack} from the provided {@link Inventory}.
     * <p>
     * The method iterates through inventory slots and decreases item amounts or clears slots
     * until the specified quantity has been removed.
     * </p>
     *
     * @param inventory the inventory to modify; must not be {@code null}
     * @param removeItemStack the item type to remove; must not be {@code null}
     * @param amount the number of items to remove
     */
    public static void removeItem(@NonNull Inventory inventory, @NonNull ItemStack removeItemStack, int amount) {
        for (int i = 0; i < inventory.getSize(); i++) {
            ItemStack inventoryItemStack = inventory.getItem(i);
            if (ItemStackHelper.isNullable(inventoryItemStack)) {
                continue;
            }

            if (removeItemStack.isSimilar(inventoryItemStack)) {
                int checkAmount = inventoryItemStack.getAmount();
                if (checkAmount == amount) {
                    inventoryItemStack = new ItemStack(Material.AIR);
                    inventory.setItem(i, new ItemStack(Material.AIR));
                    amount = 0;
                    checkAmount = 0;
                }
                if (checkAmount < amount) {
                    inventoryItemStack = new ItemStack(Material.AIR);
                    inventory.setItem(i, new ItemStack(Material.AIR));
                    amount = amount - checkAmount;
                    checkAmount = 0;
                }
                if (checkAmount > amount) {
                    inventoryItemStack.setAmount(checkAmount - amount);
                    amount = 0;
                }

                inventory.setItem(i, inventoryItemStack);
                if (amount == 0) {
                    break;
                }
            }
        }
    }

    /**
     * Calculates the total empty space available in the player's inventory
     * for a given {@link ItemStack}.
     *
     * @param player the player whose inventory should be checked; must not be {@code null}
     * @param itemStack the item type to check for available space; must not be {@code null}
     * @return the total available space for the specified item in the player's inventory
     */
    public static int getEmptySpace(@NonNull Player player, @NonNull ItemStack itemStack) {
        return getEmptySpace(player.getInventory(), itemStack);
    }

    /**
     * Calculates the total empty space in the given {@link Inventory} for a specific {@link ItemStack}.
     * <p>
     * This method considers both completely empty slots and partially filled stacks
     * that can still accept more items of the same type.
     * </p>
     *
     * @param inventory the inventory to check; must not be {@code null}
     * @param itemStack the item type to calculate space for; must not be {@code null}
     * @return the total available space (in item units) for the specified item
     */
    public static int getEmptySpace(@NonNull Inventory inventory, @NonNull ItemStack itemStack) {
        int emptySpace = 0;
        for (ItemStack checkItem : inventory.getContents()) {
            if (ItemStackHelper.isNullable(checkItem)) {
                emptySpace += itemStack.getMaxStackSize();
                continue;
            }

            if (!checkItem.isSimilar(itemStack)) {
                continue;
            }

            if (checkItem.getMaxStackSize() <= 1) {
                continue;
            }

            if (checkItem.getAmount() >= checkItem.getMaxStackSize()) {
                continue;
            }

            emptySpace += (checkItem.getMaxStackSize() - checkItem.getAmount());
        }

        return emptySpace;
    }

    /**
     * Checks if the player's inventory has enough available space to fit all the specified {@link ItemStack} elements.
     * <p>
     * This method is a convenience wrapper around
     * {@link #hasEnoughSpace(Inventory, List)} that directly operates on a {@link Player}'s inventory.
     * <p>
     *
     * Example usage:
     * <pre>{@code
     * Player player = ...;
     * List<ItemStack> rewardItems = List.of(
     *     new ItemStack(Material.DIAMOND, 32),
     *     new ItemStack(Material.GOLD_INGOT, 64)
     * );
     *
     * if (InventoryHelper.hasEnoughSpace(player, rewardItems)) {
     *     player.getInventory().addItem(rewardItems.toArray(new ItemStack[0]));
     * } else {
     *     player.sendMessage("Not enough inventory space!");
     * }
     * }</pre>
     *
     * @param player the player whose inventory should be checked; must not be {@code null}
     * @param items the list of items to test for space; must not be {@code null}
     * @return {@code true} if the player's inventory has enough space to fit all specified items; {@code false} otherwise
     * @since 5.0.7
     */
    public static boolean hasEnoughSpace(@NonNull Player player, @NonNull List<ItemStack> items) {
        return hasEnoughSpace(player.getInventory(), items);
    }

    /**
     * Checks whether the given {@link Inventory} has enough capacity to store all provided {@link ItemStack} elements.
     * <p>
     * The method groups similar items using {@link #groupItemsBySimilarity(List)} and calculates
     * the total available space for each grouped type using {@link #getEmptySpace(Inventory, ItemStack)}.
     * If the inventory lacks sufficient space for any of the grouped items, the method returns {@code false}.
     * <p>
     *
     * Example usage:
     * <pre>{@code
     * Inventory inventory = player.getInventory();
     * List<ItemStack> lootItems = List.of(
     *     new ItemStack(Material.EMERALD, 10),
     *     new ItemStack(Material.IRON_INGOT, 20)
     * );
     *
     * boolean canFit = InventoryHelper.hasEnoughSpace(inventory, lootItems);
     * if (canFit) {
     *     inventory.addItem(lootItems.toArray(new ItemStack[0]));
     * }
     * }</pre>
     *
     * @param inventory the inventory to check for available space; must not be {@code null}
     * @param items the collection of items to test for available capacity; must not be {@code null}
     * @return {@code true} if there is enough space for all given items, otherwise {@code false}
     * @since 5.0.7
     */
    public static boolean hasEnoughSpace(@NonNull Inventory inventory, @NonNull List<ItemStack> items) {
        if (items.isEmpty()) {
            return true;
        }

        Inventory clonedInventory = cloneInventory(inventory);

        Map<Integer, ItemStack> leftovers = clonedInventory.addItem(
                items.stream()
                        .filter(Objects::nonNull)
                        .map(ItemStack::clone)
                        .toArray(ItemStack[]::new)
        );

        return leftovers.isEmpty();
    }

    /**
     * Groups a list of {@link ItemStack} objects by similarity, aggregating their total quantities.
     * <p>
     * Two {@link ItemStack}s are considered similar if {@link ItemStack#isSimilar(ItemStack)} returns {@code true}.
     * The returned map uses a representative item (with stack size set to {@code 1}) as the key
     * and the total amount of all similar items as the value.
     *
     * <p>
     * This method is typically used when calculating combined space requirements for a set of items.
     * <p>
     *
     * Example usage:
     * <pre>{@code
     * List<ItemStack> items = List.of(
     *     new ItemStack(Material.DIAMOND, 5),
     *     new ItemStack(Material.DIAMOND, 3),
     *     new ItemStack(Material.EMERALD, 10)
     * );
     *
     * Map<ItemStack, Integer> grouped = InventoryHelper.groupItemsBySimilarity(items);
     * // grouped now contains two entries:
     * // - DIAMOND -> 8
     * // - EMERALD -> 10
     * }</pre>
     *
     * @param items the collection of items to group; must not be {@code null}
     * @return a map where each key is a representative {@link ItemStack} and the value is the total amount of similar items
     * @since 5.0.7
     */
    public static @NonNull Map<ItemStack, Integer> groupItemsBySimilarity(@NonNull List<ItemStack> items) {
        Map<ItemStack, Integer> grouped = new HashMap<>();

        outer:
        for (ItemStack item : items) {
            if (item == null) continue;

            for (ItemStack key : grouped.keySet()) {
                if (key.isSimilar(item)) {
                    grouped.put(key, grouped.get(key) + item.getAmount());
                    continue outer;
                }
            }

            ItemStack representative = item.clone();
            representative.setAmount(1);
            grouped.put(representative, item.getAmount());
        }

        return grouped;
    }

    /**
     * Creates a deep copy of the given {@link Inventory}.
     * <p>
     * The cloned inventory preserves:
     * <ul>
     *     <li>Inventory holder</li>
     *     <li>Inventory size</li>
     *     <li>Slot-to-slot item placement</li>
     * </ul>
     * Each {@link ItemStack} is cloned individually using {@link ItemStack#clone()},
     * ensuring that modifications to items in the cloned inventory do not affect
     * the original inventory and vice versa.
     * <p>
     * Empty slots ({@code null} items) are preserved as empty in the cloned inventory.
     * <p>
     * <b>Example usage:</b>
     * <pre>{@code
     * Inventory original = player.getInventory();
     * Inventory copy = InventoryUtils.cloneInventory(original);
     *
     * // Modifying the copy will not affect the original inventory
     * copy.clear();
     * }</pre>
     *
     * @param inventory the source inventory to clone; must not be {@code null}
     * @return a new {@link Inventory} instance containing deep-cloned item stacks
     * @throws NullPointerException if {@code inventory} is {@code null}
     *
     * @since 5.0.16
     */
    public static @NonNull Inventory cloneInventory(@NonNull Inventory inventory) {
        Inventory clone = Bukkit.createInventory(
                inventory.getHolder(),
                inventory.getType()
        );

        ItemStack[] contents = inventory.getContents();
        for (int i = 0; i < contents.length; i++) {
            ItemStack item = contents[i];
            if (item != null) {
                clone.setItem(i, item.clone());
            }
        }

        return clone;
    }
}

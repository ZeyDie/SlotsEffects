package ru.mountcode.plugins.mountcore.paper.api.command.v1;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import io.papermc.paper.command.brigadier.CommandSourceStack;
import io.papermc.paper.command.brigadier.Commands;
import io.papermc.paper.plugin.lifecycle.event.types.LifecycleEvents;
import org.jspecify.annotations.NonNull;
import ru.mountcode.plugins.mountcore.api.command.v1.BrigadierCommand;
import ru.mountcode.plugins.mountcore.api.command.v1.CommandRegistrar;
import ru.mountcode.plugins.mountcore.paper.api.bootstrap.v1.MountPlugin;

import java.util.ArrayList;
import java.util.List;

public class PaperCommandRegistrar implements CommandRegistrar<CommandSourceStack> {

    private final List<BrigadierCommand<CommandSourceStack>> commands = new ArrayList<>();

    @Override
    public void register(@NonNull BrigadierCommand<CommandSourceStack> command) {
        this.commands.add(command);
    }

    public void registerCommands(MountPlugin plugin) {
        plugin.getLifecycleManager().registerEventHandler(LifecycleEvents.COMMANDS, event -> {
            for (BrigadierCommand<CommandSourceStack> command : this.commands) {
                LiteralArgumentBuilder<CommandSourceStack> literalCommandNode = Commands.literal(command.getName());

                event.registrar().register(command.construct(literalCommandNode), command.getDescription(), command.getAliases());
            }
        });
    }
}

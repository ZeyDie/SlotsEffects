package ru.mountcode.plugins.mountcore.paper.api.command.v1.arguments;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import io.papermc.paper.command.brigadier.MessageComponentSerializer;
import io.papermc.paper.command.brigadier.argument.ArgumentTypes;
import io.papermc.paper.command.brigadier.argument.CustomArgumentType;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import org.jspecify.annotations.NonNull;

public abstract class IdentifierArgumentType<T> implements CustomArgumentType<@NonNull T, @NonNull Key> {

    private static final SimpleCommandExceptionType INVALID = new SimpleCommandExceptionType(
            MessageComponentSerializer.message().serialize(Component.translatable("mountcore.command.arguments.identifier.invalid"))
    );

    public final @NonNull Key parseKey(@NonNull StringReader reader) throws CommandSyntaxException {
        int cursor = reader.getCursor();
        String greedy = readGreedy(reader);

        try {
            return Key.key(greedy);
        } catch (Exception exception) {
            reader.setCursor(cursor);
            throw INVALID.createWithContext(reader);
        }
    }

    @Override
    public final @NonNull ArgumentType<@NonNull Key> getNativeType() {
        return ArgumentTypes.key();
    }

    private String readGreedy(StringReader reader) {
        int cursor = reader.getCursor();

        while (reader.canRead() && allowedChar(reader.peek())) {
            reader.skip();
        }

        return reader.getString().substring(cursor, reader.getCursor());
    }

    protected boolean allowedChar(char character) {
        return Key.allowedInNamespace(character) || character == ':' || Key.allowedInValue(character);
    }
}

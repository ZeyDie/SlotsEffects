package ru.mountcode.plugins.mountcore.api.translation.v1;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.minimessage.translation.MiniMessageTranslationStore;
import net.kyori.adventure.translation.GlobalTranslator;
import org.jspecify.annotations.NonNull;
import ru.mountcode.plugins.mountcore.api.bootstrap.v1.IMountPlugin;
import ru.mountcode.plugins.mountcore.api.bootstrap.v1.module.IReloadableModule;
import ru.mountcode.plugins.mountcore.api.bootstrap.v1.module.PluginModule;

import java.io.IOException;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Properties;

@Slf4j
public class TranslationPluginModule extends PluginModule implements IReloadableModule {

    public static final String MODULE_NAME = "translation";

    @Getter(AccessLevel.PROTECTED)
    private final TranslationLoader translationLoader;
    @Getter(AccessLevel.PROTECTED)
    private final Key translationStoreKey;
    @Getter(AccessLevel.PROTECTED)
    private MiniMessageTranslationStore translationStore;

    public TranslationPluginModule(IMountPlugin plugin) {
        super(plugin);
        this.translationStoreKey = Key.key(this.getPlugin().getPluginMetadata().name().toLowerCase() + ":automatic");
        this.translationStore = this.createTranslationStore();
        this.translationLoader = new TranslationLoader(this.getPlugin().getClass(), plugin.getPluginDirectory().resolve("translations"));
    }

    @Override
    public void enable() {
        loadTranslations();
    }

    @Override
    public void shutdown() {
        GlobalTranslator.translator().removeSource(this.translationStore);
    }

    @Override
    public boolean reload() {
        GlobalTranslator.translator().removeSource(this.translationStore);
        this.translationStore = createTranslationStore();
        try {
            this.loadTranslations();
        } catch (TranslationLoadingException e) {
            log.error("Error while reloading translations in plugin {}", this.getPlugin().getPluginMetadata().name(), e);
            return false;
        }

        return true;
    }

    @NonNull
    protected MiniMessageTranslationStore createTranslationStore() {
        return MiniMessageTranslationStore.create(this.translationStoreKey);
    }

    protected void loadTranslations() {
        String pluginName = this.getPlugin().getPluginMetadata().name().toLowerCase();

        try {
            Optional<Map<Locale, Properties>> translationBundleOptional = this.translationLoader.getTranslations();
            if (translationBundleOptional.isEmpty()) {
                log.warn("Translations for automatic loading not founded for plugin {}", this.getPlugin().getPluginMetadata().name());
                return;
            }

            for (Map.Entry<Locale, Properties> entry : translationBundleOptional.get().entrySet()) {
                Locale locale = entry.getKey();
                entry.getValue().forEach((key, value) -> {
                    String translationKey = (String) key;
                    if (!translationKey.startsWith(pluginName)) {
                        translationKey = pluginName + "." + translationKey;
                    }

                    try {
                        this.translationStore.register(translationKey, locale, (String) value);
                    } catch (IllegalArgumentException e) {
                        log.warn("Found duplicate translation key {} in {} locale for plugin {}", key, locale.toLanguageTag(), this.getPlugin().getPluginMetadata().name());
                    }
                });
            }

            GlobalTranslator.translator().addSource(this.translationStore);
        } catch (IOException e) {
            throw new TranslationLoadingException("Exception on automatic loading translations", e);
        }
    }

    @Override
    public @NonNull String getName() {
        return MODULE_NAME;
    }
}

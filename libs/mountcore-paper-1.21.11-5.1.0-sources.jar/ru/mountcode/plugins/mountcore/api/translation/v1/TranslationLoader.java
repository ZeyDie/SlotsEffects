package ru.mountcode.plugins.mountcore.api.translation.v1;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.*;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;

public class TranslationLoader {

    private final static Logger LOGGER = LoggerFactory.getLogger(TranslationLoader.class);

    private static final Pattern TRANSLATION_FILE_PATTERN = Pattern.compile("language_([a-z]{2})(?:_([A-Z]{2}))?.*\\.properties");

    private static final String bundleName = "language";
    private static final String inJarTranslationsDirectory = "translations";

    private final Path translationsDirectory;
    private final Class<?> anchorClass;

    public TranslationLoader(Class<?> anchorClass, Path translationsDirectory) {
        this.anchorClass = anchorClass;
        this.translationsDirectory = translationsDirectory;
    }

    /**
     * Основной метод, возвращающий итоговый словарь с переводами
     *
     * @return Map, где ключ — Locale, значение — Properties с переводами
     * @throws IOException если возникли ошибки ввода/вывода
     */
    public Optional<Map<Locale, Properties>> getTranslations() throws IOException {
        Map<Locale, Properties> originalBundle = loadOriginalBundle();

        if (originalBundle.isEmpty()) {
            return Optional.empty();
        }

        validateExternalOriginalBundle(originalBundle);

        return Optional.of(loadExternalBundle());
    }

    // Загрузка оригинальных переводов из JAR
    private Map<Locale, Properties> loadOriginalBundle() throws IOException {
        Map<Locale, Properties> bundles = new HashMap<>();
        List<String> originalFiles = getResourceFiles("/" + inJarTranslationsDirectory);

        for (String fileName : originalFiles) {
            Matcher matcher = TRANSLATION_FILE_PATTERN.matcher(fileName);
            if (matcher.matches()) {
                String language = matcher.group(1);
                String country = matcher.group(2);
                Locale locale = (country == null) ? Locale.of(language) : Locale.of(language, country);

                Properties bundleProps = new Properties();
                try (InputStream in = getResourceTranslation(fileName)) {
                    bundleProps.load(in);
                }

                bundles.put(locale, bundleProps);
            }
        }
        return bundles;
    }

    private void validateExternalOriginalBundle(Map<Locale, Properties> originalBundle) throws IOException {
        Files.createDirectories(this.translationsDirectory);
        for (Locale locale : originalBundle.keySet()) {
            String fileName = bundleName + "_" + locale.toLanguageTag().replace('-', '_') + ".properties";
            Path externalPath = this.translationsDirectory.resolve(fileName);
            if (!Files.exists(externalPath)) {
                try (InputStream in = getResourceTranslation(fileName)) {
                    if (in != null) {
                        Files.copy(in, externalPath);
                    }
                }
            } else {
                validateExternalOriginalTranslations(originalBundle.get(locale), externalPath);
            }
        }
    }

    private void validateExternalOriginalTranslations(Properties originalTranslations, Path externalPath) throws IOException {
        Properties externalOriginalTranslations = new Properties();
        try (InputStream in = Files.newInputStream(externalPath)) {
            externalOriginalTranslations.load(in);
        }

        boolean updated = false;

        // Удаление ключей, которых нет в оригинале
        for (String key : new HashSet<>(externalOriginalTranslations.stringPropertyNames())) {
            if (!originalTranslations.containsKey(key)) {
                externalOriginalTranslations.remove(key);
                updated = true;
            }
        }

        // Дополнение недостающих ключей
        for (String key : originalTranslations.stringPropertyNames()) {
            if (!externalOriginalTranslations.containsKey(key)) {
                externalOriginalTranslations.setProperty(key, originalTranslations.getProperty(key));
                updated = true;
            }
        }

        // Сохранение обновленных данных, если они изменились
        if (updated) {
            try (OutputStream out = Files.newOutputStream(externalPath)) {
                externalOriginalTranslations.store(out, "Updated translation file");
            }
        }
    }

    public Map<Locale, Properties> loadExternalBundle() throws IOException {
        Map<Locale, Properties> externalBundle = new HashMap<>();

        try (Stream<Path> filesStream = Files.list(this.translationsDirectory)) {
            List<Path> externalPaths = filesStream
                    .filter(path -> path.getFileName().toString().matches(bundleName + "_.*\\.properties"))
                    .toList();
            for (Path path : externalPaths) {
                Matcher matcher = TRANSLATION_FILE_PATTERN.matcher(path.getFileName().toString());
                if (!matcher.matches()) {
                    continue;
                }

                Locale locale = getLocaleFromTranslationMatcher(matcher);

                Properties externalTranslations = new Properties();
                try (InputStream in = Files.newInputStream(path)) {
                    externalTranslations.load(in);
                }

                if (externalBundle.containsKey(locale)) {
                    externalBundle.get(locale).putAll(externalTranslations);
                } else {
                    externalBundle.put(locale, externalTranslations);
                }
            }
        }

        return externalBundle;
    }

    // Получение списка файлов из ресурсов
    private List<String> getResourceFiles(String directory) throws IOException {
        List<String> files = new ArrayList<>();

        try {
            URL jarURL = this.anchorClass.getProtectionDomain().getCodeSource().getLocation();
            Path jarPath = Paths.get(jarURL.toURI());
            FileSystem jarFS = FileSystems.newFileSystem(jarPath, this.anchorClass.getClassLoader());
            Path directoryPath = jarFS.getPath(directory);

            try (Stream<Path> stream = Files.walk(directoryPath)) {
                stream.filter(Files::isRegularFile)
                        .forEach(path -> {
                            if (path.toString().endsWith(".properties")) {
                                files.add(path.getFileName().toString());
                            }
                        });
            }

            jarFS.close();
        } catch (URISyntaxException | IOException e) {
            LOGGER.error("Error on getting translations files from jar", e);
        }

        return files;
    }

    private InputStream getResource(String path) {
        return this.anchorClass.getResourceAsStream(path);
    }

    private InputStream getResourceTranslation(String fileName) {
        return getResource("/" + inJarTranslationsDirectory + "/" + fileName);
    }

    private Locale getLocaleFromTranslationMatcher(Matcher matcher) {
        String language = matcher.group(1);
        String country = matcher.group(2);
        return (country == null) ? Locale.of(language) : Locale.of(language, country);
    }
}

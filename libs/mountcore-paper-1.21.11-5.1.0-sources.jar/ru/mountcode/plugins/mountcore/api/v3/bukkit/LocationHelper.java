package ru.mountcode.plugins.mountcore.api.v3.bukkit;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import ru.mountcode.plugins.mountcore.paper.api.world.v1.LocationSerializer;

/**
 * @deprecated use {@link LocationSerializer}
 */
@Deprecated(forRemoval = true, since = "5.0.0")
public class LocationHelper {

    /**
     * Парсит строку в формате "x y z" в объект {@link Location}.
     * Строка должна содержать ровно три компонента: координаты x, y и z.
     *
     * @param location строка в формате "x y z", где x, y и z - координаты в пространстве.
     * @return объект {@link Location}, представляющий локацию с заданными координатами и не заданным миром.
     * @throws IllegalArgumentException если строка имеет неправильный формат или если координаты не могут быть преобразованы в числа.
     */
    public static Location parseLocation(String location) {
        String[] parts = location.split(" ");

        if (parts.length != 3) {
            throw new IllegalArgumentException("Invalid format. Expected format: 'x y z'");
        }

        try {
            double x = Double.parseDouble(parts[0]);
            double y = Double.parseDouble(parts[1]);
            double z = Double.parseDouble(parts[2]);

            return new Location(null, x, y, z);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Invalid number format in the input string.", e);
        }
    }
    /**
     * Парсит строку в одном из форматов: "world x y z" или "world x y z yaw pitch"
     * в объект {@link Location}. Строка может содержать только координаты x, y, z,
     * либо координаты с углами поворота yaw и pitch.
     *
     * @param input строка в формате "world x y z" или "world x y z yaw pitch", где:
     *              <ul>
     *              <li>world - имя мира (должен существовать в сервере)</li>
     *              <li>x, y, z - координаты локации</li>
     *              <li>yaw (необязательно) - угол поворота по горизонтали (в градусах)</li>
     *              <li>pitch (необязательно) - угол поворота по вертикали (в градусах)</li>
     *              </ul>
     * @return объект {@link Location}, представляющий локацию в указанном мире с заданными координатами,
     *         а также с указанными углами поворота, если они были предоставлены.
     * @throws IllegalArgumentException если формат строки неверен, если мир не существует или если координаты/углы не могут быть преобразованы в числа.
     * @throws NullPointerException если мир, который указан, не был найден.
     */
    public static Location parseLocationWithWorldYawPitch(String input) throws IllegalArgumentException {
        String[] parts = input.split(" ");

        if (parts.length < 4 || parts.length > 6) {
            throw new IllegalArgumentException("Invalid format. Expected formats: 'world x y z' or 'world x y z yaw pitch'");
        }

        World world = Bukkit.getWorld(parts[0]);
        if (world == null) {
            throw new NullPointerException("World '" + parts[0] + "' not found.");
        }

        try {
            double x = Double.parseDouble(parts[1]);
            double y = Double.parseDouble(parts[2]);
            double z = Double.parseDouble(parts[3]);

            // Если предоставлены yaw и pitch
            if (parts.length == 6) {
                float yaw = Float.parseFloat(parts[4]);
                float pitch = Float.parseFloat(parts[5]);
                return new Location(world, x, y, z, yaw, pitch);
            }

            // Если только world x y z
            return new Location(world, x, y, z);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Invalid number format in the input string.", e);
        }
    }
}

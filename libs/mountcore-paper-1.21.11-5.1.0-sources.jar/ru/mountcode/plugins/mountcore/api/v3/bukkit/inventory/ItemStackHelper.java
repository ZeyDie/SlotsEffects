package ru.mountcode.plugins.mountcore.api.v3.bukkit.inventory;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

@Deprecated(forRemoval = true, since = "5.0.0")
public class ItemStackHelper {

    /**
     * @param itemStack An item that needs to be checked for emptiness
     * @return Returns true if the object is empty, and false if it is not
     */
    public static boolean isNullable(ItemStack itemStack) {
        return itemStack == null || itemStack.getType().equals(Material.AIR);
    }
}

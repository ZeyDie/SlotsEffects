package ru.mountcode.plugins.mountcore.api.v3.utils;

/**
 * Use {@link ru.mountcode.plugins.mountcore.api.primitive.v1.Primitives}
 */
@Deprecated
public class NumberUtils {

    public static boolean isInteger(String string) {
        try {
            Integer.parseInt(string);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean isDouble(String string) {
        try {
            Double.parseDouble(string);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean isByte(String string) {
        try {
            Byte.parseByte(string);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}

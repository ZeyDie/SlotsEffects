package ru.mountcode.plugins.mountcore.api.v3.bukkit;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;

@Deprecated(forRemoval = true, since = "5.0.0")
public class Sender {

    public static void sendConsole(Component text) {
        Bukkit.getConsoleSender().sendMessage(text);
    }

    public static void broadcast(Component text) {
        Bukkit.broadcast(text);
    }

    public static void broadcastWithPermission(Component text, String permission) {
        Bukkit.broadcast(text, permission);
    }
}

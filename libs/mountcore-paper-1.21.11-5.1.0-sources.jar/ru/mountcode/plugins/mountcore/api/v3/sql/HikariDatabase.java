package ru.mountcode.plugins.mountcore.api.v3.sql;

import com.zaxxer.hikari.HikariDataSource;
import ru.mountcode.plugins.mountcore.api.v3.sql.driver.Driver;

@Deprecated(forRemoval = true, since = "4.0.0")
public class HikariDatabase extends HikariDataSource {

    public HikariDatabase(Driver driver) {
        super(driver.configureHikari());
    }
}

package ru.mountcode.plugins.mountcore.api.v3.exception;

@Deprecated(forRemoval = true, since = "5.0.0")
public class PluginNotTranslatableException extends RuntimeException {
  /**
   * Constructs a new plugin not translatable exception exception with {@code null} as its
   * detail message.  The cause is not initialized, and may subsequently be
   * initialized by a call to {@link #initCause}.
   */
  public PluginNotTranslatableException() {
    super();
  }

  /**
   * Constructs a new plugin not translatable exception with the specified detail message.
   * The cause is not initialized, and may subsequently be initialized by a
   * call to {@link #initCause}.
   *
   * @param message the detail message. The detail message is saved for
   *                later retrieval by the {@link #getMessage()} method.
   */
  public PluginNotTranslatableException(String message) {
    super(message);
  }
}

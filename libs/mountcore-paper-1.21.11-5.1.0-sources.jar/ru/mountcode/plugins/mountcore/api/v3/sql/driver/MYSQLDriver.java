package ru.mountcode.plugins.mountcore.api.v3.sql.driver;

import com.zaxxer.hikari.HikariConfig;
import lombok.Builder;
import ru.mountcode.plugins.mountcore.MountCore;

@Deprecated(forRemoval = true, since = "4.0.0")
@Builder
public class MYSQLDriver extends Driver {

    private static final String DRIVER_CLASS = "com.mysql.cj.jdbc.Driver";
    private static final String URL_TEMPLATE = "jdbc:MySQL://%s:%d/%s";

    @Builder.Default
    private String address = "localhost";
    @Builder.Default
    private int port = 3306;

    private String database;
    private String username;
    private String password;


    @Override
    public String getUrl() {
        return String.format(URL_TEMPLATE, this.address, this.port, this.database);
    }

    @Override
    public String getUsername() {
        return this.username;
    }

    @Override
    public String getPassword() {
        return this.password;
    }

    @Override
    public HikariConfig configureHikari() {
        try {
            Class.forName(DRIVER_CLASS).newInstance();
        } catch (Exception e) {
            MountCore.LOGGER.error("Driver MYSQL has not found.");
            throw new RuntimeException(e);
        }

        return super.configureHikari();
    }
}

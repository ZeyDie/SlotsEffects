package ru.mountcode.plugins.mountcore.api.v3.async;

import com.google.common.util.concurrent.ThreadFactoryBuilder;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Deprecated(forRemoval = true, since = "5.0.0")
public class GlobalExecutors {

    private static final ExecutorService WRITING_IO_EXECUTOR = Executors.newSingleThreadExecutor(new ThreadFactoryBuilder().setNameFormat("MC IO writing #%d").setDaemon(true).build());

    public static ExecutorService writingIO() {
        return WRITING_IO_EXECUTOR;
    }
}

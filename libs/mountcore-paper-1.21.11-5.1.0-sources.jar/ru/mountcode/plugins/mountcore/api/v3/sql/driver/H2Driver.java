package ru.mountcode.plugins.mountcore.api.v3.sql.driver;

import com.zaxxer.hikari.HikariConfig;
import lombok.Builder;
import ru.mountcode.plugins.mountcore.MountCore;

@Deprecated(forRemoval = true, since = "4.0.0")
@Builder
public class H2Driver extends Driver {

    private static final String DRIVER_CLASS = "org.h2.Driver";
    private static final String URL_TEMPLATE = "jdbc:h2:%s";

    private String absolutePath;
    @Builder.Default
    private String username = "root";
    @Builder.Default
    private String password = "root";


    @Override
    public String getUrl() {
        return String.format(URL_TEMPLATE, absolutePath);
    }

    @Override
    public String getUsername() {
        return this.username;
    }

    @Override
    public String getPassword() {
        return this.password;
    }

    @Override
    public HikariConfig configureHikari() {
        try {
            Class.forName(DRIVER_CLASS).newInstance();
        } catch (Exception e) {
            MountCore.LOGGER.error("Driver H2 has not found.");
            throw new RuntimeException(e);
        }

        return super.configureHikari();
    }
}

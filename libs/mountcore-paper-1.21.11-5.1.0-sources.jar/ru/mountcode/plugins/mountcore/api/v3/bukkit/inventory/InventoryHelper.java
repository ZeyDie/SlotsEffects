package ru.mountcode.plugins.mountcore.api.v3.bukkit.inventory;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

@Deprecated(forRemoval = true, since = "5.0.0")
public class InventoryHelper {

    /**
     * @param player The player in whose inventory you need to count the number of items
     * @param searchedItemStack The item whose quantity needs to be counted
     * @return The number of the specified item in the inventory
     */
    public static int getItemCount(Player player, ItemStack searchedItemStack) {
        return getItemCount(player.getInventory(), searchedItemStack);
    }

    /**
     * @param inventory Inventory in which you need to count the number of items
     * @param searchedItemStack The item whose quantity needs to be counted
     * @return The number of the specified item in the inventory
     */
    public static int getItemCount(Inventory inventory, ItemStack searchedItemStack) {
        int amount = 0;
        for (ItemStack inventoryItemStack : inventory.getContents()) {
            if (inventoryItemStack.isSimilar(searchedItemStack)) {
                amount += inventoryItemStack.getAmount();
            }
        }
        return amount;
    }

    public static void removeItem(Inventory inventory, ItemStack removeItemStack) {
        removeItem(inventory, removeItemStack, removeItemStack.getAmount());
    }

    public static void removeItem(Inventory inventory, ItemStack removeItemStack, int amount) {
        for (int i = 0; i < inventory.getSize(); i++) {
            ItemStack inventoryItemStack = inventory.getItem(i);
            if (removeItemStack.isSimilar(inventoryItemStack)) {
                int checkAmount = inventoryItemStack.getAmount();
                if (checkAmount == amount) {
                    inventoryItemStack = new ItemStack(Material.AIR);
                    inventory.setItem(i, new ItemStack(Material.AIR));
                    amount = 0;
                    checkAmount = 0;
                }
                if (checkAmount < amount) {
                    inventoryItemStack = new ItemStack(Material.AIR);
                    inventory.setItem(i, new ItemStack(Material.AIR));
                    amount = amount - checkAmount;
                    checkAmount = 0;
                }
                if (checkAmount > amount) {
                    inventoryItemStack.setAmount(checkAmount - amount);
                    amount = 0;
                }

                inventory.setItem(i, inventoryItemStack);
                if (amount == 0) {
                    break;
                }
            }
        }
    }

    /**
     * @param player The player in whose inventory you need to search
     * @param itemStack The item that you need to search for a free place for
     * @return Returns the amount of free space for the specified item
     */
    public static int getEmptySpace(Player player, ItemStack itemStack) {
        return getEmptySpace(player.getInventory(), itemStack);
    }

    /**
     * @param inventory Inventory to search in
     * @param itemStack The item that you need to search for a free place for
     * @return Returns the amount of free space for the specified item
     */
    public static int getEmptySpace(Inventory inventory, ItemStack itemStack) {
        int emptySpace = 0;
        for (ItemStack checkItem : inventory.getContents()) {
            if (ItemStackHelper.isNullable(checkItem)) {
                emptySpace += itemStack.getMaxStackSize();
                continue;
            }

            if (!checkItem.isSimilar(itemStack)) {
                continue;
            }

            if (checkItem.getMaxStackSize() <= 1) {
                continue;
            }

            if (checkItem.getAmount() >= checkItem.getMaxStackSize()) {
                continue;
            }

            emptySpace += (checkItem.getMaxStackSize() - checkItem.getAmount());
        }

        return emptySpace;
    }
}

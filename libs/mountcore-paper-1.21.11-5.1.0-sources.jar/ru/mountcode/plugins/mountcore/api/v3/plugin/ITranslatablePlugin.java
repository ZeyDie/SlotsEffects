package ru.mountcode.plugins.mountcore.api.v3.plugin;

/**
 * Says for plugin has translations and translations must be loaded in automatic mode
 * Говорит, что плагин содержит переводы и переводы должны быть загружены в автоматическом режиме
 * <p>
 * <b>Требования для плагина реализующего интерфейс автоматической загрузки переводов:</b>
 * <ul>
 *     <li>Файлы переводов должны находиться в jar файле в папку translations и иметь формат названия language_язык_СТРАНА.properties</li>
 *     <li>Все ключи переводов должны содержать название плагина маленькими буквами как префикс (Пример: mountcore.enabled=Включён),
 *  для того, чтобы исключить возможную коллизию переводов между плагинами. Если же будет найден ключ перевода без префикса,
 *  то он в автоматическом режиме будет добавлен.</li>
 * </ul>
 */
@Deprecated(forRemoval = true, since = "5.0.0")
public interface ITranslatablePlugin {


    default void reloadTranslations() {

    }
}

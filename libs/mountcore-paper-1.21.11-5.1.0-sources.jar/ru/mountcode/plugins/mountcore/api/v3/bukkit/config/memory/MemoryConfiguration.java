package ru.mountcode.plugins.mountcore.api.v3.bukkit.config.memory;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.apache.commons.lang3.Validate;
import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.configuration.file.YamlConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;

@Deprecated(forRemoval = true, since = "5.0.0")
@RequiredArgsConstructor
public class MemoryConfiguration {

    private static final Logger LOGGER = LoggerFactory.getLogger(MemoryConfiguration.class);

    @Getter
    private final Path configurationFilePath;
    @Getter
    @Setter
    private URL defaultConfig = null;
    private YamlConfiguration configuration;

    public void reload() {
        initialize();
    }

    public void save() {
        Validate.notNull(this.configurationFilePath, "Configuration file can not be null");
        if (isInfrastructureUnloaded()) {
            loadInfrastructure();
        }

        try {
            configuration.save(this.configurationFilePath.toFile());
        } catch (IOException exception) {
            LOGGER.error("Error on saving configuration: {}", this.configurationFilePath.getFileName(), exception);
        }
    }

    public void initialize() {
        if (!Files.exists(this.configurationFilePath)) {
            generate();
        }

        loadConfiguration();
    }

    private void generate() {
        Validate.notNull(this.configurationFilePath, "Configuration file can not be null");
        try {
            Files.createDirectories(this.configurationFilePath.getParent());
        } catch (IOException e) {
            LOGGER.error("Can not creating directories to config file: {}", this.configurationFilePath.toAbsolutePath(), e);
        }

        if (this.configuration == null) {
            this.configuration = new YamlConfiguration();
        }

        if (this.defaultConfig == null) {
            this.configuration.options().copyDefaults(true);
            save();
            return;
        }

        try (OutputStream outputStream = Files.newOutputStream(this.configurationFilePath)) {
            try (InputStream inputStream = this.defaultConfig.openStream()) {
                byte[] buffer = new byte[1024];

                int length;
                while ((length = inputStream.read(buffer)) > 0) {
                    outputStream.write(buffer, 0, length);
                }
            }
        } catch (IOException e) {
            LOGGER.error("Can not generate config file: {}", this.configurationFilePath.getFileName(), e);
        }
    }

    private void loadConfiguration() {
        Validate.notNull(this.configurationFilePath, "File cannot be null");
        if (this.configuration == null) {
            this.configuration = new YamlConfiguration();
        }

        try {
            this.configuration.load(this.configurationFilePath.toFile());
        } catch (IOException | InvalidConfigurationException exception) {
            LOGGER.error("Can not load configuration: {}", this.configurationFilePath.getFileName(), exception);
        }
    }

    public void loadInfrastructure() {
        initialize();
    }

    public void unloadInfrastructure() {
        this.configuration = null;
    }

    public boolean isInfrastructureUnloaded() {
        return this.configuration == null;
    }

    public YamlConfiguration getConfiguration() {
        if (isInfrastructureUnloaded()) {
            this.loadInfrastructure();
        }
        return configuration;
    }
}

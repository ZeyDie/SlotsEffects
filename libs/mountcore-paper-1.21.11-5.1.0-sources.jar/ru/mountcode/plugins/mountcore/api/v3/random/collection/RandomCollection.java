package ru.mountcode.plugins.mountcore.api.v3.random.collection;

import java.util.Random;
import java.util.TreeMap;
import java.util.random.RandomGenerator;


/**
 * Класс {@code RandomCollection} позволяет добавлять объекты с заданными шансами и случайным образом выбирать один
 * из добавленных объектов на основе этих шансов.
 * <p>
 * Каждый объект имеет вероятность (шанс) быть выбранным. Выбор происходит на основе суммарной вероятности всех
 * добавленных объектов, используя генератор случайных чисел.
 * </p>
 *
 * @param <T> тип объектов, которые будут добавлены в коллекцию.
 *
 * @deprecated Use {@link ru.mountcode.plugins.mountcore.api.collection.v1.RandomCollection}
 */
@Deprecated(forRemoval = true, since = "5.0.0")
public class RandomCollection<T> {

    /**
     * Генератор случайных чисел по умолчанию, используемый при создании экземпляра {@code RandomCollection}
     * без явного указания генератора.
     */
    private static final RandomGenerator DEFAULT_RANDOM_GENERATOR = new Random();

    /**
     * Карта для хранения объектов и их соответствующих порогов вероятности.
     * Ключом является кумулятивная сумма шансов, значением - объект, связанный с этим шансом.
     */
    private final TreeMap<Double, T> map;

    /**
     * Генератор случайных чисел, используемый для выбора объектов.
     */
    private final RandomGenerator randomGenerator;

    /**
     * Общая сумма всех шансов, добавленных в коллекцию.
     */
    private double total;

    /**
     * Создает новый экземпляр {@code RandomCollection} с генератором случайных чисел по умолчанию.
     */
    public RandomCollection() {
        this(DEFAULT_RANDOM_GENERATOR);
    }

    /**
     * Создает новый экземпляр {@code RandomCollection} с заданным генератором случайных чисел.
     *
     * @param randomGenerator генератор случайных чисел, который будет использоваться для выбора объектов.
     */
    public RandomCollection(RandomGenerator randomGenerator) {
        this.map = new TreeMap<>();
        this.total = 0.0;
        this.randomGenerator = randomGenerator;
    }

    /**
     * Добавляет объект в коллекцию с указанным шансом.
     *
     * @param chance шанс выбора объекта. Должен быть больше 0.0. Шансы добавляются к общей сумме вероятностей.
     * @param object объект, который будет добавлен в коллекцию для случайного выбора.
     */
    public void add(double chance, T object) {
        if (chance > 0.0) {
            this.total += chance;
            this.map.put(this.total, object);
        }
    }

    /**
     * Выбирает случайный объект из коллекции на основе добавленных шансов.
     * <p>
     * Метод использует генератор случайных чисел для выбора порогового значения из диапазона [0, общая сумма шансов),
     * и возвращает объект, соответствующий этому значению.
     * </p>
     *
     * @return случайно выбранный объект на основе добавленных шансов.
     * @throws IllegalStateException если коллекция пуста и нет доступных объектов для выбора.
     */
    public T next() {
        if (this.map.isEmpty()) {
            throw new IllegalStateException("The collection is empty and cannot return a random object.");
        }
        return this.map.ceilingEntry(this.randomGenerator.nextDouble() * this.total).getValue();
    }
}

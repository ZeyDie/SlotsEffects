package ru.mountcode.plugins.mountcore.api.v3.async;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

@Deprecated(forRemoval = true, since = "5.0.0")
public class AsyncIO {

    private static final Logger LOGGER = LoggerFactory.getLogger(AsyncIO.class);

    public static void writeString(Path path, String string) {
        writeString(path, string, StandardCharsets.UTF_8);
    }

    public static void writeString(Path path, String string, java.nio.charset.Charset encoding) {
        GlobalExecutors.writingIO().execute(() -> {
            try {
                Files.writeString(path, string, encoding);
            } catch (Exception e) {
                LOGGER.error("Exception when async writing string to file: {}", path.toAbsolutePath(), e);
            }
        });
    }

    public static void writeBytes(Path path, byte[] data) {
        GlobalExecutors.writingIO().execute(() -> {
            try {
                Files.write(path, data);
            } catch (Exception e) {
                LOGGER.error("Exception when async writing bytes to file: {}", path.toAbsolutePath(), e);
            }
        });
    }
}

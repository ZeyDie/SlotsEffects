package ru.mountcode.plugins.mountcore.api.v3.datetime;

import java.time.Duration;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Deprecated(forRemoval = true, since = "5.0.0")
public class DurationHelper {

    private static final Pattern DURATION_PATTERN = Pattern.compile(
            "(\\d+)\\s*(year|years|y|г|л|год|года|лет)?\\s*" +
                    "(\\d+)?\\s*(month|months|месяц|месяца|месяцев)?\\s*" +
                    "(\\d+)?\\s*(week|weeks|н|w|неделя|недели|недель)?\\s*" +
                    "(\\d+)?\\s*(day|days|d|д|день|дня|дней)?\\s*" +
                    "(\\d+)?\\s*(min|minute|minutes|мин|минута|минуты|минут)?\\s*" +
                    "(\\d+)?\\s*(sec|second|с|s|seconds|сек|секунда|секунды|секунд)?");

    /**
     * Парсит строку с указанием продолжительности времени и возвращает объект {@link Duration}.
     * <p>
     * Поддерживаемые единицы времени, которые могут быть указаны в строке:
     * <ul>
     *     <li><b>Годы</b>: year, years, y, г, л, год, года, лет</li>
     *     <li><b>Месяцы</b>: month, months, месяц, месяца, месяцев</li>
     *     <li><b>Недели</b>: week, weeks, н, w, неделя, недели, недель</li>
     *     <li><b>Дни</b>: day, days, d, д, день, дня, дней</li>
     *     <li><b>Минуты</b>: min, minute, minutes, мин, минута, минуты, минут</li>
     *     <li><b>Секунды</b>: sec, second, s, с, seconds, сек, секунда, секунды, секунд</li>
     * </ul>
     * <p>
     * Пример строки: "1 год 2 месяца 3 недели 4 дня 5 минут 6 секунд"
     * <p>
     * Строка может содержать любое сочетание этих единиц времени, включая только одну единицу, например "2 часа".
     *
     * @param duration строка, содержащая описание продолжительности времени.
     * @return объект {@link Duration}, представляющий общую продолжительность времени, указанную в строке. Все временные единицы
     *         преобразуются в секунды.
     * @throws NumberFormatException если какая-либо из частей строки содержит некорректное числовое значение.
     */
//    public static Duration parseDuration(String duration) {
//        Matcher matcher = DURATION_PATTERN.matcher(duration);
//        int years = 0, months = 0, weeks = 0, days = 0, minutes = 0, seconds = 0;
//
//        if (matcher.find()) {
//            if (matcher.group(1) != null) {
//                years = Integer.parseInt(matcher.group(1));
//            }
//            if (matcher.group(3) != null) {
//                months = Integer.parseInt(matcher.group(3));
//            }
//            if (matcher.group(5) != null) {
//                weeks = Integer.parseInt(matcher.group(5));
//            }
//            if (matcher.group(7) != null) {
//                days = Integer.parseInt(matcher.group(7));
//            }
//            if (matcher.group(9) != null) {
//                minutes = Integer.parseInt(matcher.group(9));
//            }
//            if (matcher.group(11) != null) {
//                seconds = Integer.parseInt(matcher.group(11));
//            }
//        }
//
//        // Преобразуем все в секунды (год = 365 дней, месяц = 30 дней, неделя = 7 дней)
//        long totalSeconds = Duration.ofDays(years * 365L).getSeconds() +
//                Duration.ofDays(months * 30L).getSeconds() +
//                Duration.ofDays(weeks * 7L).getSeconds() +
//                Duration.ofDays(days).getSeconds() +
//                Duration.ofMinutes(minutes).getSeconds() +
//                seconds;
//
//        return Duration.ofSeconds(totalSeconds);
//    }

    public static Duration parseDuration(String duration) {
        int years = 0, months = 0, weeks = 0, days = 0, minutes = 0, seconds = 0;

        String[] parts = duration.split("\\s+");
        for (int i = 0; i < parts.length; i++) {
            String value = parts[i];
            int amount;

            try {
                amount = Integer.parseInt(value); // Пробуем распарсить количество
            } catch (NumberFormatException e) {
                continue; // Если это не число, идем дальше
            }

            if (i + 1 < parts.length) {
                String unit = parts[i + 1].toLowerCase();

                if (unit.equals("year") || unit.equals("years") || unit.equals("y") ||
                        unit.equals("г") || unit.equals("л") || unit.equals("год") ||
                        unit.equals("года") || unit.equals("лет")) {
                    years = amount;
                    i++; // Пропускаем единицу измерения
                } else if (unit.equals("month") || unit.equals("months") ||
                        unit.equals("месяц") || unit.equals("месяца") ||
                        unit.equals("месяцев")) {
                    months = amount;
                    i++;
                } else if (unit.equals("week") || unit.equals("weeks") || unit.equals("w") ||
                        unit.equals("н") || unit.equals("неделя") ||
                        unit.equals("недели") || unit.equals("недель")) {
                    weeks = amount;
                    i++;
                } else if (unit.equals("day") || unit.equals("days") || unit.equals("d") ||
                        unit.equals("д") || unit.equals("день") ||
                        unit.equals("дня") || unit.equals("дней")) {
                    days = amount;
                    i++;
                } else if (unit.equals("min") || unit.equals("minute") ||
                        unit.equals("minutes") || unit.equals("мин") ||
                        unit.equals("минута") || unit.equals("минуты") ||
                        unit.equals("минут")) {
                    minutes = amount;
                    i++;
                } else if (unit.equals("sec") || unit.equals("second") ||
                        unit.equals("seconds") || unit.equals("s") ||
                        unit.equals("с") || unit.equals("сек") ||
                        unit.equals("секунда") || unit.equals("секунды") ||
                        unit.equals("секунд")) {
                    seconds = amount;
                    i++;
                }
            }
        }

        // Преобразуем все в секунды (год = 365 дней, месяц = 30 дней, неделя = 7 дней)
        long totalSeconds = Duration.ofDays(years * 365L).getSeconds() +
                Duration.ofDays(months * 30L).getSeconds() +
                Duration.ofDays(weeks * 7L).getSeconds() +
                Duration.ofDays(days).getSeconds() +
                Duration.ofMinutes(minutes).getSeconds() +
                seconds;

        return Duration.ofSeconds(totalSeconds);
    }
}


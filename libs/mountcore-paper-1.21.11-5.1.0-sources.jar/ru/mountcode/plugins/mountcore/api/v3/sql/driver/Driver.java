package ru.mountcode.plugins.mountcore.api.v3.sql.driver;

import com.zaxxer.hikari.HikariConfig;

@Deprecated(forRemoval = true, since = "4.0.0")
public abstract class Driver {

    public abstract String getUrl();

    public abstract String getUsername();
    public abstract String getPassword();

    public HikariConfig configureHikari() {
        HikariConfig config = new HikariConfig();
        config.setJdbcUrl(this.getUrl());
        config.setUsername(this.getUsername());
        config.setPassword(this.getPassword());

        config.addDataSourceProperty("cachePrepStmts", "true");
        config.addDataSourceProperty("prepStmtCacheSize", "250");
        config.addDataSourceProperty("prepStmtCacheSqlLimit", "2048");

        return config;
    }
}

package ru.mountcode.plugins.mountcore.api.v3.bukkit.text;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;

/**
 * @deprecated Not using Boxing of MiniMessage instance.
 */
@Deprecated(forRemoval = true, since = "5.0.0")
public class MiniMessages {

    public static Component parseMiniMessage(String rawMessage) {
        return MiniMessage.miniMessage().deserialize(rawMessage);
    }
}

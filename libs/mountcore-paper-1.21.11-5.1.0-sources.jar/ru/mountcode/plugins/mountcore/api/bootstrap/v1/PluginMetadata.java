package ru.mountcode.plugins.mountcore.api.bootstrap.v1;

import lombok.Builder;
import org.jspecify.annotations.NonNull;

/**
 * Represents metadata for a MountCore plugin.
 * <p>
 * Contains basic identifying information such as plugin name and version.
 *
 * @param name    plugin name
 * @param version plugin version
 * @since 5.0.0
 */
@Builder
public record PluginMetadata(@NonNull String name, @NonNull String version) {

    /**
     * Returns a formatted display name in the format "name@version".
     *
     * @return the formatted plugin name and version
     * @since 5.0.0
     */
    public String displayName() {
        return this.name + "@" + this.version;
    }
}

package ru.mountcode.plugins.mountcore.api.bootstrap.v1.module;

import lombok.Getter;
import org.jspecify.annotations.NonNull;
import ru.mountcode.plugins.mountcore.api.bootstrap.v1.IMountPlugin;

/**
 * Represents a modular unit of a plugin that can be enabled, disabled,
 * and optionally reloaded. Modules encapsulate isolated functionality
 * that extends a plugin’s capabilities.
 * <p>
 * Example usage:
 * <pre>{@code
 * public class ExampleModule extends PluginModule {
 *
 *     public ExampleModule(IMountPlugin plugin) {
 *         super(plugin);
 *     }
 *
 *     @Override
 *     public void enable() {
 *         getPlugin().logger().info("ExampleModule enabled.");
 *     }
 *
 *     @Override
 *     public void shutdown() {
 *         getPlugin().logger().info("ExampleModule disabled.");
 *     }
 *
 *     @Override
 *     public @NonNull String getName() {
 *         return "ExampleModule";
 *     }
 * }
 * }</pre>
 *
 * @since 5.0.0
 */
public abstract class PluginModule {

    @Getter
    private final IMountPlugin plugin;

    /**
     * Constructs a plugin module with a reference to its parent plugin.
     *
     * @param plugin parent plugin instance
     * @since 5.0.0
     */
    public PluginModule(IMountPlugin plugin) {
        this.plugin = plugin;
    }


    /**
     * Called when the module is being enabled.
     *
     * @since 5.0.0
     */
    public abstract void enable();

    /**
     * Called when the module is being shut down.
     *
     * @since 5.0.0
     */
    public abstract void shutdown();

    /**
     * Returns the unique name of the module.
     *
     * @return module name
     * @since 5.0.0
     */
    @NonNull
    public abstract String getName();

    /**
     * Returns array of depended module names
     *
     * @return depended module names
     * @since 5.0.3
     */
    @NonNull
    public String[] getDependencies() {
        return new String[0];
    }


    /**
     * Returns the reloadability of the module
     *
     * @return {@code true} if  module is reloadable
     * @since 5.0.18
     */
    public boolean isReloadable() {
        return this instanceof IReloadableModule;
    }
}

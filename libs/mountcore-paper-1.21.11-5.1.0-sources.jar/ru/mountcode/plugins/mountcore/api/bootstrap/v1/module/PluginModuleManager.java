package ru.mountcode.plugins.mountcore.api.bootstrap.v1.module;

import lombok.AccessLevel;
import lombok.Getter;
import org.jspecify.annotations.NonNull;
import ru.mountcode.plugins.mountcore.api.bootstrap.v1.IMountPlugin;
import ru.mountcode.plugins.mountcore.api.bootstrap.v1.module.dependency.DependencyGraph;
import ru.mountcode.plugins.mountcore.api.translation.v1.TranslationPluginModule;

import java.util.*;


/**
 * Manages all registered plugin modules, including their lifecycle and reload operations.
 * <p>
 * Provides functionality to register, unregister, and reload modules dynamically.
 * Also handles the registration of built-in modules such as translations.
 *
 * @since 5.0.0
 */
public final class PluginModuleManager {

    @Getter(value = AccessLevel.PROTECTED)
    private final IMountPlugin plugin;

    private final Map<String, PluginModule> modules = new HashMap<>();

    /**
     * Creates a new module manager for the given plugin.
     *
     * @param plugin the parent plugin instance
     * @since 5.0.0
     */
    public PluginModuleManager(IMountPlugin plugin) {
        this.plugin = plugin;
    }

    /**
     * Registers and enables a new module.
     *
     * @param module the module to register
     * @return {@code true} if the module was successfully registered, {@code false} if already present
     * @throws PluginModuleException when dependency module not registered required by module
     * @since 5.0.0
     */
    public boolean registerModule(PluginModule module) {
        if (modules.containsKey(module.getName())) {
            return false;
        }

        for (String dependency : module.getDependencies()) {
            if (!this.modules.containsKey(dependency)) {
                throw new PluginModuleException("Module " + module.getName() + " requires dependency " + dependency);
            }
        }

        // Проверяем циклические зависимости
        List<String> cyclePath = detectCycle(module);
        if (cyclePath != null) {
            String pathStr = String.join(" -> ", cyclePath);
            throw new PluginModuleException("Cyclic dependency registering detected: " + pathStr);
        }

        modules.put(module.getName(), module);
        module.enable();
        return true;
    }

    /**
     * Unregisters and shuts down a module by name.
     *
     * @param moduleName the name of the module
     * @return {@code true} if the module was unregistered successfully
     * @throws PluginModuleException when module is required by registered modules
     * @since 5.0.0
     */
    public boolean unregisterModule(String moduleName) {
        if (!modules.containsKey(moduleName)) {
            return false;
        }

        PluginModule module = modules.get(moduleName);
        for (Map.Entry<String, PluginModule> entry : modules.entrySet()) {
            if (entry.getValue().getName().equals(moduleName)) {
                continue;
            }

            String[] dependencies = entry.getValue().getDependencies();
            for (String dependency : dependencies) {
                if (moduleName.equals(dependency)) {
                    throw new PluginModuleException("A module " + moduleName + " cannot be unregistered while module " + entry.getKey() + " that require it as a dependency are registered");
                }
            }
        }

        modules.remove(moduleName);
        module.shutdown();
        return true;
    }

    /**
     * Reloads all modules that implement {@link IReloadableModule}.
     *
     * @return {@code true} if all reloadable modules reloaded successfully
     * @since 5.0.0
     */
    public boolean reloadModules() {
        DependencyGraph graph = new DependencyGraph(modules).build();

        boolean success = true;
        for (String moduleName : graph.getTopologicalModules()) {
            PluginModule module = modules.get(moduleName);

            if (!module.isReloadable()) {
                continue;
            }

            if (!((IReloadableModule) module).reload()) {
                success = false;
            }
        }

        return success;
    }

    /**
     * Checks for the presence of a registered module
     *
     * @param moduleName the name of the module
     * @return {@code true} if the module exists
     * @since 5.0.18
     */
    public boolean existsModule(@NonNull String moduleName) {
        return this.modules.containsKey(moduleName);
    }

    /**
     * Getting registered plugin module
     *
     * @param moduleName the name of the module
     * @return plugin module when it registered
     * @since 5.0.18
     */
    public Optional<PluginModule> getModule(@NonNull String moduleName) {
        return Optional.ofNullable(this.modules.get(moduleName));
    }

    /**
     * Retrieves a list of all modules.
     *
     * @return an unmodifiable list of all modules
     * @since 5.0.18
     */
    public Collection<PluginModule> getModules() {
        return Collections.unmodifiableCollection(this.modules.values());
    }

    /**
     * Reloads a specific module by name, if it supports reloading.
     *
     * @param moduleName the name of the module
     * @return {@code true} if the module was reloaded successfully
     * @since 5.0.0
     */
    public boolean reloadModule(String moduleName) {
        if (!modules.containsKey(moduleName)) {
            return false;
        }

        PluginModule currentModule = this.modules.get(moduleName);
        if (!currentModule.isReloadable()) {
            return false;
        }

        DependencyGraph graph = new DependencyGraph(this.modules).build();

        boolean success = true;
        for (String name : graph.getTopologicalModulesFor(moduleName)) {
            PluginModule module = modules.get(name);
            if (!module.isReloadable()) {
                continue;
            }

            if (!((IReloadableModule) module).reload()) {
                success = false;
            }
        }


        return success;
    }

    /**
     * Retrieves a list of names of all reloadable modules.
     *
     * @return an unmodifiable list of reloadable module names
     * @since 5.0.0
     */
    @NonNull
    public List<String> getReloadableModules() {
        List<String> list = new ArrayList<>();
        for (PluginModule module : modules.values()) {
            if (module.isReloadable()) {
                list.add(module.getName());
            }
        }

        return Collections.unmodifiableList(list);
    }

    /**
     * Registers the built-in {@link TranslationPluginModule}.
     *
     * @since 5.0.0
     */
    public void registerTranslationModule() {
        this.registerModule(new TranslationPluginModule(this.getPlugin()));
    }

    private List<String> detectCycle(PluginModule module) {
        Deque<String> path = new ArrayDeque<>();
        Set<String> visited = new HashSet<>();
        return detectCycleRecursive(module, path, visited);
    }

    private List<String> detectCycleRecursive(PluginModule current,
                                              Deque<String> path,
                                              Set<String> visited) {
        String currentName = current.getName();

        // Если модуль уже есть в текущем пути — цикл найден
        if (path.contains(currentName)) {
            List<String> cycle = new ArrayList<>(path);
            cycle.add(currentName); // замыкаем цикл
            return cycle;
        }

        // Если уже проверен ранее — пропускаем
        if (visited.contains(currentName)) {
            return null;
        }

        visited.add(currentName);
        path.addLast(currentName);

        for (String dependencyName : current.getDependencies()) {
            PluginModule dependency = modules.get(dependencyName);
            if (dependency == null) continue; // пропускаем не зарегистрированные

            List<String> result = detectCycleRecursive(dependency, path, visited);
            if (result != null) {
                return result;
            }
        }

        path.removeLast();
        return null;
    }
}

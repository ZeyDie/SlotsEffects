package ru.mountcode.plugins.mountcore.api.bootstrap.v1.module;

/**
 * Represents a module that supports reloading.
 * <p>
 * A reloadable module should implement this interface to define how
 * its internal state or configuration can be refreshed without full restart.
 * </p>
 *
 * Example usage:
 * <pre>{@code
 * public class ConfigModule extends PluginModule implements IReloadableModule {
 *
 *     public ConfigModule(IMountPlugin plugin) {
 *         super(plugin);
 *     }
 *
 *     @Override
 *     public boolean reload() {
 *         // Reload configuration
 *         getPlugin().logger().info("Configuration reloaded.");
 *         return true;
 *     }
 * }
 * }</pre>
 *
 * @since 5.0.0
 */
public interface IReloadableModule {

    /**
     * Reloads the module state or configuration.
     *
     * @return {@code true} if reload succeeded
     * @since 5.0.0
     */
    boolean reload();
}

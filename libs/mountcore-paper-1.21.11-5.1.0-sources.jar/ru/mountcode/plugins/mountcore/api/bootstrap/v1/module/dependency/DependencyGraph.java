package ru.mountcode.plugins.mountcore.api.bootstrap.v1.module.dependency;

import lombok.Getter;
import lombok.NonNull;
import ru.mountcode.plugins.mountcore.api.bootstrap.v1.module.PluginModule;

import java.util.*;

public final class DependencyGraph {

    private final Map<String, PluginModule> modules;
    private final Map<String, Node> nodes = new HashMap<>();
    private final Map<String, Node> roots = new LinkedHashMap<>();

    public DependencyGraph(@NonNull Map<String, PluginModule> modules) {
        this.modules = modules;
    }

    public DependencyGraph build() {
        nodes.clear();
        roots.clear();

        // 1. Инициализация всех узлов
        for (PluginModule module : modules.values()) {
            nodes.computeIfAbsent(module.getName(), n -> new Node(module));
        }

        // 2. Построение связей (обратных зависимостей)
        for (PluginModule module : modules.values()) {
            Node node = nodes.get(module.getName());
            for (String dependencyName : module.getDependencies()) {
                Node dependencyNode = nodes.get(dependencyName);
                dependencyNode.children.add(node); // reversed: dependency → dependent
                node.parents.add(dependencyNode);
            }
        }

        // 3. Определяем корни (модули без родителей)
        for (Node node : nodes.values()) {
            if (node.parents.isEmpty()) {
                roots.put(node.module.getName(), node);
            }
        }

        return this;
    }

    /**
     * Возвращает список имён модулей в порядке обхода графа (топологическая сортировка).
     * Независимые модули идут первыми, зависимые — после них.
     *
     */
    public List<String> getTopologicalModules() {
        List<String> result = new ArrayList<>();
        Set<String> visited = new HashSet<>();

        for (Node root : roots.values()) {
            traverse(root, visited, result);
        }

        // если по каким-то причинам остались "висячие" модули (без корня)
        // добавляем их тоже (чтобы вернуть полный список)
        for (Node node : nodes.values()) {
            if (!visited.contains(node.getName())) {
                traverse(node, visited, result);
            }
        }

        Collections.reverse(result);
        return result;
    }

    /**
     * Возвращает список имён модулей, достижимых из заданного модуля (включая его самого).
     * Использует обратный граф (B → A означает, что A зависит от B).
     *
     * @param moduleName имя исходного модуля
     * @return список имён модулей, достижимых из указанного
     */
    public List<String> getTopologicalModulesFor(@NonNull String moduleName) {
        Node startNode = nodes.get(moduleName);
        if (startNode == null) {
            throw new IllegalArgumentException("Module not found in dependency graph: " + moduleName);
        }

        List<String> result = new ArrayList<>();
        Set<String> visited = new HashSet<>();

        traverse(startNode, visited, result);

        Collections.reverse(result);
        return result;
    }

    /**
     * Рекурсивный обход графа (DFS) — добавляет модули в топологическом порядке.
     */
    private void traverse(Node node, Set<String> visited, List<String> result) {
        if (!visited.add(node.getName())) return;
        for (Node child : node.getChildren()) {
            traverse(child, visited, result);
        }
        result.add(node.getName());
    }

    public static class Node {

        @Getter
        private final PluginModule module;
        private final Set<Node> parents = new LinkedHashSet<>();
        private final Set<Node> children = new LinkedHashSet<>();

        private Node(PluginModule module) {
            this.module = module;
        }

        public String getName() {
            return module.getName();
        }

        public Set<Node> getParents() {
            return Collections.unmodifiableSet(parents);
        }

        public Set<Node> getChildren() {
            return Collections.unmodifiableSet(children);
        }

        @Override
        public String toString() {
            return module.getName();
        }
    }
}

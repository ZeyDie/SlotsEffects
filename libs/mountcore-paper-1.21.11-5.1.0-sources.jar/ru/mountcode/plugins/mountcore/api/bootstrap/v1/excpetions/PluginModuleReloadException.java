package ru.mountcode.plugins.mountcore.api.bootstrap.v1.excpetions;

import org.jspecify.annotations.NonNull;
import ru.mountcode.plugins.mountcore.api.bootstrap.v1.IMountPlugin;
import ru.mountcode.plugins.mountcore.api.bootstrap.v1.module.PluginModule;

/**
 * Exception thrown to indicate that an error occurred during the reload
 * process of a plugin module.
 *
 * <p>This exception is typically used to wrap and propagate issues related
 * to dynamic reloading mechanisms, such as configuration inconsistencies,
 * resource loading failures, or lifecycle management errors.
 *
 * <p>As a {@link RuntimeException}, it is unchecked and does not require
 * explicit handling, allowing it to bubble up through the call stack
 * when a critical reload failure occurs.
 *
 * @since 5.0.18
 */
public class PluginModuleReloadException extends RuntimeException {

    public PluginModuleReloadException(@NonNull String message) {
        super(message);
    }

    public PluginModuleReloadException(@NonNull PluginModule module, @NonNull  IMountPlugin plugin) {
        super("Error while reloading the " + module.getName() + " module in " + plugin.getPluginMetadata().displayName() + " plugin");
    }
}

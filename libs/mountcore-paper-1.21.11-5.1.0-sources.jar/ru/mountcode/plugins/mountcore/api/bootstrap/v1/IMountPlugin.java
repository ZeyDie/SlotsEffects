package ru.mountcode.plugins.mountcore.api.bootstrap.v1;

import net.kyori.adventure.text.Component;
import org.jspecify.annotations.NonNull;
import org.slf4j.Logger;
import ru.mountcode.plugins.mountcore.api.bootstrap.v1.module.PluginModuleManager;
import ru.mountcode.plugins.mountcore.api.command.v1.CommandRegistrar;

import java.nio.file.Path;

/**
 * Represents the core interface for MountCore plugins.
 * <p>
 * Each plugin must implement this interface to properly integrate into
 * the MountCore bootstrap system. The lifecycle of a plugin includes
 * construction, enabling, reloading, and shutdown phases.
 * </p>
 *
 * <p>It also provides access to plugin-specific metadata, settings, modules,
 * and logging mechanisms.</p>
 *
 * @since 5.0.0
 */
public interface IMountPlugin {

    /**
     * Returns the plugin settings used for configuration and directory management.
     *
     * @return the plugin settings
     * @since 5.0.0
     */
    @NonNull
    PluginSettings getSettings();

    /**
     * Returns the path to the directory where the plugin data is stored.
     *
     * @return plugin directory path
     * @since 5.0.0
     */
    @NonNull
    Path getPluginDirectory();

    /**
     * Returns the metadata describing the plugin.
     *
     * @return plugin metadata
     * @since 5.0.0
     */
    @NonNull
    PluginMetadata getPluginMetadata();

    /**
     * Returns the module manager that controls plugin modules.
     *
     * @return the plugin module manager
     * @since 5.0.0
     */
    PluginModuleManager getModuleManager();

    /**
     * Returns the command registrar that controls plugin commands.
     *
     * @return the plugin command registrar
     * @since 5.0.5
     */
    CommandRegistrar<?> getCommandRegistrar();

    /**
     * Allows customization of plugin settings before initialization.
     * This method can be overridden to adjust the default builder configuration.
     *
     * @param builder the settings builder
     * @return modified or same builder instance
     * @since 5.0.0
     */
    default PluginSettings.PluginSettingsBuilder configurePluginSettings(PluginSettings.@NonNull PluginSettingsBuilder builder) {
        return builder;
    }

    /**
     * Returns the SLF4J logger instance for this plugin.
     *
     * @return logger instance
     * @since 5.0.0
     */
    Logger logger();

    /**
     * Prints the current plugin state as a formatted message.
     *
     * @param component the component representing the state message
     * @since 5.0.0
     */
    void printState(Component component);

    /**
     * Called during the plugin construction phase.
     * Use this for initialization logic before enabling the plugin.
     *
     * @since 5.0.0
     */
    void construct();

    /**
     * Called when the plugin is being enabled.
     * Typically used for registering listeners, commands, or modules.
     *
     * @since 5.0.0
     */
    void enable();

    /**
     * Called when the plugin is being disabled or unloaded.
     * Use this method to release resources or save persistent data.
     *
     * @since 5.0.0
     */
    void shutdown();

    /**
     * Called when the plugin needs to reload its configuration or modules.
     * Called after the plugin modules are reloaded.
     *
     * @since 5.0.0
     */
    void reload();
}

package ru.mountcode.plugins.mountcore.api.bootstrap.v1;

import lombok.Builder;
import lombok.Getter;
import org.jspecify.annotations.NonNull;

import java.nio.file.Path;

/**
 * Defines configuration settings for a plugin.
 * <p>
 * The settings are used to configure plugin behavior and specify directory paths.
 * </p>
 *
 * Example usage:
 * <pre>{@code
 * PluginSettings settings = PluginSettings.builder()
 *     .directory(Path.of("plugins/MyPlugin"))
 *     .stateLogging(true)
 *     .build();
 * }</pre>
 *
 * @since 5.0.0
 */
@Builder
@Getter
public class PluginSettings {

    /**
     * Whether to enable plugin state logging when enabling or disabling the plugin.
     *
     * @since 5.0.0
     */
    @Builder.Default
    private boolean stateLogging = true;

    /**
     * The directory path associated with the plugin.
     * Used for automatic operations such as localization or configuration management.
     *
     * @since 5.0.0
     */
    @NonNull
    private Path directory;

    /**
     * Builder class for constructing {@link PluginSettings} instances.
     *
     * @since 5.0.0
     */
    public static class PluginSettingsBuilder {
        // For lombok
    }
}

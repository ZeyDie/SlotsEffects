package ru.mountcode.plugins.mountcore.api.bootstrap.v1.module;

public class PluginModuleException extends RuntimeException {
    public PluginModuleException(String message) {
        super(message);
    }
}

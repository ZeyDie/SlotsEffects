package ru.mountcode.plugins.mountcore.api.configuration.v1;

import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;
import ru.mountcode.plugins.mountcore.api.configuration.v1.exception.InvalidConfigurationException;
import ru.mountcode.plugins.mountcore.api.configuration.v1.memory.MemoryConfiguration;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Path;

public interface ConfigurationLoader {
    @NonNull
    MemoryConfiguration load() throws InvalidConfigurationException, IOException;

    void save(@NonNull MemoryConfiguration configuration) throws IOException;

    @NonNull
    Path getPath();

    @Nullable
    URL getDefaultConfigurationURL();
}

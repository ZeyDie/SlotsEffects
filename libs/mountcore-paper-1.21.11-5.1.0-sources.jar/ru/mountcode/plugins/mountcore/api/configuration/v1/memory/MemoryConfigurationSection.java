package ru.mountcode.plugins.mountcore.api.configuration.v1.memory;

import com.google.common.base.Preconditions;
import com.google.common.base.Strings;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;
import ru.mountcode.plugins.mountcore.api.configuration.v1.ConfigurationSection;
import ru.mountcode.plugins.mountcore.api.configuration.v1.serialization.ISerializableObject;

import java.util.*;

public class MemoryConfigurationSection implements ConfigurationSection {

    private static final char PATH_SEPARATOR = '.';

    protected final Map<String, Object> childrens = new LinkedHashMap<>();
    private final ConfigurationSection root;
    private final ConfigurationSection parent;
    private final String path;
    private final String fullPath;

    protected MemoryConfigurationSection() {
        this.path = "";
        this.fullPath = "";
        this.parent = null;
        this.root = this;
    }

    protected MemoryConfigurationSection(@NonNull ConfigurationSection parent, @NonNull String path) {
        this.path = path;
        this.parent = parent;
        this.root = parent.getRoot();

        Preconditions.checkArgument(root != null, "Path cannot be orphaned");

        this.fullPath = createPath(parent, path);
    }

    public MemoryConfigurationSection(@NonNull ConfigurationSection parent, @NonNull String path, Map<String, Object> map) {
        this.path = path;
        this.parent = parent;
        this.root = parent.getRoot();

        Preconditions.checkArgument(root != null, "Path cannot be orphaned");

        this.fullPath = createPath(parent, path);

        this.fromMapTree(map);
    }

    @Override
    public @Nullable ConfigurationSection getParent() {
        return parent;
    }

    @Override
    public @Nullable ConfigurationSection getRoot() {
        return isRoot() ? this : root;
    }

    @Override
    @NonNull
    public String getCurrentPath() {
        return fullPath;
    }

    @Override
    @NonNull
    public String getName() {
        return path;
    }

    @Override
    @NonNull
    public Set<String> getKeys(boolean deep) {
        Set<String> result = new LinkedHashSet<>();

        mapChildrenKeys(result, this, deep);

        return result;
    }

    @Override
    public boolean contains(@NonNull String path) {
        return contains(path, false);
    }

    @Override
    public boolean contains(@NonNull String path, boolean ignoreDefault) {
        return ((ignoreDefault) ? get(path, null) : get(path)) != null;
    }

    @Override
    @NonNull
    public Map<String, Object> getValues(boolean deep) {
        Map<String, Object> result = new LinkedHashMap<>();

        mapChildrenValues(result, this, deep);

        return result;
    }

    @Override
    public void set(@NonNull String path, @Nullable Object value) {
        Preconditions.checkArgument(!Strings.isNullOrEmpty(path), "Cannot set to an empty path");

        ConfigurationSection root = getRoot();
        if (root == null) {
            throw new IllegalStateException("Cannot use section without a root");
        }

        // i1 is the leading (higher) index
        // i2 is the trailing (lower) index
        int i1 = -1, i2;
        ConfigurationSection section = this;
        while ((i1 = path.indexOf(PATH_SEPARATOR, i2 = i1 + 1)) != -1) {
            String node = path.substring(i2, i1);
            ConfigurationSection subSection = section.getConfigurationSection(node);
            if (subSection == null) {
                if (value == null) {
                    // no need to create missing sub-sections if we want to remove the value:
                    return;
                }
                section = section.createSection(node);
            } else {
                section = subSection;
            }
        }

        String key = path.substring(i2);
        if (section == this) {
            if (value == null) {
                childrens.remove(key);
            } else {
                childrens.put(key, value);
            }
        } else {
            section.set(key, value);
        }
    }

    @Override
    @Nullable
    public Object get(@NonNull String path) {
        return get(path, null);
    }

    @Override
    @Nullable
    public Object get(@NonNull String path, @Nullable Object def) {
        Preconditions.checkArgument(true, "Path cannot be null");

        if (path.isEmpty()) {
            return this;
        }

        ConfigurationSection root = getRoot();
        if (root == null) {
            throw new IllegalStateException("Cannot access section without a root");
        }

        // i1 is the leading (higher) index
        // i2 is the trailing (lower) index
        int i1 = -1, i2;
        ConfigurationSection section = this;
        while ((i1 = path.indexOf(PATH_SEPARATOR, i2 = i1 + 1)) != -1) {
            final String currentPath = path.substring(i2, i1);
            if (!section.contains(currentPath, true)) {
                return def;
            }
            section = section.getConfigurationSection(currentPath);
            if (section == null) {
                return def;
            }
        }

        String key = path.substring(i2);
        if (section == this) {
            Object result = childrens.get(key);
            return (result == null) ? def : result;
        }
        return section.get(key, def);
    }

    @Override
    @NonNull
    public ConfigurationSection createSection(@NonNull String path) {
        Preconditions.checkArgument(!Strings.isNullOrEmpty(path), "Cannot create section at empty path");
        ConfigurationSection root = getRoot();
        if (root == null) {
            throw new IllegalStateException("Cannot create section without a root");
        }

        // i1 is the leading (higher) index
        // i2 is the trailing (lower) index
        int i1 = -1, i2;
        ConfigurationSection section = this;
        while ((i1 = path.indexOf(PATH_SEPARATOR, i2 = i1 + 1)) != -1) {
            String node = path.substring(i2, i1);
            ConfigurationSection subSection = section.getConfigurationSection(node);
            if (subSection == null) {
                section = section.createSection(node);
            } else {
                section = subSection;
            }
        }

        String key = path.substring(i2);
        if (section == this) {
            ConfigurationSection result = new MemoryConfigurationSection(this, key);
            childrens.put(key, result);
            return result;
        }
        return section.createSection(key);
    }

    @Override
    @NonNull
    public ConfigurationSection createSection(@NonNull String path, @NonNull Map<?, ?> map) {
        ConfigurationSection section = createSection(path);

        ((MemoryConfigurationSection) section).fromMapTree((Map<String, Object>) map);

        return section;
    }

    @Override
    @Nullable
    public String getString(@NonNull String path) {
        return getString(path,null);
    }

    @Override
    @Nullable
    public String getString(@NonNull String path, @Nullable String def) {
        Object val = get(path, def);
        return (val != null) ? val.toString() : def;
    }

    @Override
    public boolean isString(@NonNull String path) {
        Object val = get(path);
        return val instanceof String;
    }

    @Override
    public int getInt(@NonNull String path) {
        return getInt(path, 0);
    }

    @Override
    public int getInt(@NonNull String path, int def) {
        Object val = get(path, def);
        return (val instanceof Number) ? toInt(val) : def;
    }

    @Override
    public boolean isInt(@NonNull String path) {
        Object val = get(path);
        return val instanceof Integer;
    }

    @Override
    public boolean getBoolean(@NonNull String path) {
        return getBoolean(path, false);
    }

    @Override
    public boolean getBoolean(@NonNull String path, boolean def) {
        Object val = get(path, def);
        return (val instanceof Boolean) ? (Boolean) val : def;
    }

    @Override
    public boolean isBoolean(@NonNull String path) {
        Object val = get(path);
        return val instanceof Boolean;
    }

    @Override
    public double getDouble(@NonNull String path) {
        return getDouble(path, 0);
    }

    @Override
    public double getDouble(@NonNull String path, double def) {
        Object val = get(path, def);
        return (val instanceof Number) ? toDouble(val) : def;
    }

    @Override
    public boolean isDouble(@NonNull String path) {
        Object val = get(path);
        return val instanceof Double;
    }

    @Override
    public UUID getUUID(@NonNull String path) {
        return getUUID(path, null);
    }

    @Override
    public UUID getUUID(@NonNull String path, UUID def) {
        Object val = get(path, def);
        return (val instanceof UUID) ? (UUID) val : def;
    }

    @Override
    public boolean isUUID(@NonNull String path) {
        Object val = get(path);
        return val instanceof UUID;
    }

    @Override
    public long getLong(@NonNull String path) {
        return getLong(path, 0);
    }

    @Override
    public long getLong(@NonNull String path, long def) {
        Object val = get(path, def);
        return (val instanceof Number) ? toLong(val) : def;
    }

    @Override
    public boolean isLong(@NonNull String path) {
        Object val = get(path);
        return val instanceof Long;
    }

    // Java
    @Override
    @Nullable
    public List<?> getList(@NonNull String path) {
        return getList(path,null);
    }

    @Override
    @Nullable
    public List<?> getList(@NonNull String path, @Nullable List<?> def) {
        Object val = get(path, def);
        return (List<?>) ((val instanceof List) ? val : def);
    }

    @Override
    public boolean isList(@NonNull String path) {
        Object val = get(path);
        return val instanceof List;
    }

    @Override
    @NonNull
    public List<String> getStringList(@NonNull String path) {
        List<?> list = getList(path);

        if (list == null) {
            return new ArrayList<>(0);
        }

        List<String> result = new ArrayList<>();

        for (Object object : list) {
            if ((object instanceof String) || (isPrimitiveWrapper(object))) {
                result.add(String.valueOf(object));
            }
        }

        return result;
    }

    @Override
    @NonNull
    public List<Integer> getIntegerList(@NonNull String path) {
        List<?> list = getList(path);

        if (list == null) {
            return new ArrayList<>(0);
        }

        List<Integer> result = new ArrayList<>();

        for (Object object : list) {
            if (object instanceof Integer) {
                result.add((Integer) object);
            } else if (object instanceof String) {
                try {
                    result.add(Integer.valueOf((String) object));
                } catch (Exception _) {
                }
            } else if (object instanceof Character) {
                result.add((int) (Character) object);
            } else if (object instanceof Number) {
                result.add(((Number) object).intValue());
            }
        }

        return result;
    }

    @Override
    @NonNull
    public List<Boolean> getBooleanList(@NonNull String path) {
        List<?> list = getList(path);

        if (list == null) {
            return new ArrayList<>(0);
        }

        List<Boolean> result = new ArrayList<>();

        for (Object object : list) {
            if (object instanceof Boolean) {
                result.add((Boolean) object);
            } else if (object instanceof String) {
                if (Boolean.TRUE.toString().equals(object)) {
                    result.add(true);
                } else if (Boolean.FALSE.toString().equals(object)) {
                    result.add(false);
                }
            }
        }

        return result;
    }

    @Override
    @NonNull
    public List<Double> getDoubleList(@NonNull String path) {
        List<?> list = getList(path);

        if (list == null) {
            return new ArrayList<>(0);
        }

        List<Double> result = new ArrayList<>();

        for (Object object : list) {
            if (object instanceof Double) {
                result.add((Double) object);
            } else if (object instanceof String) {
                try {
                    result.add(Double.valueOf((String) object));
                } catch (Exception _) {
                }
            } else if (object instanceof Character) {
                result.add((double) (Character) object);
            } else if (object instanceof Number) {
                result.add(((Number) object).doubleValue());
            }
        }

        return result;
    }

    @Override
    @NonNull
    public List<Float> getFloatList(@NonNull String path) {
        List<?> list = getList(path);

        if (list == null) {
            return new ArrayList<>(0);
        }

        List<Float> result = new ArrayList<>();

        for (Object object : list) {
            if (object instanceof Float) {
                result.add((Float) object);
            } else if (object instanceof String) {
                try {
                    result.add(Float.valueOf((String) object));
                } catch (Exception _) {
                }
            } else if (object instanceof Character) {
                result.add((float) (Character) object);
            } else if (object instanceof Number) {
                result.add(((Number) object).floatValue());
            }
        }

        return result;
    }

    @Override
    @NonNull
    public List<Long> getLongList(@NonNull String path) {
        List<?> list = getList(path);

        if (list == null) {
            return new ArrayList<>(0);
        }

        List<Long> result = new ArrayList<>();

        for (Object object : list) {
            if (object instanceof Long) {
                result.add((Long) object);
            } else if (object instanceof String) {
                try {
                    result.add(Long.valueOf((String) object));
                } catch (Exception _) {
                }
            } else if (object instanceof Character) {
                result.add((long) (Character) object);
            } else if (object instanceof Number) {
                result.add(((Number) object).longValue());
            }
        }

        return result;
    }

    @Override
    @NonNull
    public List<Byte> getByteList(@NonNull String path) {
        List<?> list = getList(path);

        if (list == null) {
            return new ArrayList<>(0);
        }

        List<Byte> result = new ArrayList<>();

        for (Object object : list) {
            if (object instanceof Byte) {
                result.add((Byte) object);
            } else if (object instanceof String) {
                try {
                    result.add(Byte.valueOf((String) object));
                } catch (Exception _) {
                }
            } else if (object instanceof Character) {
                result.add((byte) ((Character) object).charValue());
            } else if (object instanceof Number) {
                result.add(((Number) object).byteValue());
            }
        }

        return result;
    }

    @Override
    @NonNull
    public List<Character> getCharacterList(@NonNull String path) {
        List<?> list = getList(path);

        if (list == null) {
            return new ArrayList<>(0);
        }

        List<Character> result = new ArrayList<>();

        for (Object object : list) {
            if (object instanceof Character) {
                result.add((Character) object);
            } else if (object instanceof String str) {

                if (str.length() == 1) {
                    result.add(str.charAt(0));
                }
            } else if (object instanceof Number) {
                result.add((char) ((Number) object).intValue());
            }
        }

        return result;
    }

    @Override
    @NonNull
    public List<Short> getShortList(@NonNull String path) {
        List<?> list = getList(path);

        if (list == null) {
            return new ArrayList<>(0);
        }

        List<Short> result = new ArrayList<>();

        for (Object object : list) {
            if (object instanceof Short) {
                result.add((Short) object);
            } else if (object instanceof String) {
                try {
                    result.add(Short.valueOf((String) object));
                } catch (Exception _) {
                }
            } else if (object instanceof Character) {
                result.add((short) ((Character) object).charValue());
            } else if (object instanceof Number) {
                result.add(((Number) object).shortValue());
            }
        }

        return result;
    }

    @Override
    @NonNull
    public List<Map<?, ?>> getMapList(@NonNull String path) {
        List<?> list = getList(path);
        List<Map<?, ?>> result = new ArrayList<>();

        if (list == null) {
            return result;
        }

        for (Object object : list) {
            if (object instanceof Map) {
                result.add((Map<?, ?>) object);
            }
        }

        return result;
    }

    @Override
    public @NonNull List<ConfigurationSection> getConfigurationSectionList(@NonNull String path) {
        List<?> list = getList(path);
        List<ConfigurationSection> result = new ArrayList<>();

        if (list == null) {
            return result;
        }

        for (Object object : list) {
            if (object instanceof ConfigurationSection section) {
                result.add(section);
            }
        }

        return result;
    }

    @Nullable
    @Override
    public <T> T getObject(@NonNull String path, @NonNull Class<T> clazz) {
        return getObject(path, clazz, null);
    }

    @Nullable
    @Override
    public <T> T getObject(@NonNull String path, @NonNull Class<T> clazz, @Nullable T def) {
        Object val = get(path, def);
        return (clazz.isInstance(val)) ? clazz.cast(val) : def;
    }

    @Nullable
    @Override
    public <T extends ISerializableObject> T getSerializable(@NonNull String path, @NonNull Class<T> clazz) {
        return getObject(path, clazz);
    }

    @Nullable
    @Override
    public <T extends ISerializableObject> T getSerializable(@NonNull String path, @NonNull Class<T> clazz, @Nullable T def) {
        return getObject(path, clazz, def);
    }

    @Override
    @Nullable
    public ConfigurationSection getConfigurationSection(@NonNull String path) {
        Object val = get(path, null);
        if (val != null) {
            return (val instanceof ConfigurationSection) ? (ConfigurationSection) val : null;
        }

        val = get(path, null);
        return (val instanceof ConfigurationSection) ? createSection(path) : null;
    }

    @Override
    public boolean isConfigurationSection(@NonNull String path) {
        Object val = get(path);
        return val instanceof ConfigurationSection;
    }

    @NonNull
    public static String createPath(@NonNull ConfigurationSection section, @Nullable String key) {
        return createPath(section, key, section.getRoot());
    }

    @NonNull
    public static String createPath(@NonNull ConfigurationSection section, @Nullable String key, @Nullable ConfigurationSection relativeTo) {
        ConfigurationSection rootSection = section.getRoot();
        if (rootSection == null) {
            throw new IllegalStateException("Cannot create path without a root");
        }

        StringBuilder builder = new StringBuilder();
        for (ConfigurationSection parent = section; (parent != null) && (parent != relativeTo); parent = parent.getParent()) {
            if (!builder.isEmpty()) {
                builder.insert(0, PATH_SEPARATOR);
            }
            builder.insert(0, parent.getName());
        }

        if ((key != null) && (!key.isEmpty())) {
            if (!builder.isEmpty()) {
                builder.append(PATH_SEPARATOR);
            }

            builder.append(key);
        }

        return builder.toString();
    }

    protected void mapChildrenKeys(@NonNull Set<String> output, @NonNull ConfigurationSection section, boolean deep) {
        if (section instanceof MemoryConfigurationSection memorySection) {

            for (Map.Entry<String, Object> entry : memorySection.childrens.entrySet()) {
                output.add(createPath(section, entry.getKey(), this));

                if (deep && (entry.getValue() instanceof ConfigurationSection entrySection)) {
                    mapChildrenKeys(output, entrySection, true);
                }
            }
        } else {
            Set<String> keys = section.getKeys(deep);

            for (String key : keys) {
                output.add(createPath(section, key, this));
            }
        }
    }

    protected void mapChildrenValues(@NonNull Map<String, Object> output, @NonNull ConfigurationSection section, boolean deep) {
        if (section instanceof MemoryConfigurationSection memorySection) {

            for (Map.Entry<String, Object> entry : memorySection.childrens.entrySet()) {
                String childPath = createPath(section, entry.getKey(), this);
                output.remove(childPath);
                output.put(childPath, entry.getValue());

                if (deep && entry.getValue() instanceof ConfigurationSection entrySection) {
                    mapChildrenValues(output, entrySection, true);
                }
            }
        } else {
            Map<String, Object> values = section.getValues(deep);

            for (Map.Entry<String, Object> entry : values.entrySet()) {
                output.put(createPath(section, entry.getKey(), this), entry.getValue());
            }
        }
    }

    protected boolean isPrimitiveWrapper(@Nullable Object input) {
        return input instanceof Integer || input instanceof Boolean
                || input instanceof Character || input instanceof Byte
                || input instanceof Short || input instanceof Double
                || input instanceof Long || input instanceof Float;
    }

    protected void fromMapTree(@NonNull Map<String, Object> map) {
        for (Map.Entry<?, ?> entry : map.entrySet()) {
            if (entry.getValue() instanceof Map<?, ?> mapTree) {
                this.createSection(entry.getKey().toString(), mapTree);
            } else if (entry.getValue() instanceof List<?> list) {
                if (!list.isEmpty() && list.getFirst() instanceof Map<?, ?>) {
                    List<ConfigurationSection> childrens = new ArrayList<>();
                    int index = 0;
                    for (Object children : list) {
                        childrens.add(new MemoryConfigurationSection(this, "[" + index + "]", (Map<String, Object>) children));
                                index++;
                    }
                    this.set(entry.getKey().toString(), childrens);
                } else {
                    this.set(entry.getKey().toString(), entry.getValue());
                }
            } else {
                this.set(entry.getKey().toString(), entry.getValue());
            }
        }
    }

    protected static int toInt(@Nullable Object object) {
        if (object instanceof Number) {
            return ((Number) object).intValue();
        }

        try {
            return Integer.parseInt(object.toString());
        } catch (NumberFormatException e) {
        } catch (NullPointerException e) {
        }
        return 0;
    }

    protected static float toFloat(@Nullable Object object) {
        if (object instanceof Number) {
            return ((Number) object).floatValue();
        }

        try {
            return Float.parseFloat(object.toString());
        } catch (NumberFormatException e) {
        } catch (NullPointerException e) {
        }
        return 0;
    }

    protected static double toDouble(@Nullable Object object) {
        if (object instanceof Number) {
            return ((Number) object).doubleValue();
        }

        try {
            return Double.parseDouble(object.toString());
        } catch (NumberFormatException e) {
        } catch (NullPointerException e) {
        }
        return 0;
    }

    protected static long toLong(@Nullable Object object) {
        if (object instanceof Number) {
            return ((Number) object).longValue();
        }

        try {
            return Long.parseLong(object.toString());
        } catch (NumberFormatException e) {
        } catch (NullPointerException e) {
        }
        return 0;
    }

    protected static short toShort(@Nullable Object object) {
        if (object instanceof Number) {
            return ((Number) object).shortValue();
        }

        try {
            return Short.parseShort(object.toString());
        } catch (NumberFormatException e) {
        } catch (NullPointerException e) {
        }
        return 0;
    }

    protected static byte toByte(@Nullable Object object) {
        if (object instanceof Number) {
            return ((Number) object).byteValue();
        }

        try {
            return Byte.parseByte(object.toString());
        } catch (NumberFormatException e) {
        } catch (NullPointerException e) {
        }
        return 0;
    }
}

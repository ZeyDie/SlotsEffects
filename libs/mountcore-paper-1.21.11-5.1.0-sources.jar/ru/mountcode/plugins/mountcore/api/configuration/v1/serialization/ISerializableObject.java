package ru.mountcode.plugins.mountcore.api.configuration.v1.serialization;

import org.jspecify.annotations.NonNull;

import java.util.Map;

public interface ISerializableObject {

    @NonNull
    Map<String, Object> serialize();

    @NonNull
    ISerializableObject deserialize(@NonNull Map<String, Object> data);
}

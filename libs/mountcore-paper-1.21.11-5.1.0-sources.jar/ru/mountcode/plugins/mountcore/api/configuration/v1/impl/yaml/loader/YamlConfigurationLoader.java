package ru.mountcode.plugins.mountcore.api.configuration.v1.impl.yaml.loader;

import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;
import org.snakeyaml.engine.v2.api.Dump;
import org.snakeyaml.engine.v2.api.DumpSettings;
import org.snakeyaml.engine.v2.api.Load;
import org.snakeyaml.engine.v2.api.LoadSettings;
import org.snakeyaml.engine.v2.common.FlowStyle;
import ru.mountcode.plugins.mountcore.api.configuration.v1.ConfigurationLoader;
import ru.mountcode.plugins.mountcore.api.configuration.v1.exception.InvalidConfigurationException;
import ru.mountcode.plugins.mountcore.api.configuration.v1.memory.MemoryConfiguration;

import java.io.*;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;

public class YamlConfigurationLoader implements ConfigurationLoader {

    @NonNull
    private final Path path;
    @Nullable
    private final URL defaultConfigurationURL;
    private final LoadSettings loadSettings;

    public YamlConfigurationLoader(@NonNull Path path) {
        this(path, null);
    }

    public YamlConfigurationLoader(@NonNull Path path, @Nullable URL defaultConfigurationURL) {
        this.path = path;
        this.defaultConfigurationURL = defaultConfigurationURL;

        this.loadSettings = LoadSettings.builder()
                .setLabel(path.getFileName().toString())
                .setParseComments(true)
                .build();
    }

    private void writeDefaultConfiguration() throws IOException {
        Files.createDirectories(path.getParent());

        if (this.defaultConfigurationURL == null) {
            Files.createFile(path);
            return;
        }

        try (InputStream inputStream = this.defaultConfigurationURL.openStream()) {
            Files.copy(inputStream, path);
        }
    }

    @NonNull
    @Override
    public MemoryConfiguration load() throws InvalidConfigurationException, IOException {
        if (!Files.exists(path)) {
            writeDefaultConfiguration();
        }

        try (InputStream inputStream = new FileInputStream(path.toFile())) {
            Load loader = new Load(loadSettings);

            Object object = loader.loadFromInputStream(inputStream);
            if (object == null) {
                throw new InvalidConfigurationException("Unable to load configuration from file '" + path + "'");
            }

            if (!(object instanceof Map<?,?> rawNode)) {
                throw new InvalidConfigurationException("Unable to load configuration from file '" + path + "', but root node isn`t map");
            }

            Map<String, Object> rootNode;
            try {
                rootNode = (Map<String, Object>) rawNode;
            } catch (ClassCastException e) {
                throw new InvalidConfigurationException("Can not loading configuration, but casting not successful", e);
            }

            return new MemoryConfiguration(rootNode);
        }
    }

    @Override
    public void save(@NonNull MemoryConfiguration configuration) throws IOException {
        DumpSettings settings = DumpSettings.builder()
                .setDefaultFlowStyle(FlowStyle.BLOCK)
                .build();

        Dump dumper = new Dump(settings);
        String yaml = dumper.dumpToString(configuration.toMapTree());

        try (Writer writer = new OutputStreamWriter(new FileOutputStream(this.path.toFile()), StandardCharsets.UTF_8)) {
            writer.write(yaml);
        }
    }

    @NonNull
    @Override
    public Path getPath() {
        return path;
    }

    @Nullable
    @Override
    public URL getDefaultConfigurationURL() {
        return this.defaultConfigurationURL;
    }
}

package ru.mountcode.plugins.mountcore.api.configuration.v1;

import org.jspecify.annotations.Nullable;
import org.jspecify.annotations.NonNull;
import ru.mountcode.plugins.mountcore.api.configuration.v1.serialization.ISerializableObject;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public interface ConfigurationSection {

    String getName();

    @Nullable ConfigurationSection getParent();

    @Nullable ConfigurationSection getRoot();

    default boolean isRoot() {
        return getParent() == null;
    }

    @Nullable String getCurrentPath();

    @NonNull
    Set<String> getKeys(boolean recursive);

    @NonNull
    Map<String, Object> getValues(boolean recursive);

    boolean contains(@NonNull String path);

    boolean contains(@NonNull String path, boolean ignoreDefault);

    @Nullable Object get(@NonNull String path);

    @Nullable
    Object get(@NonNull String path, @Nullable Object def);

    void set(@NonNull String path, @Nullable Object value);

    @NonNull
    ConfigurationSection createSection(@NonNull String path);

    @NonNull
    ConfigurationSection createSection(@NonNull String path, @NonNull Map<?, ?> map);

    @Nullable String getString(@NonNull String path);

    @Nullable String getString(@NonNull String path, @Nullable String def);

    boolean isString(@NonNull String path);

    int getInt(@NonNull String path);

    int getInt(@NonNull String path, int def);

    boolean isInt(@NonNull String path);

    boolean getBoolean(@NonNull String path);

    boolean getBoolean(@NonNull String path, boolean def);

    boolean isBoolean(@NonNull String path);

    double getDouble(@NonNull String path);

    double getDouble(@NonNull String path, double def);

    boolean isDouble(@NonNull String path);

    UUID getUUID(@NonNull String path);

    UUID getUUID(@NonNull String path, UUID def);

    boolean isUUID(@NonNull String path);

    long getLong(@NonNull String path);

    long getLong(@NonNull String path, long def);

    boolean isLong(@NonNull String path);

    @Nullable List<?> getList(@NonNull String path);

    @Nullable List<?> getList(@NonNull String path, @Nullable List<?> def);

    boolean isList(@NonNull String path);

    @NonNull
    List<String> getStringList(@NonNull String path);

    @NonNull
    List<Integer> getIntegerList(@NonNull String path);

    @NonNull
    List<Boolean> getBooleanList(@NonNull String path);

    @NonNull
    List<Double> getDoubleList(@NonNull String path);

    @NonNull
    List<Float> getFloatList(@NonNull String path);

    @NonNull
    List<Long> getLongList(@NonNull String path);

    @NonNull
    List<Byte> getByteList(@NonNull String path);

    @NonNull
    List<Character> getCharacterList(@NonNull String path);

    @NonNull
    List<Short> getShortList(@NonNull String path);

    @NonNull
    List<Map<?, ?>> getMapList(@NonNull String path);

    @NonNull
    List<ConfigurationSection> getConfigurationSectionList(@NonNull String path);

    @Nullable <T> T getObject(@NonNull String path, @NonNull Class<T> clazz);

    @Nullable ConfigurationSection getConfigurationSection(@NonNull String path);

    boolean isConfigurationSection(@NonNull String path);

    @Nullable <T> T getObject(@NonNull String path, @NonNull Class<T> clazz, @Nullable T def);

    @Nullable <T extends ISerializableObject> T getSerializable(@NonNull String path, @NonNull Class<T> clazz);

    @Nullable <T extends ISerializableObject> T getSerializable(@NonNull String path, @NonNull Class<T> clazz, @Nullable T def);
}

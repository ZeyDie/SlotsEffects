package ru.mountcode.plugins.mountcore.api.configuration.v1.memory;

import org.jspecify.annotations.NonNull;
import ru.mountcode.plugins.mountcore.api.configuration.v1.ConfigurationSection;

import java.util.*;

public class MemoryConfiguration extends MemoryConfigurationSection {

    public MemoryConfiguration(@NonNull Map<String, Object> map) {
        super();

        fromMapTree(map);
    }

    /**
     * Преобразует текущий {@link MemoryConfiguration} и всё его содержимое в сериализуемую Map-структуру.
     * Поддерживает вложенные секции и списки ConfigurationSection.
     *
     * @return сериализуемое дерево в виде {@code Map<String, Object>}
     */
    public Map<String, Object> toMapTree() {
        return toMapTree(this);
    }


    /**
     * Преобразует {@link ConfigurationSection} и всё его содержимое в сериализуемую Map-структуру.
     * Поддерживает вложенные секции и списки ConfigurationSection.
     *
     * @param section конфигурационная секция
     * @return сериализуемое дерево в виде {@code Map<String, Object>}
     */
    public static Map<String, Object> toMapTree(ConfigurationSection section) {
        Map<String, Object> result = new LinkedHashMap<>();

        Set<String> keys = section.getKeys(false);
        for (String key : keys) {
            Object value = section.get(key);

            if (value instanceof ConfigurationSection subSection) {
                result.put(key, toMapTree(subSection));

            } else if (value instanceof List<?> list) {
                result.put(key, serializeList(list));

            } else {
                result.put(key, value);
            }
        }

        return result;
    }

    /**
     * Обрабатывает элементы списка, превращая вложенные ConfigurationSection в Map-объекты.
     */
    private static List<Object> serializeList(List<?> list) {
        List<Object> result = new ArrayList<>();

        for (Object item : list) {
            if (item instanceof ConfigurationSection section) {
                result.add(toMapTree(section));
            } else if (item instanceof List<?>) {
                result.add(serializeList((List<?>) item));
            } else {
                result.add(item);
            }
        }

        return result;
    }
}

package ru.mountcode.plugins.mountcore.api.database.v1.impl;

import com.zaxxer.hikari.HikariDataSource;
import lombok.Getter;
import org.jooq.DSLContext;
import org.jooq.impl.DSL;
import org.jooq.jpa.extensions.DefaultAnnotatedPojoMemberProvider;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;
import ru.mountcode.plugins.mountcore.api.database.v1.DatabaseAlreadyInitializedException;
import ru.mountcode.plugins.mountcore.api.database.v1.DatabaseType;
import ru.mountcode.plugins.mountcore.api.database.v1.MountDatabase;
import ru.mountcode.plugins.mountcore.api.database.v1.UnsupportedDatabaseException;
import ru.mountcode.plugins.mountcore.api.database.v1.credentials.DatabaseCredentials;
import ru.mountcode.plugins.mountcore.api.database.v1.migration.DatabaseMigrationException;
import ru.mountcode.plugins.mountcore.api.database.v1.migration.DatabaseMigrator;

import java.sql.Connection;
import java.sql.SQLException;

public class MountDatabaseImpl implements MountDatabase {

    private final DatabaseCredentials credentials;
    @Getter
    private final DatabaseType databaseType;
    @Nullable
    @Getter
    private final DatabaseMigrator migrator;

    @Nullable
    @Getter
    private HikariDataSource dataSource;
    @Nullable
    private DSLContext dslContext;

    static {
        System.getProperties().setProperty("org.jooq.no-logo", "true");
        System.getProperties().setProperty("org.jooq.no-tips", "true");
        System.setProperty("org.jooq.log.org.jooq.impl.DefaultExecuteContext.logVersionSupport", "ERROR");
    }

    public MountDatabaseImpl(@NonNull DatabaseCredentials credentials, @NonNull DatabaseType databaseType, @Nullable DatabaseMigrator migrator) throws UnsupportedDatabaseException {
        this.credentials = credentials;
        this.databaseType = databaseType;
        this.migrator = migrator;

        this.loadDriver();
    }

    @Override
    public void initialize() throws DatabaseMigrationException {
        if (this.dataSource != null) {
            throw new DatabaseAlreadyInitializedException("Initialize method called twice!");
        }

        this.initializeDataSource();
        this.initializeDSLContext();

        if (this.migrator != null) {
            try (Connection connection = this.connection()) {
                this.migrator.migrate(connection);
            } catch (SQLException e) {
                throw new DatabaseMigrationException("Error when migration but detected sql exception", e);
            }
        }
    }

    @Override
    public @NonNull Connection connection() throws SQLException {
        if (this.dataSource == null) {
            throw new IllegalStateException("Method connection called before database initialization!");
        }

        return this.dataSource.getConnection();
    }

    @Override
    public @NonNull DSLContext query() {
        if (this.dslContext == null) {
            throw new IllegalStateException("Method query called before database initialization!");
        }

        return this.dslContext;
    }

    @Override
    public void shutdown() {
        if (this.dataSource == null) {
            return;
        }

        this.dataSource.close();
    }

    @Override
    public @NonNull DatabaseCredentials getDatabaseCredentials() {
        return credentials;
    }

    protected void loadDriver() throws UnsupportedDatabaseException {
        try {
            Class.forName(this.getDatabaseType().getDriverClass(), true, MountDatabase.class.getClassLoader());
        } catch (UnsupportedClassVersionError e) {
            throw new UnsupportedDatabaseException(String.format("Your database driver %s is not compatible with your Java version. " +
                    "You will need to either upgrade your Java version or install a different driver jar file.", this.getDatabaseType().getDriverClass()), e);
        } catch (Exception e) {
            throw new UnsupportedDatabaseException("Cannot find database driver: " + e.getMessage());
        }
    }

    protected void initializeDataSource() {
        this.dataSource = new HikariDataSource();
        this.dataSource.setJdbcUrl(this.credentials.jdbcUrl());
        this.dataSource.setUsername(this.credentials.username());
        this.dataSource.setPassword(this.credentials.password());

        this.dataSource.addDataSourceProperty("cachePrepStmts", "true");
        this.dataSource.addDataSourceProperty("prepStmtCacheSize", "250");
        this.dataSource.addDataSourceProperty("prepStmtCacheSqlLimit", "2048");
    }

    protected void initializeDSLContext() {
        this.dslContext = DSL.using(this.dataSource, this.databaseType.getSqlDialect())
                .configuration()
                .derive(new DefaultAnnotatedPojoMemberProvider())
                .deriveSettings(settings -> settings.withMapJPAAnnotations(true))
                .dsl();

    }
}

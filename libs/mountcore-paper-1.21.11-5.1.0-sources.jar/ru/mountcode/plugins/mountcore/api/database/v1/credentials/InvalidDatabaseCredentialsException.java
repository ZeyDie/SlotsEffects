package ru.mountcode.plugins.mountcore.api.database.v1.credentials;

public class InvalidDatabaseCredentialsException extends Exception {
    public InvalidDatabaseCredentialsException(String message) {
        super(message);
    }
}

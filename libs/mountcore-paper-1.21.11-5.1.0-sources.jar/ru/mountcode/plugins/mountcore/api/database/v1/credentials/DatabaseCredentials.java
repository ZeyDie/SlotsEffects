package ru.mountcode.plugins.mountcore.api.database.v1.credentials;

/**
 * Represents immutable credentials for connecting to a database via JDBC.
 * This record encapsulates the essential connection information:
 * <ul>
 *   <li>JDBC URL (connection string)</li>
 *   <li>Username</li>
 *   <li>Password</li>
 * </ul>
 *
 * <p><b>Example usage:</b></p>
 * <pre>{@code
 * DatabaseCredentials credentials = new DatabaseCredentials(
 *     "jdbc:mysql://localhost:3306/my_database",
 *     "root",
 *     "password123"
 * );
 * }</pre>
 *
 * <p><b>Supported JDBC URL patterns:</b></p>
 * <table border="1">
 *   <caption>Supported JDBC URLs for different databases</caption>
 *   <tr><th>Database</th><th>Example JDBC URL</th><th>Description</th></tr>
 *   <tr>
 *     <td>MySQL</td>
 *     <td>{@code jdbc:mysql://localhost:3306/my_database?useSSL=false&serverTimezone=UTC}</td>
 *     <td>Connects to a local MySQL server</td>
 *   </tr>
 *   <tr>
 *     <td>PostgreSQL</td>
 *     <td>{@code jdbc:postgresql://localhost:5432/my_database}</td>
 *     <td>Connects to a local PostgreSQL server</td>
 *   </tr>
 *   <tr>
 *     <td>H2 (in-memory)</td>
 *     <td>{@code jdbc:h2:mem:my_database;DB_CLOSE_DELAY=-1}</td>
 *     <td>In-memory database, not persisted after shutdown</td>
 *   </tr>
 *   <tr>
 *     <td>H2 (local file)</td>
 *     <td>{@code jdbc:h2:file:./data/my_database}</td>
 *     <td>Stores data in a local file</td>
 *   </tr>
 *   <tr>
 *     <td>H2 (remote server)</td>
 *     <td>{@code jdbc:h2:tcp://192.168.0.100:9092/~/my_database}</td>
 *     <td>Connects to a remote H2 server</td>
 *   </tr>
 *   <tr>
 *     <td>MariaDB</td>
 *     <td>{@code jdbc:mariadb://localhost:3306/my_database}</td>
 *     <td>Connects to a MariaDB instance</td>
 *   </tr>
 *   <tr>
 *     <td>ClickHouse</td>
 *     <td>{@code jdbc:clickhouse://localhost:8123/my_database}</td>
 *     <td>Connects to a ClickHouse instance</td>
 *   </tr>
 * </table>
 *
 * @param jdbcUrl  The full JDBC URL for the database connection
 * @param username The username used for authentication
 * @param password The user’s password
 *
 * @since 5.0.0
 */
public record DatabaseCredentials(String jdbcUrl, String username, String password) {
}

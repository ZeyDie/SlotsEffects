package ru.mountcode.plugins.mountcore.api.database.v1;

public class UnsupportedDatabaseException extends Exception {
    public UnsupportedDatabaseException(String message) {
        super(message);
    }

    public UnsupportedDatabaseException(String message, Throwable cause) {
        super(message, cause);
    }
}

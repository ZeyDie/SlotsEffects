package ru.mountcode.plugins.mountcore.api.database.v1.migration;

import java.sql.Connection;

/**
 * Contract for performing database schema migrations.
 * Implementations are responsible for applying pending changesets to the target database
 * using the provided JDBC connection.
 *
 * <p>This interface is typically used during application or plugin startup to ensure the
 * database schema is up-to-date with the current version defined in migration scripts.
 *
 * <p>Example usage:
 * <pre>{@code
 * DatabaseMigrator migrator = new YourMigratorImpl();
 * try (Connection connection = dataSource.getConnection()) {
 *     migrator.migrate(connection);
 *     System.out.println("Database migration completed.");
 * } catch (DatabaseMigrationException e) {
 *     System.err.println("Migration failed: " + e.getMessage());
 *     throw e;
 * }
 * }</pre>
 *
 * @since 5.0.0
 */
public interface DatabaseMigrator {

    /**
     * Executes the migration process on the specified database connection.
     *
     * <p>The implementation should:
     * <ul>
     *   <li>Detect pending changesets</li>
     *   <li>Apply them in the correct order</li>
     *   <li>Track applied changes in system tables</li>
     *   <li>Handle rollbacks or errors appropriately</li>
     * </ul>
     *
     * @param connection an active JDBC connection to the target database
     * @throws DatabaseMigrationException if any error occurs during migration
     * @since 5.0.0
     */
    void migrate(Connection connection) throws DatabaseMigrationException;
}

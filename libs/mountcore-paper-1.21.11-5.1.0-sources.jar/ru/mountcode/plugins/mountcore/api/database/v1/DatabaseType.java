package ru.mountcode.plugins.mountcore.api.database.v1;

import lombok.Getter;
import org.jooq.SQLDialect;
import org.jspecify.annotations.NonNull;

public enum DatabaseType {

    H2(SQLDialect.H2, "org.h2.Driver"),
    MYSQL(SQLDialect.MYSQL, "com.mysql.cj.jdbc.Driver"),
    MARIADB(SQLDialect.MARIADB, "org.mariadb.jdbc.Driver"),
    POSTGRESQL(SQLDialect.POSTGRES, "org.postgresql.Driver"),
    CLICKHOUSE(SQLDialect.CLICKHOUSE, "com.clickhouse.jdbc.ClickHouseDriver");

    @Getter
    @NonNull
    private final String driverClass;
    @Getter
    @NonNull
    private final SQLDialect sqlDialect;

    DatabaseType(@NonNull SQLDialect sqlDialect, @NonNull String driverClass) {
        this.sqlDialect = sqlDialect;
        this.driverClass = driverClass;
    }

    @NonNull
    public static DatabaseType fromJdbcUrl(@NonNull String jdbcUrl) throws UnsupportedDatabaseException {
        if (jdbcUrl.isBlank()) {
            throw new UnsupportedDatabaseException("JDBC URL is blank");
        }

        String[] parts = jdbcUrl.split(":");
        if (parts.length < 2) {
            throw new UnsupportedDatabaseException("JDBC URL is invalid");
        }

        String databaseType = parts[1];
        if (databaseType.isBlank()) {
            throw new UnsupportedDatabaseException("Database type in JDBC URL is blank");
        }
        try {
            return DatabaseType.valueOf(databaseType.toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new UnsupportedDatabaseException("Unsupported database type: " + databaseType);
        }
    }
}

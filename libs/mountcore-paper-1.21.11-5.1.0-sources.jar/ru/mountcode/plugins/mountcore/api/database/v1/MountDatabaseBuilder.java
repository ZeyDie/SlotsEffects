package ru.mountcode.plugins.mountcore.api.database.v1;

import org.jspecify.annotations.NonNull;
import ru.mountcode.plugins.mountcore.api.database.v1.credentials.DatabaseCredentials;
import ru.mountcode.plugins.mountcore.api.database.v1.impl.MountDatabaseImpl;
import ru.mountcode.plugins.mountcore.api.database.v1.migration.DatabaseMigrator;

/**
 * A builder class for constructing and configuring {@link MountDatabase} instances.
 *
 * <p>
 * The {@code MountDatabaseBuilder} follows the <b>Builder design pattern</b>,
 * providing a fluent API for setting up database credentials and optional
 * migration logic before creating a fully initialized {@link MountDatabase} instance.
 * </p>
 *
 * <p><b>Responsibilities:</b></p>
 * <ul>
 *     <li>Configure {@link DatabaseCredentials} for establishing the connection.</li>
 *     <li>Optionally attach a {@link DatabaseMigrator} for schema migration or initialization logic.</li>
 *     <li>Determine the {@link DatabaseType} automatically from the JDBC URL.</li>
 *     <li>Build a concrete {@link MountDatabaseImpl} instance ready for use.</li>
 * </ul>
 *
 * <p><b>Usage example:</b></p>
 * <pre>{@code
 * DatabaseCredentials credentials = new DatabaseCredentials(
 *     "jdbc:postgresql://localhost:5432/mountcore",
 *     "postgres",
 *     "secret"
 * );
 *
 * DatabaseMigrator migrator = new LiquibaseDatabaseMigrator("classpath:/migrations");
 *
 * MountDatabase database = MountDatabase.builder()
 *     .credentials(credentials)
 *     .migrator(migrator) // Optional
 *     .build();
 *
 * }</pre>
 *
 * <p><b>Notes:</b></p>
 * <ul>
 *     <li>{@link #credentials(DatabaseCredentials)} is mandatory; without it, {@link #build()} will throw an exception.</li>
 *     <li>{@link #migrator(DatabaseMigrator)} is optional; pass it only if database migration is required.</li>
 *     <li>The appropriate {@link DatabaseType} is automatically detected from the JDBC URL (e.g. MySQL, PostgreSQL, H2, etc.).</li>
 * </ul>
 *
 * @see MountDatabase
 * @see DatabaseCredentials
 * @see DatabaseMigrator
 * @see DatabaseType
 *
 * @since 5.0.0
 */
public class MountDatabaseBuilder {

    private DatabaseCredentials credentials;
    private DatabaseMigrator migrator;

    MountDatabaseBuilder() {
    }

    /**
     * Sets the {@link DatabaseCredentials} used for connecting to the database.
     *
     * @param credentials non-null database credentials
     * @return this builder instance for method chaining
     */
    @NonNull
    public MountDatabaseBuilder credentials(@NonNull DatabaseCredentials credentials) {
        this.credentials = credentials;
        return this;
    }

    /**
     * Sets the {@link DatabaseMigrator} responsible for applying database schema migrations.
     * This parameter is optional.
     *
     * @param migrator non-null migrator instance
     * @return this builder instance for method chaining
     */
    @NonNull
    public MountDatabaseBuilder migrator(@NonNull DatabaseMigrator migrator) {
        this.migrator = migrator;
        return this;
    }

    /**
     * Builds a fully configured {@link MountDatabase} instance based on the provided
     * credentials and optional migration logic.
     *
     * <p>
     * The {@link DatabaseType} is automatically derived from the JDBC URL contained
     * in {@link DatabaseCredentials}.
     * </p>
     *
     * @return a ready-to-use {@link MountDatabase} implementation
     * @throws IllegalStateException if credentials are not specified
     * @throws UnsupportedDatabaseException if the JDBC URL uses an unsupported database type
     */
    @NonNull
    public MountDatabase build() throws UnsupportedDatabaseException {
        if (credentials == null) {
            throw new IllegalStateException("Credentials is null when building database");
        }

        DatabaseType databaseType = DatabaseType.fromJdbcUrl(credentials.jdbcUrl());

        return new MountDatabaseImpl(credentials, databaseType, migrator);
    }
}

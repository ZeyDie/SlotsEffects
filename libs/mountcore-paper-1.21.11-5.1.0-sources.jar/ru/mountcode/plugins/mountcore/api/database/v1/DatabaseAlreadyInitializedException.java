package ru.mountcode.plugins.mountcore.api.database.v1;

public class DatabaseAlreadyInitializedException extends RuntimeException {
    public DatabaseAlreadyInitializedException(String message) {
        super(message);
    }
}

package ru.mountcode.plugins.mountcore.api.database.v1.credentials;

import ru.mountcode.plugins.mountcore.api.configuration.v1.ConfigurationSection;

public interface DatabaseCredentialsParser {

    DatabaseCredentials parse(ConfigurationSection configurationSection) throws InvalidDatabaseCredentialsException;
}

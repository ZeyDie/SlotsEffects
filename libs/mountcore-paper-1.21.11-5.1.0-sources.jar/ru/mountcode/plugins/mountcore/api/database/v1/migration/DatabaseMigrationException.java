package ru.mountcode.plugins.mountcore.api.database.v1.migration;

/**
 * A checked exception indicating that a database migration operation has failed.
 * This exception is thrown by implementations of {@link DatabaseMigrator} when
 * an error occurs during the execution of migration scripts (e.g., syntax errors,
 * constraint violations, connection issues, or Liquibase-specific failures).
 *
 * <p>It provides constructors that allow wrapping of the original cause and/or
 * a descriptive message to aid in debugging and error handling at the application level.
 *
 * <p>Example usage:
 * <pre>{@code
 * try {
 *     migrator.migrate(connection);
 * } catch (DatabaseMigrationException e) {
 *     log.error("Failed to apply database migrations", e);
 *     throw e; // rethrow or handle gracefully
 * }
 * }</pre>
 *
 * @since 5.0.0
 */
public class DatabaseMigrationException extends Exception {

    /**
     * Constructs a new database migration exception with the specified detail message.
     *
     * @param message the detail message (which is saved for later retrieval
     *                by the {@link #getMessage()} method)
     * @since 5.0.0
     */
    public DatabaseMigrationException(String message) {
        super(message);
    }

    /**
     * Constructs a new database migration exception with the specified detail message
     * and cause.
     *
     * @param message the detail message
     * @param cause   the cause (which is saved for later retrieval by the
     *                {@link #getCause()} method)
     * @since 5.0.0
     */
    public DatabaseMigrationException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * Constructs a new database migration exception with the specified cause
     * and a detail message of {@code (cause==null ? null : cause.toString())}.
     *
     * @param cause the cause (which is saved for later retrieval by the
     *              {@link #getCause()} method)
     * @since 5.0.0
     */
    public DatabaseMigrationException(Throwable cause) {
        super(cause);
    }
}

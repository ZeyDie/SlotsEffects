package ru.mountcode.plugins.mountcore.api.database.v1.migration.impl;

import liquibase.Liquibase;
import liquibase.database.Database;
import liquibase.database.DatabaseFactory;
import liquibase.database.jvm.JdbcConnection;
import liquibase.resource.ResourceAccessor;
import liquibase.resource.ZipResourceAccessor;
import lombok.Builder;
import lombok.Singular;
import org.jspecify.annotations.NonNull;
import ru.mountcode.plugins.mountcore.api.database.v1.migration.DatabaseMigrationException;
import ru.mountcode.plugins.mountcore.api.database.v1.migration.DatabaseMigrator;

import java.io.File;
import java.io.FileNotFoundException;
import java.net.URISyntaxException;
import java.net.URL;
import java.security.CodeSource;
import java.sql.Connection;
import java.util.Map;

/**
 * Implementation of {@link DatabaseMigrator} using Liquibase for database schema migrations.
 * This class handles the migration process by configuring Liquibase with a custom changelog path,
 * system tables prefix, and resource class loader. It ensures thread-safe class loader management
 * during the migration execution.
 *
 * <p>This migrator is designed to be used in plugin environments where database schema changes
 * need to be applied reliably. It wraps Liquibase operations and translates exceptions into
 * {@link DatabaseMigrationException} for consistent error handling.
 *
 * <p>Example usage:
 * <pre>{@code
 * LiquibaseMigrator migrator = LiquibaseMigrator.builder()
 *     .systemTablesPrefix("my_prefix")
 *     .anchorClass(getClass())
 *     .changelogPath("db/changelog/my-changelog-master.yml")
 *     .build();
 * }</pre>
 *
 * @since 5.0.0
 */
@Builder
public class LiquibaseMigrator implements DatabaseMigrator {

    /**
     * Prefix for Liquibase system tables (e.g., changelog and changelog_lock tables).
     * This allows customization of table names to avoid conflicts in shared databases.
     *
     * @since 5.0.0
     */
    @NonNull
    private final String systemTablesPrefix;

    /**
     * Anchor class used to access resources like the changelog file.
     * This is typically the class of the plugin or application context.
     *
     * @since 5.0.11
     */
    @NonNull
    private final Class<?> anchorClass;

    /**
     * Path to the Liquibase changelog master file, relative to the resource class loader.
     * Defaults to "db/changelog/changelog-master.yml" if not specified.
     *
     * @since 5.0.0
     */
    @Builder.Default
    private String changelogPath = "db/changelog/changelog-master.yml";

    /**
     * Dictionary of liquibase changelog parameters, used by liquibase for dynamic injection
     * in changelog files
     * <p>
     * Using in changelog files
     * <pre>{@code
     * databaseChangeLog:
     *   - changeSet:
     *       id: create-${mountcore_example_table}-table
     *       author: EarWarm
     *       changes:
     *         - createTable:
     *             tableName: ${mountcore_example_table}
     *             columns:
     *               - column:
     *                   name: id
     *                   type: uuid
     *                   constraints:
     *                     primaryKey: true
     *                     nullable: false
     * }</pre>
     *
     * @since 5.0.17
     */
    @Singular
    private Map<String, Object> parameters;

    /**
     * This method called automatically.
     * <p>Performs the database migration using Liquibase.
     *
     * <p>This method sets up the Liquibase environment, configures custom table names based on the
     * system tables prefix, executes the update, and handles class loader switching to ensure
     * compatibility in multi-classloader environments (e.g., plugin systems).
     *
     * <p>If any error occurs during migration, it is wrapped in a {@link DatabaseMigrationException}.
     *
     * @param connection the JDBC connection to the database
     * @throws DatabaseMigrationException if migration fails due to Liquibase errors or configuration issues
     * @since 5.0.0
     */
    @Override
    public void migrate(Connection connection) throws DatabaseMigrationException {
        ClassLoader originalClassLoader = Thread.currentThread().getContextClassLoader();
        try {
            // Set the context classloader to the one loading Liquibase
            Thread.currentThread().setContextClassLoader(Liquibase.class.getClassLoader());

            Database database = DatabaseFactory.getInstance().findCorrectDatabaseImplementation(new JdbcConnection(connection));
            database.setDatabaseChangeLogTableName((systemTablesPrefix.endsWith("_") ? systemTablesPrefix : systemTablesPrefix + "_") + "changelog");
            database.setDatabaseChangeLogLockTableName((systemTablesPrefix.endsWith("_") ? systemTablesPrefix : systemTablesPrefix + "_") + "changelog_lock");
            Liquibase liquibase = new Liquibase(
                    changelogPath.startsWith("/") ? changelogPath.substring(1) : changelogPath,
                    constructResourceAccessor(),
                    database
            );

            for (Map.Entry<String, Object> entry : parameters.entrySet()) {
                liquibase.setChangeLogParameter(entry.getKey(), entry.getValue());
            }

            liquibase.update();
        } catch (Exception e) {
            throw new DatabaseMigrationException(e);
        } finally {
            // Reset the original classloader
            Thread.currentThread().setContextClassLoader(originalClassLoader);
        }
    }

    protected ResourceAccessor constructResourceAccessor() throws DatabaseMigrationException {
        CodeSource codeSource = this.anchorClass.getProtectionDomain().getCodeSource();
        if (codeSource == null || codeSource.getLocation() == null) {
            throw new DatabaseMigrationException("Cannot determine JAR file location for " + this.anchorClass.getSimpleName() + " class");
        }

        URL jarUrl = codeSource.getLocation();
        File jarFile;
        try {
            jarFile = new File(jarUrl.toURI());
        } catch (URISyntaxException e) {
            throw new DatabaseMigrationException("Cannot determine Jar file location");
        }

        if (!jarFile.isFile()) {
            throw new DatabaseMigrationException("Expected a Jar file, but got: " + jarFile);
        }

        try {
            return new ZipResourceAccessor(jarFile.getAbsoluteFile());
        } catch (FileNotFoundException e) {
            throw new DatabaseMigrationException("Jar file not found: " + jarFile);
        }
    }
}

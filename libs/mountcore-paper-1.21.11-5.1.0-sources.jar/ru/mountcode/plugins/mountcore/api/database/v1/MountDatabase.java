package ru.mountcode.plugins.mountcore.api.database.v1;

import org.jooq.DSLContext;
import org.jspecify.annotations.NonNull;
import ru.mountcode.plugins.mountcore.api.database.v1.credentials.DatabaseCredentials;
import ru.mountcode.plugins.mountcore.api.database.v1.migration.DatabaseMigrationException;

import java.sql.Connection;
import java.sql.SQLException;

/**
 * Represents the central abstraction for database management and query execution
 * within the MountCore data access layer.
 *
 * A {@code MountDatabase} instance provides unified access to both:
 * <ul>
 *     <li>Low-level JDBC operations via {@link #connection()}.</li>
 *     <li>High-level fluent SQL API via {@link #query()} (powered by jOOQ).</li>
 * </ul>
 *
 * <p><b>Lifecycle:</b></p>
 * <ol>
 *     <li>Construct a {@link MountDatabase} instance via {@link MountDatabaseBuilder}.</li>
 *     <li>Call {@link #initialize()} to open the connection or pool.</li>
 *     <li>Perform queries via {@link #query()} or {@link #connection()}.</li>
 *     <li>Call {@link #shutdown()} to gracefully release resources.</li>
 * </ol>
 *
 * <p><b>Example usage:</b></p>
 * <pre>{@code
 * MountDatabase database = MountDatabase.builder()
 *     .credentials(new DatabaseCredentials(
 *         "jdbc:mysql://localhost:3306/mountcore?useSSL=false&serverTimezone=UTC",
 *         "root",
 *         "secret"
 *     ))
 *     .build();
 *
 * database.initialize();
 *
 * // Run jOOQ queries
 * database.query()
 *     .insertInto(DSL.table("users"))
 *     .set(DSL.field("username"), "artem")
 *     .execute();
 *
 * database.shutdown();
 * }</pre>
 *
 * <p><b>Thread-safety:</b></p>
 * Implementations should ensure that both {@link Connection} and {@link DSLContext}
 * are safely accessible from multiple threads, typically by using a connection pool.
 *
 * @see MountDatabaseBuilder
 * @see DatabaseCredentials
 * @see org.jooq.DSLContext
 * @see java.sql.Connection
 *
 * @since 5.0.0
 */
public interface MountDatabase {

    /**
     * Initializes the database connection and prepares internal resources.
     */
    void initialize() throws DatabaseMigrationException;

    /**
     * Returns an active JDBC connection to the underlying database.
     *
     * @return a non-null JDBC {@link Connection}
     * @throws SQLException if acquiring the connection fails
     */
    @NonNull
    Connection connection() throws SQLException;

    /**
     * Returns a jOOQ {@link DSLContext} bound to the current database connection.
     * <p>
     * The {@link DSLContext} is the central entry point of the jOOQ API and allows
     * execution of type-safe, fluent SQL queries, schema manipulations, and transactional logic.
     * </p>
     *
     * <p><b>Official documentation:</b><br>
     * <a href="https://www.jooq.org/doc/latest/manual/sql-building/dsl-context/"
     *    target="_blank">https://www.jooq.org/doc/latest/manual/sql-building/dsl-context/</a>
     * </p>
     *
     * @return a non-null jOOQ {@link DSLContext} instance for this database
     * @see <a href="https://www.jooq.org/doc/latest/manual/sql-building/dsl-context/"
     *      target="_blank">jOOQ DSLContext Documentation</a>
     */
    @NonNull
    DSLContext query();

    /**
     * Closes the database connection and releases any underlying resources.
     */
    void shutdown();

    /**
     * Returns the credentials used to connect to this database.
     *
     * @return non-null {@link DatabaseCredentials}
     */
    @NonNull
    DatabaseCredentials getDatabaseCredentials();

    /**
     * Creates a new {@link MountDatabaseBuilder} instance for constructing
     * database configurations in a fluent manner.
     *
     * @return a new builder
     */
    @NonNull
    static MountDatabaseBuilder builder() {
        return new MountDatabaseBuilder();
    }
}

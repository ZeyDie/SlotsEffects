package ru.mountcode.plugins.mountcore.api.database.v1.credentials.impl;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.jspecify.annotations.NonNull;
import ru.mountcode.plugins.mountcore.api.configuration.v1.ConfigurationSection;
import ru.mountcode.plugins.mountcore.api.database.v1.credentials.DatabaseCredentials;
import ru.mountcode.plugins.mountcore.api.database.v1.credentials.DatabaseCredentialsParser;
import ru.mountcode.plugins.mountcore.api.database.v1.credentials.InvalidDatabaseCredentialsException;

/**
 * <p>
 * Implementation of {@link DatabaseCredentialsParser} that reads and validates
 * database connection credentials from a {@link ConfigurationSection}.
 * </p>
 *
 * This parser extracts three essential properties:
 * <ul>
 *   <li><b>jdbc-url</b> — the JDBC connection string (must start with {@code jdbc:})</li>
 *   <li><b>username</b> — the database username</li>
 *   <li><b>password</b> — the database password</li>
 * </ul>
 *
 * <p><b>Example configuration:</b></p>
 * <pre>{@code
 * database:
 *   # ---------------------------------------------------------------------
 *   # Supported databases and their default JDBC URL patterns:
 *   # ---------------------------------------------------------------------
 *   # MySQL:
 *   #   jdbc:mysql://<host>:<port>/<database>?useSSL=false&serverTimezone=UTC
 *   #
 *   # PostgreSQL:
 *   #   jdbc:postgresql://<host>:<port>/<database>
 *   #
 *   # H2 (in-memory):
 *   #   jdbc:h2:mem:<database>;DB_CLOSE_DELAY=-1
 *   #
 *   # H2 (local file):
 *   #   jdbc:h2:file:./MountCore/<plugin_name>/database.db
 *   #
 *   # H2 (remote server):
 *   #   jdbc:h2:tcp://<host>:9092/~/<database>
 *   #
 *   # MariaDB:
 *   #   jdbc:mariadb://<host>:<port>/<database>
 *   #
 *   # ClickHouse:
 *   #   jdbc:clickhouse://<host>:<port>/<database>
 *   # ---------------------------------------------------------------------
 *
 *   # JDBC URL of the target database (choose one of the patterns above)
 *   jdbc-url: jdbc:h2:file:./MountCore/MountPlugin/exampleDatabase.db
 *
 *   # Database username
 *   username: root
 *
 *   # Database password
 *   password: secret
 * }</pre>
 *
 * <p><b>Supported JDBC URL patterns:</b></p>
 * <table border="1">
 *   <caption>Supported JDBC URLs for different databases</caption>
 *   <tr><th>Database</th><th>Example JDBC URL</th><th>Description</th></tr>
 *   <tr>
 *     <td>MySQL</td>
 *     <td>{@code jdbc:mysql://localhost:3306/my_database?useSSL=false&serverTimezone=UTC}</td>
 *     <td>Connects to a local MySQL instance</td>
 *   </tr>
 *   <tr>
 *     <td>PostgreSQL</td>
 *     <td>{@code jdbc:postgresql://localhost:5432/my_database}</td>
 *     <td>Connects to a local PostgreSQL instance</td>
 *   </tr>
 *   <tr>
 *     <td>H2 (in-memory)</td>
 *     <td>{@code jdbc:h2:mem:my_database;DB_CLOSE_DELAY=-1}</td>
 *     <td>Creates a temporary in-memory H2 database</td>
 *   </tr>
 *   <tr>
 *     <td>H2 (local file)</td>
 *     <td>{@code jdbc:h2:file:./data/my_database}</td>
 *     <td>Stores H2 data locally on disk</td>
 *   </tr>
 *   <tr>
 *     <td>H2 (remote server)</td>
 *     <td>{@code jdbc:h2:tcp://192.168.0.100:9092/~/my_database}</td>
 *     <td>Connects to a remote H2 server</td>
 *   </tr>
 *   <tr>
 *     <td>MariaDB</td>
 *     <td>{@code jdbc:mariadb://localhost:3306/my_database}</td>
 *     <td>Connects to a MariaDB database</td>
 *   </tr>
 *   <tr>
 *     <td>ClickHouse</td>
 *     <td>{@code jdbc:clickhouse://localhost:8123/my_database}</td>
 *     <td>Connects to a ClickHouse instance</td>
 *   </tr>
 * </table>
 *
 * <b>Validation rules:</b>
 * <ul>
 *   <li>The configuration section must not be {@code null}.</li>
 *   <li>The {@code jdbc-url} must be non-empty and start with {@code jdbc:}.</li>
 *   <li>All required fields ({@code jdbc-url}, {@code username}, {@code password}) must exist.</li>
 * </ul>
 *
 * <p><b>Example usage:</b></p>
 * <pre>{@code
 * ConfigurationSection section = config.getConfigurationSection("database");
 * DatabaseCredentialsParser parser = ConfigurationDatabaseCredentialsParser.parser();
 * DatabaseCredentials credentials = parser.parse(section);
 * }</pre>
 *
 * @see DatabaseCredentials
 * @see DatabaseCredentialsParser
 * @see InvalidDatabaseCredentialsException
 *
 * @since 5.0.0
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class ConfigurationDatabaseCredentialsParser implements DatabaseCredentialsParser {

    private static final ConfigurationDatabaseCredentialsParser PARSER = new ConfigurationDatabaseCredentialsParser();

    @NonNull
    public static ConfigurationDatabaseCredentialsParser parser() {
        return PARSER;
    }

    @Override
    public DatabaseCredentials parse(ConfigurationSection section) throws InvalidDatabaseCredentialsException {
        if (section == null) {
            throw new InvalidDatabaseCredentialsException("Section is null");
        }

        if (!section.contains("jdbc-url")) {
            throw new InvalidDatabaseCredentialsException("JDBC url isn`t set in section");
        }

        String jdbcUrl = section.getString("jdbc-url");
        if (jdbcUrl == null || jdbcUrl.isBlank() || !jdbcUrl.startsWith("jdbc:")) {
            throw new InvalidDatabaseCredentialsException("JDBC url has invalid pattern");
        }

        if (!section.contains("username")) {
            throw new InvalidDatabaseCredentialsException("Username isn`t set in section");
        }
        String username = section.getString("username");

        if (!section.contains("password")) {
            throw new InvalidDatabaseCredentialsException("Password isn`t set in section");
        }
        String password = section.getString("password");

        return new DatabaseCredentials(jdbcUrl, username, password);
    }
}

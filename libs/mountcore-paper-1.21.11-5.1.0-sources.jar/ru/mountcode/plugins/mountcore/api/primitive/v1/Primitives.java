package ru.mountcode.plugins.mountcore.api.primitive.v1;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.jspecify.annotations.NonNull;

import java.util.Optional;

/**
 * Utility class for safely parsing strings into primitive numbers and
 * checking if a given string represents a valid Java primitive number type.
 * All methods for parsing return Optional.empty() if parsing fails and all methods for checking return false if parsing fails.
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class Primitives {

    /**
     * Checks if the given string is a valid byte value.
     *
     * @param value input string
     * @return true if value can be parsed as byte
     */
    public static boolean isByte(@NonNull String value) {
        if (value.isBlank()) return false;

        try {
            Byte.parseByte(value);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    /**
     * Checks if the given string is a valid short value.
     */
    public static boolean isShort(@NonNull String value) {
        if (value.isBlank()) return false;

        try {
            Short.parseShort(value);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    /**
     * Checks if the given string is a valid int value.
     */
    public static boolean isInt(@NonNull String value) {
        if (value.isBlank()) return false;

        try {
            Integer.parseInt(value);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    /**
     * Checks if the given string is a valid long value.
     */
    public static boolean isLong(@NonNull String value) {
        if (value.isBlank()) return false;

        try {
            Long.parseLong(value);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    /**
     * Checks if the given string is a valid float value.
     */
    public static boolean isFloat(@NonNull String value) {
        if (value.isBlank()) return false;

        try {
            Float.parseFloat(value);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    /**
     * Checks if the given string is a valid double value.
     */
    public static boolean isDouble(@NonNull String value) {
        if (value.isBlank()) return false;

        try {
            Double.parseDouble(value);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    /**
     * Safely parses a string into a byte.
     *
     * @param value input string
     * @return Optional containing byte if parsing succeeds, otherwise empty
     */
    public static Optional<Byte> parseByte(@NonNull String value) {
        if (value.isBlank()) return Optional.empty();

        try {
            return Optional.of(Byte.parseByte(value));
        } catch (NumberFormatException e) {
            return Optional.empty();
        }
    }

    /**
     * Safely parses a string into a short.
     */
    public static Optional<Short> parseShort(@NonNull String value) {
        if (value.isBlank()) return Optional.empty();

        try {
            return Optional.of(Short.parseShort(value));
        } catch (NumberFormatException e) {
            return Optional.empty();
        }
    }

    /**
     * Safely parses a string into an int.
     */
    public static Optional<Integer> parseInt(@NonNull String value) {
        if (value.isBlank()) return Optional.empty();

        try {
            return Optional.of(Integer.parseInt(value));
        } catch (NumberFormatException e) {
            return Optional.empty();
        }
    }

    /**
     * Safely parses a string into a long.
     */
    public static Optional<Long> parseLong(@NonNull String value) {
        if (value.isBlank()) return Optional.empty();

        try {
            return Optional.of(Long.parseLong(value));
        } catch (NumberFormatException e) {
            return Optional.empty();
        }
    }

    /**
     * Safely parses a string into a float.
     */
    public static Optional<Float> parseFloat(@NonNull String value) {
        if (value.isBlank()) return Optional.empty();

        try {
            return Optional.of(Float.parseFloat(value));
        } catch (NumberFormatException e) {
            return Optional.empty();
        }
    }

    /**
     * Safely parses a string into a double.
     */
    public static Optional<Double> parseDouble(@NonNull String value) {
        if (value.isBlank()) return Optional.empty();

        try {
            return Optional.of(Double.parseDouble(value));
        } catch (NumberFormatException e) {
            return Optional.empty();
        }
    }
}

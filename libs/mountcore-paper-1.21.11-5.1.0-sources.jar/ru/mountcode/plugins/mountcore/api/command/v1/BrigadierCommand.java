package ru.mountcode.plugins.mountcore.api.command.v1;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.tree.LiteralCommandNode;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;

import java.util.Collection;
import java.util.Collections;

/**
 * Represents a Brigadier-based command abstraction used within the MountCore command framework.
 * <p>
 * Implementations of this interface define how a specific command should be built and registered
 * using the Brigadier command system. The {@link #construct(LiteralArgumentBuilder)} method is responsible
 * for setting up command arguments, executors, permissions, and other related properties.
 * <p>
 * Each command must have a unique {@link #getName()} that defines its main literal node,
 * while optional aliases and descriptions can be provided through {@link #getAliases()} and
 * {@link #getDescription()} respectively.
 *
 * <p><b>Example usage:</b></p>
 * <pre>{@code
 * public class HelloCommand implements BrigadierCommand<CommandSource> {
 *
 *     @Override
 *     public @NonNull LiteralCommandNode<CommandSource> construct(LiteralArgumentBuilder<CommandSource> command) {
 *         return command
 *             .then(Commands.literal("hello")
 *                 .executes(context -> {
 *                     context.getSource().sendMessage("Hello, world!");
 *                     return 1;
 *                 }))
 *             .build();
 *     }
 *
 *     @Override
 *     public @NonNull String getName() {
 *         return "hello";
 *     }
 *
 *     @Override
 *     public @Nullable String getDescription() {
 *         return "Sends a greeting message to the player.";
 *     }
 * }
 * }</pre>
 *
 * @param <S> the Brigadier command source type, typically representing a command sender or player
 * @since 5.0.5
 */
public interface BrigadierCommand<S> {

    /**
     * Constructs and returns the {@link LiteralCommandNode} for this command.
     * This method is called during command registration and should define
     * the structure of the command, including its arguments, executors, and
     * any child subcommands.
     *
     * @param command the root literal node representing this command
     * @return the fully constructed {@link LiteralCommandNode}
     * @since 5.0.5
     */
    @NonNull
    LiteralCommandNode<S> construct(LiteralArgumentBuilder<S> command);

    /**
     * Returns the primary name of this command.
     * This name represents the root literal node and is used to invoke the command.
     *
     * @return the command's root name
     * @since 5.0.5
     */
    @NonNull
    String getName();

    /**
     * Returns an unmodifiable collection of aliases for this command.
     * Aliases are alternative names that can be used to invoke the same command logic.
     * <p>
     * By default, this method returns an empty list.
     *
     * @return a collection of aliases, or an empty collection if none exist
     * @since 5.0.5
     */
    @NonNull
    default Collection<String> getAliases() {
        return Collections.emptyList();
    }

    /**
     * Working only on Paper platform
     * <p>
     * Returns an optional description of this command.
     * This description can be used for help messages or command listings.
     * <p>
     * By default, this method returns {@code null}.
     *
     * @return a human-readable description, or {@code null} if not defined
     * @since 5.0.5
     */
    @Nullable
    default String getDescription() {
        return null;
    }
}

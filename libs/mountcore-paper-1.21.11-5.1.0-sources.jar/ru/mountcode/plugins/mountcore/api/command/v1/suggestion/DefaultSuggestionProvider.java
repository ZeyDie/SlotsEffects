package ru.mountcode.plugins.mountcore.api.command.v1.suggestion;

import com.google.common.base.CharMatcher;
import com.mojang.brigadier.Message;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import org.jspecify.annotations.NonNull;

import java.util.Collection;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Stream;

/**
 * Utility interface providing static helper methods for creating Brigadier {@link Suggestions}.
 * <p>Uses default matching algorithm.
 *
 * @since 5.0.15
 */
public interface DefaultSuggestionProvider {

    /**
     * Matcher that detects the characters used as word separators
     */
    CharMatcher MATCH_SPLITTER = CharMatcher.anyOf("._/");

    /**
     * Suggests all strings from the given iterable that match the current input.
     *
     * @param strings the candidate strings to suggest
     * @param builder the Brigadier suggestions builder
     * @return a completed future containing the built suggestions
     * @since 5.0.15
     */
    static @NonNull CompletableFuture<@NonNull Suggestions> suggest(@NonNull Iterable<@NonNull String> strings, @NonNull SuggestionsBuilder builder) {
        String string = builder.getRemaining().toLowerCase(Locale.ROOT);

        for (String candidate : strings) {
            if (matchesSubStr(string, candidate.toLowerCase(Locale.ROOT))) {
                builder.suggest(candidate);
            }
        }

        return builder.buildFuture();
    }

    /**
     * Suggests all strings from the given stream that match the current input.
     *
     * @param strings stream of candidate strings
     * @param builder the Brigadier suggestions builder
     * @return a completed future containing the built suggestions
     * @since 5.0.15
     */
    static @NonNull CompletableFuture<@NonNull Suggestions> suggest(@NonNull Stream<@NonNull String> strings, @NonNull SuggestionsBuilder builder) {
        String remaining = builder.getRemaining().toLowerCase(Locale.ROOT);

        Stream<String> candidates = strings.filter(str -> matchesSubStr(remaining, str.toLowerCase(Locale.ROOT)));

        candidates.forEach(builder::suggest);
        return builder.buildFuture();
    }

    /**
     * Suggests all strings from the given array that match the current input.
     *
     * @param strings array of candidate strings
     * @param builder the Brigadier suggestions builder
     * @return a completed future containing the built suggestions
     * @since 5.0.15
     */
    static @NonNull CompletableFuture<@NonNull Suggestions> suggest(@NonNull String[] strings, @NonNull SuggestionsBuilder builder) {
        String string = builder.getRemaining().toLowerCase(Locale.ROOT);

        for (String candidate : strings) {
            if (matchesSubStr(string, candidate.toLowerCase(Locale.ROOT))) {
                builder.suggest(candidate);
            }
        }

        return builder.buildFuture();
    }

    /**
     * Suggests entries with optional {@link Message} tooltips.
     *
     * @param candidates collection of entries where the key is the suggestion text and the value
     *                   is an optional tooltip message (may be {@code null})
     * @param builder    the Brigadier suggestions builder
     * @return a completed future containing the built suggestions
     * @since 5.0.15
     */
    static @NonNull CompletableFuture<@NonNull Suggestions> suggestWithMessageTooltips(@NonNull Collection<Map.@NonNull Entry<@NonNull String, Message>> candidates, @NonNull SuggestionsBuilder builder) {
        String string = builder.getRemaining().toLowerCase(Locale.ROOT);

        for (Map.Entry<String, Message> candidate : candidates) {
            if (matchesSubStr(string, candidate.getKey().toLowerCase(Locale.ROOT))) {
                if (candidate.getValue() == null) {
                    builder.suggest(candidate.getKey());
                    continue;
                }

                builder.suggest(candidate.getKey(), candidate.getValue());
            }
        }

        return builder.buildFuture();
    }

    /**
     * Checks whether {@code substring} contains {@code input} as a sub-string, allowing the match
     * to start at the beginning of any "word" (words are split by {@code .}, {@code _} or {@code /}).
     *
     * <p>Examples (input → candidate):
     * <ul>
     *   <li>{@code "core"} → {@code "mountcore"} – true</li>
     *   <li>{@code "paper"} → {@code "io.papermc.paper"} – true</li>
     *   <li>{@code "cmd"} → {@code "my_plugin.command"} – true</li>
     *   <li>{@code "abc"} → {@code "a.b.c"} – true</li>
     * </ul>
     *
     * @param input     the text typed by the player (already lower-cased)
     * @param substring the candidate string (already lower-cased)
     * @return {@code true} if the input matches a sub-string of the candidate
     * @since 5.0.15
     */
    static boolean matchesSubStr(@NonNull String input, @NonNull String substring) {
        int i1;
        for (int i = 0; !substring.startsWith(input, i); i = i1 + 1) {
            i1 = MATCH_SPLITTER.indexIn(substring, i);
            if (i1 < 0) {
                return false;
            }
        }

        return true;
    }
}

package ru.mountcode.plugins.mountcore.api.command.v1;

import org.jspecify.annotations.NonNull;

public interface CommandRegistrar<S> {

    void register(@NonNull BrigadierCommand<S> command);
}

package ru.mountcode.plugins.mountcore.api.time.v1.format;

/**
 * Represents the contextual meaning of time-related messages in formatting operations.
 * <p>
 * This enumeration defines how a time value should be interpreted and displayed in messages.
 * For example, whether the message describes the remaining time until an event or
 * the time that will pass before something happens.
 * </p>
 *
 * <p>Typical use cases include:
 * <ul>
 *   <li>Formatting countdown timers (e.g., "1 minute remaining")</li>
 *   <li>Formatting scheduled or delayed events (e.g., "in 1 minute")</li>
 * </ul>
 *
 * Example usage:
 * <pre>{@code
 * TimeContext context = TimeContext.REMAINING;
 * if (context == TimeContext.REMAINING) {
 *     System.out.println("1 minute remaining");
 * } else if (context == TimeContext.IN) {
 *     System.out.println("in 1 minute");
 * }
 * }</pre>
 *
 * @since 5.0.6
 */
public enum TimeContext {

    /**
     * Indicates that the time value represents the remaining time until an event occurs.
     * <p>Example: "1 minute remaining".</p>
     * <p>Example: "Осталась: 1 минута".</p>
     */
    REMAINING,
    /**
     * Indicates that the time value represents the time after which an event will occur.
     * <p>Example: "in 1 minute".</p>
     * <p>Example: "Через 1 минуту".</p>
     */
    IN;
}

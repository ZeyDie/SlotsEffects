package ru.mountcode.plugins.mountcore.api.time.v1.format;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import net.kyori.adventure.text.Component;

import java.time.temporal.ChronoUnit;

/**
 * Utility class for formatting time values into localized {@link Component} representations.
 * <p>
 * This class provides static methods to build translation keys for time expressions
 * based on the time unit ({@link ChronoUnit}), the numeric value, and the contextual meaning
 * defined by {@link TimeContext}.
 * </p>
 *
 * <p>
 * The resulting {@link Component} is typically used with Adventure's translation system,
 * where keys such as <code>mountcore.time.seconds.one</code> or
 * <code>mountcore.time.minutes.acc.few</code> can be defined in localization files.
 * </p>
 *
 * <p>
 * This class also supports correct pluralization for Russian language forms ("one", "few", "many")
 * and adjusts the key form for certain grammatical cases (e.g., using <code>.acc</code>
 * suffix for the accusative case in the {@link TimeContext#IN} context).
 * </p>
 *
 * Example usage:
 * <pre>{@code
 * Component result = TimeComponentFormatter.format(ChronoUnit.MINUTES, 5, TimeContext.REMAINING);
 * // Produces translation key: "mountcore.time.minutes.few"
 * // Example output (depending on locale): "5 минут осталось"
 *
 * Component result2 = TimeComponentFormatter.format(ChronoUnit.SECONDS, 1, TimeContext.IN);
 * // Produces translation key: "mountcore.time.seconds.acc.one"
 * // Example output (depending on locale): "через 1 секунду"
 * }</pre>
 *
 * @since 5.0.6
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class TimeComponentFormatter {

    /** The base translation key prefix for all time-related entries. */
    private static final String PREFIX = "mountcore.time.";

    /**
     * Formats a time value into a localized {@link Component} based on the given unit, value, and context.
     * <p>
     * The method automatically constructs the appropriate translation key and selects
     * the correct plural form according to Russian grammar rules.
     * </p>
     *
     * @param unit    the {@link ChronoUnit} representing the time unit (e.g., seconds, minutes)
     * @param value   the numeric time value
     * @param context the {@link TimeContext} indicating whether the message is about remaining or upcoming time
     * @return a {@link Component} containing the localized time expression
     *
     * @since 5.0.6
     */
    public static Component format(ChronoUnit unit, long value, TimeContext context) {
        String key = PREFIX + unit.name().toLowerCase();

        if (context == TimeContext.IN && (unit == ChronoUnit.MINUTES || unit == ChronoUnit.SECONDS)) {
            key += ".acc";
        }

        key += "." + getPluralForm(value);

        return Component.text(value)
                .append(Component.text(" "))
                .append(Component.translatable(key));
    }

    /**
     * Determines the plural form key ("one", "few", or "many") according to Russian grammar rules.
     * <p>
     * This method ensures correct pluralization of time units for values like 1, 2–4, 5–20, etc.
     * </p>
     *
     * @param n the numeric value to analyze
     * @return the plural form as a string ("one", "few", or "many")
     *
     * @since 5.0.6
     */
    private static String getPluralForm(long n) {
        n = Math.abs(n) % 100;
        if (n >= 11 && n <= 19) return "many";
        long i = n % 10;
        return switch ((int) i) {
            case 1 -> "one";
            case 2, 3, 4 -> "few";
            default -> "many";
        };
    }
}

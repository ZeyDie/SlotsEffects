package ru.mountcode.plugins.mountcore.api.time.v1;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.jspecify.annotations.NonNull;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;

/**
 * Utility class providing methods for parsing date and date-time strings in various common formats.
 * <p>
 * Supported date formats include:
 * <ul>
 *     <li>yyyy-MM-dd</li>
 *     <li>yyyy.MM.dd</li>
 *     <li>yyyy/MM/dd</li>
 *     <li>dd-MM-yyyy</li>
 *     <li>dd.MM.yyyy</li>
 *     <li>dd/MM/yyyy</li>
 * </ul>
 *
 * Supported date-time formats include both space and 'T' separators:
 * <ul>
 *     <li>dd-MM-yyyy HH:mm</li>
 *     <li>yyyy-MM-dd HH:mm</li>
 *     <li>yyyy/MM/dd HH:mm</li>
 *     <li>ISO_LOCAL_DATE_TIME (e.g., 2025-10-26T15:00:00)</li>
 * </ul>
 *
 * Time zone parsing supports:
 * <ul>
 *     <li>Explicit region-based zones (e.g., {@code Europe/London})</li>
 *     <li>Offset-based zones (e.g., {@code +03:00})</li>
 *     <li>Defaults to {@code Europe/Moscow} if unspecified</li>
 * </ul>
 *
 * This class is {@code final} and cannot be instantiated.
 *
 * @since 5.0.9
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class DateTimeParser {

    private static final ZoneId DEFAULT_ZONE = ZoneId.of("Europe/Moscow");

    private static final List<DateTimeFormatter> DATE_FORMATS = List.of(
            DateTimeFormatter.ofPattern("yyyy-MM-dd"),
            DateTimeFormatter.ofPattern("yyyy.MM.dd"),
            DateTimeFormatter.ofPattern("yyyy/MM/dd"),
            DateTimeFormatter.ofPattern("dd-MM-yyyy"),
            DateTimeFormatter.ofPattern("dd.MM.yyyy"),
            DateTimeFormatter.ofPattern("dd/MM/yyyy")
    );

    private static final List<DateTimeFormatter> DATETIME_FORMATS = List.of(
            DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm"),
            DateTimeFormatter.ofPattern("dd-MM-yyyy'T'HH:mm"),
            DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm"),
            DateTimeFormatter.ofPattern("dd.MM.yyyy'T'HH:mm"),
            DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"),
            DateTimeFormatter.ofPattern("dd/MM/yyyy'T'HH:mm"),

            DateTimeFormatter.ofPattern("yyyy.MM.dd HH:mm"),
            DateTimeFormatter.ofPattern("yyyy.MM.dd'T'HH:mm"),
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"),
            DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm"),
            DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm"),
            DateTimeFormatter.ofPattern("yyyy/MM/dd'T'HH:mm"),

            DateTimeFormatter.ISO_LOCAL_DATE_TIME
    );

    /**
     * Parses a date string into a {@link LocalDate}, trying multiple supported formats.
     * <p>
     * This method automatically detects date format among commonly used patterns such as
     * {@code yyyy-MM-dd}, {@code dd.MM.yyyy}, etc.
     *
     * <p>Example usage:
     * <pre>{@code
     * LocalDate date = DateTimeParser.parseDate("2025-10-27");
     * }</pre>
     *
     * @param input the input date string (non-null)
     * @return a parsed {@link LocalDate} instance
     * @throws DateTimeParseException if the date format is unrecognized or invalid
     *
     * @since 5.0.9
     */
    public static @NonNull LocalDate parseDate(@NonNull String input) throws DateTimeParseException {
        for (DateTimeFormatter fmt : DATE_FORMATS) {
            try {
                return LocalDate.parse(input, fmt);
            } catch (DateTimeParseException ignored) {}
        }
        throw new DateTimeParseException("Unrecognized date format", input, 0);
    }

    /**
     * Parses a date-time string that may include an optional time zone or offset.
     * <p>
     * Examples of valid inputs:
     * <ul>
     *     <li>{@code 2025-10-26 15:00}</li>
     *     <li>{@code 2025-10-26T15:00+02:00}</li>
     *     <li>{@code 2025-10-26 15:00 Europe/London}</li>
     *     <li>{@code 26.10.2025 15:00 UTC}</li>
     * </ul>
     *
     * The default time zone is {@code Europe/Moscow} if not specified.
     *
     * <p>Example usage:
     * <pre>{@code
     * LocalDateTime dateTime = DateTimeParser.parseDateTime("2025-10-26 15:00 Europe/London");
     * }</pre>
     *
     * @param input the input date-time string (non-null)
     * @return a parsed {@link LocalDateTime} adjusted to the resolved {@link ZoneId}
     * @throws DateTimeParseException if parsing fails for all supported formats
     *
     * @since 5.0.8
     */
    public static @NonNull LocalDateTime parseDateTime(@NonNull String input) throws DateTimeParseException {
        String[] parts = input.trim().split("\\s+");

        String dateTimePart = parts[0];
        String zonePart = null;
        if (parts.length > 1) {
            zonePart = parts[parts.length - 1];
            // Might be a zone or part of date-time if date contains space
            if (parts.length > 2) {
                dateTimePart = String.join(" ", parts[0], parts[1]);
            }
        }

        ZoneId zone = DEFAULT_ZONE;
        if (zonePart != null) {
            try {
                zone = ZoneId.of(zonePart);
            } catch (DateTimeException ignored) {
                // Maybe it's an offset like +03:00
                if (zonePart.matches("[+-]\\d{2}:?\\d{2}?")) {
                    zone = ZoneOffset.of(zonePart);
                }
            }
        }

        if (parts.length == 2 && zone.equals(DEFAULT_ZONE)) {
            dateTimePart = String.join(" ", parts);
        }

        // Try parse with offset first
        try {
            OffsetDateTime odt = OffsetDateTime.parse(dateTimePart, DateTimeFormatter.ISO_OFFSET_DATE_TIME);
            return odt.toLocalDateTime();
        } catch (DateTimeParseException ignored) {}

        // Try various local date-time formats
        for (DateTimeFormatter fmt : DATETIME_FORMATS) {
            try {
                LocalDateTime ldt = LocalDateTime.parse(dateTimePart, fmt);
                return ldt.atZone(zone).toLocalDateTime();
            } catch (DateTimeParseException ignored) {}
        }

        throw new DateTimeParseException("Unrecognized date-time format", input, 0);
    }
}

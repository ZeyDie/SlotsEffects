package ru.mountcode.plugins.mountcore.api.time.v1.format;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import net.kyori.adventure.text.Component;

import java.time.Duration;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

/**
 * Utility class for converting a {@link Duration} into a localized {@link Component}
 * representation that displays a human-readable formatted time string.
 * <p>
 * This class decomposes a {@link Duration} into its constituent time units
 * (years, months, days, hours, minutes, and seconds), and formats each of them
 * using {@link TimeComponentFormatter}. The final result is a concatenation
 * of all non-zero time components, properly localized and grammatically correct.
 * </p>
 *
 * <p>
 * For example, if the {@code Duration} represents <code>1 hour 15 minutes 30 seconds</code>,
 * the resulting {@link Component} could correspond to:
 * <blockquote><pre>1 час 15 минут 30 секунд</pre></blockquote>
 * The exact phrasing depends on the selected {@link TimeContext} and the localization configuration.
 *
 * <p>
 * Supported time units:
 * <ul>
 *     <li>Years (approximated as 365 days)</li>
 *     <li>Months (approximated as 30 days)</li>
 *     <li>Days</li>
 *     <li>Hours</li>
 *     <li>Minutes</li>
 *     <li>Seconds</li>
 * </ul>
 *
 * Example usage:
 * <pre>{@code
 * Duration duration = Duration.ofHours(2).plusMinutes(5).plusSeconds(12);
 * Component result = DurationComponentFormatter.format(duration, TimeContext.REMAINING);
 * // Produces something like: "2 часа 5 минут 12 секунд осталось"
 *
 * Duration shortDuration = Duration.ofSeconds(45);
 * Component result2 = DurationComponentFormatter.format(shortDuration, TimeContext.IN);
 * // Produces something like: "через 45 секунд"
 * }</pre>
 *
 * @since 5.0.6
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class DurationComponentFormatter  {

    /**
     * Converts a {@link Duration} to a formatted {@link Component}, breaking it down
     * into readable time parts such as years, months, days, hours, minutes, and seconds.
     * <p>
     * Each part is localized using {@link TimeComponentFormatter#format(ChronoUnit, long, TimeContext)}
     * according to the provided {@link TimeContext}.
     * </p>
     *
     * @param duration the {@link Duration} to be formatted
     * @param context  the {@link TimeContext} defining whether the message refers to remaining or future time
     * @return a {@link Component} representing the formatted duration
     *
     * @since 5.0.6
     */
    public static Component format(Duration duration, TimeContext context) {
        long totalSeconds = duration.getSeconds();

        long years = totalSeconds / (365 * 24 * 3600);
        totalSeconds %= (365 * 24 * 3600);

        long months = totalSeconds / (30 * 24 * 3600);
        totalSeconds %= (30 * 24 * 3600);

        long days = totalSeconds / (24 * 3600);
        totalSeconds %= (24 * 3600);

        long hours = totalSeconds / 3600;
        totalSeconds %= 3600;

        long minutes = totalSeconds / 60;
        long seconds = totalSeconds % 60;

        List<Component> parts = new ArrayList<>();
        if (years > 0) parts.add(TimeComponentFormatter.format(ChronoUnit.YEARS, years, context));
        if (months > 0) parts.add(TimeComponentFormatter.format(ChronoUnit.MONTHS, months, context));
        if (days > 0) parts.add(TimeComponentFormatter.format(ChronoUnit.DAYS, days, context));
        if (hours > 0) parts.add(TimeComponentFormatter.format(ChronoUnit.HOURS, hours, context));
        if (minutes > 0) parts.add(TimeComponentFormatter.format(ChronoUnit.MINUTES, minutes, context));
        if (seconds > 0 || parts.isEmpty())
            parts.add(TimeComponentFormatter.format(ChronoUnit.SECONDS, seconds, context));

        Component result = Component.empty();
        for (int i = 0; i < parts.size(); i++) {
            result = result.append(parts.get(i));
            if (i < parts.size() - 1) {
                result = result.append(Component.text(" "));
            }
        }

        return result;
    }
}

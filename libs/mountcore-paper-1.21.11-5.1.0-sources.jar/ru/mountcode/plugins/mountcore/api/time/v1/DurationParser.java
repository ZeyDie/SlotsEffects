package ru.mountcode.plugins.mountcore.api.time.v1;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.jspecify.annotations.NonNull;

import java.time.Duration;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Utility class for parsing human-readable duration strings
 * into a {@link Duration} object.
 * <p>
 * The string may consist of multiple numeric values followed by
 * time units. Whitespace between the number and the unit is allowed.
 * Unit names are case-insensitive.
 * <p>
 * Examples:
 * <ul>
 *     <li>{@code "10s"} → 10 seconds</li>
 *     <li>{@code "5m"} → 5 minutes</li>
 *     <li>{@code "2h 30m"} → 2 hours and 30 minutes</li>
 * </ul>
 * <p>
 * Unit mapping is delegated to {@link TimeUnitMapper}, which
 * translates unit strings (e.g., "s", "min", "hours", "d") into
 * {@link ChronoUnit}.
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class DurationParser {

    private static final Pattern DURATION_PATTERN = Pattern.compile("(\\d+)(\\D+)", Pattern.CASE_INSENSITIVE);

    /**
     * Parses the given string into a {@link Duration}.
     * <p>
     * The input may contain multiple segments (e.g., {@code "1h 30m"}).
     * Each segment must consist of a numeric value and a time unit.
     * If the number cannot be parsed or the unit is not recognized,
     * a {@link DateTimeParseException} will be thrown.
     *
     * @param input the string representing a duration (e.g., {@code "2h 15m"})
     * @return a {@link Duration} corresponding to the parsed string
     * @throws DateTimeParseException if the input contains an invalid number
     *                                or an unsupported time unit or input not contain valid duration
     * @since 5.0.0
     */
    public static Duration parse(@NonNull String input) throws DateTimeParseException {
        Duration duration = Duration.ZERO;

        String normalizedInput = input.toLowerCase().replace(" ", "");
        Matcher matcher = DURATION_PATTERN.matcher(normalizedInput);

        while (matcher.find()) {
            long value;
            try {
                value = Long.parseLong(matcher.group(1));
            } catch (NumberFormatException e) {
                throw new DateTimeParseException("Invalid unit number", matcher.group(1), matcher.start(1), e);
            }
            String unitStr = matcher.group(2);
            ChronoUnit unit = TimeUnitMapper.getUnit(unitStr);
            if (unit != null) {
                duration = duration.plus(unit.getDuration().multipliedBy(value));
            } else {
                throw new DateTimeParseException("Invalid unit", matcher.group(2), matcher.start(2));
            }
        }

        if (duration.isZero()) {
            throw new DateTimeParseException("Input not contain valid duration", input, 0);
        }

        return duration;
    }
}

package ru.mountcode.plugins.mountcore.api.time.v1;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.jspecify.annotations.Nullable;
import org.jspecify.annotations.NonNull;

import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.Map;

/**
 * Utility class for mapping human-readable time unit strings
 * (both English and Russian) to {@link ChronoUnit}.
 * <p>
 * This class provides predefined support for:
 * <ul>
 *     <li>English units (e.g., {@code "s"}, {@code "sec"}, {@code "hours"}, {@code "days"})</li>
 *     <li>Russian units (e.g., {@code "секунд"}, {@code "минут"}, {@code "ч"}, {@code "год"})</li>
 * </ul>
 * <p>
 * It covers a wide range of temporal units, including:
 * years, months, weeks, days, half-days, hours, minutes, seconds,
 * milliseconds, microseconds, nanoseconds, decades, centuries,
 * millennia, and eras.
 * <p>
 * The mapping can also be extended dynamically at runtime
 * via {@link #addLanguageSupport(Map)}.
 *
 * Examples:
 * <pre>{@code
 * ChronoUnit unit1 = TimeUnitMapper.getUnit("h");      // HOURS
 * ChronoUnit unit2 = TimeUnitMapper.getUnit("минут");  // MINUTES
 * ChronoUnit unit3 = TimeUnitMapper.getUnit("week");   // WEEKS
 * }</pre>
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class TimeUnitMapper {

    private static final Map<String, ChronoUnit> unitMapping = new HashMap<>();

    static {
        addEnglishSupport();
        addRussianSupport();
    }

    private static void addEnglishSupport() {
        // Years
        unitMapping.put("year", ChronoUnit.YEARS);
        unitMapping.put("years", ChronoUnit.YEARS);
        unitMapping.put("y", ChronoUnit.YEARS);
        unitMapping.put("yr", ChronoUnit.YEARS);
        unitMapping.put("yrs", ChronoUnit.YEARS);

        // Months
        unitMapping.put("month", ChronoUnit.MONTHS);
        unitMapping.put("months", ChronoUnit.MONTHS);
        unitMapping.put("mon", ChronoUnit.MONTHS);
        unitMapping.put("mons", ChronoUnit.MONTHS);
        unitMapping.put("mth", ChronoUnit.MONTHS);
        unitMapping.put("mths", ChronoUnit.MONTHS);

        // Weeks
        unitMapping.put("week", ChronoUnit.WEEKS);
        unitMapping.put("weeks", ChronoUnit.WEEKS);
        unitMapping.put("w", ChronoUnit.WEEKS);
        unitMapping.put("wk", ChronoUnit.WEEKS);
        unitMapping.put("wks", ChronoUnit.WEEKS);

        // Days
        unitMapping.put("day", ChronoUnit.DAYS);
        unitMapping.put("days", ChronoUnit.DAYS);
        unitMapping.put("d", ChronoUnit.DAYS);

        // Half Days
        unitMapping.put("halfday", ChronoUnit.HALF_DAYS);
        unitMapping.put("halfdays", ChronoUnit.HALF_DAYS);
        unitMapping.put("half_day", ChronoUnit.HALF_DAYS);
        unitMapping.put("half_days", ChronoUnit.HALF_DAYS);

        // Hours
        unitMapping.put("hour", ChronoUnit.HOURS);
        unitMapping.put("hours", ChronoUnit.HOURS);
        unitMapping.put("h", ChronoUnit.HOURS);
        unitMapping.put("hr", ChronoUnit.HOURS);
        unitMapping.put("hrs", ChronoUnit.HOURS);

        // Minutes
        unitMapping.put("minute", ChronoUnit.MINUTES);
        unitMapping.put("minutes", ChronoUnit.MINUTES);
        unitMapping.put("min", ChronoUnit.MINUTES);
        unitMapping.put("mins", ChronoUnit.MINUTES);
        unitMapping.put("m", ChronoUnit.MINUTES);

        // Seconds
        unitMapping.put("second", ChronoUnit.SECONDS);
        unitMapping.put("seconds", ChronoUnit.SECONDS);
        unitMapping.put("sec", ChronoUnit.SECONDS);
        unitMapping.put("secs", ChronoUnit.SECONDS);
        unitMapping.put("s", ChronoUnit.SECONDS);

        // Milliseconds
        unitMapping.put("millisecond", ChronoUnit.MILLIS);
        unitMapping.put("milliseconds", ChronoUnit.MILLIS);
        unitMapping.put("milli", ChronoUnit.MILLIS);
        unitMapping.put("millis", ChronoUnit.MILLIS);
        unitMapping.put("ms", ChronoUnit.MILLIS);

        // Microseconds
        unitMapping.put("microsecond", ChronoUnit.MICROS);
        unitMapping.put("microseconds", ChronoUnit.MICROS);
        unitMapping.put("micro", ChronoUnit.MICROS);
        unitMapping.put("micros", ChronoUnit.MICROS);
        unitMapping.put("us", ChronoUnit.MICROS);

        // Nanoseconds
        unitMapping.put("nanosecond", ChronoUnit.NANOS);
        unitMapping.put("nanoseconds", ChronoUnit.NANOS);
        unitMapping.put("nano", ChronoUnit.NANOS);
        unitMapping.put("nanos", ChronoUnit.NANOS);
        unitMapping.put("ns", ChronoUnit.NANOS);

        // Decades
        unitMapping.put("decade", ChronoUnit.DECADES);
        unitMapping.put("decades", ChronoUnit.DECADES);

        // Centuries
        unitMapping.put("century", ChronoUnit.CENTURIES);
        unitMapping.put("centuries", ChronoUnit.CENTURIES);
        unitMapping.put("cent", ChronoUnit.CENTURIES);
        unitMapping.put("cents", ChronoUnit.CENTURIES);

        // Millennia
        unitMapping.put("millennium", ChronoUnit.MILLENNIA);
        unitMapping.put("millennia", ChronoUnit.MILLENNIA);

        // Eras
        unitMapping.put("era", ChronoUnit.ERAS);
        unitMapping.put("eras", ChronoUnit.ERAS);
    }

    private static void addRussianSupport() {
        // Years
        unitMapping.put("год", ChronoUnit.YEARS);
        unitMapping.put("года", ChronoUnit.YEARS);
        unitMapping.put("лет", ChronoUnit.YEARS);
        unitMapping.put("г", ChronoUnit.YEARS);

        // Months
        unitMapping.put("месяц", ChronoUnit.MONTHS);
        unitMapping.put("месяца", ChronoUnit.MONTHS);
        unitMapping.put("месяцев", ChronoUnit.MONTHS);
        unitMapping.put("мес", ChronoUnit.MONTHS);

        // Weeks
        unitMapping.put("неделя", ChronoUnit.WEEKS);
        unitMapping.put("недели", ChronoUnit.WEEKS);
        unitMapping.put("недель", ChronoUnit.WEEKS);
        unitMapping.put("нед", ChronoUnit.WEEKS);

        // Days
        unitMapping.put("день", ChronoUnit.DAYS);
        unitMapping.put("дня", ChronoUnit.DAYS);
        unitMapping.put("дней", ChronoUnit.DAYS);
        unitMapping.put("дн", ChronoUnit.DAYS);
        unitMapping.put("д", ChronoUnit.DAYS);

        // Half Days
        unitMapping.put("полдня", ChronoUnit.HALF_DAYS);
        unitMapping.put("полдней", ChronoUnit.HALF_DAYS);

        // Hours
        unitMapping.put("час", ChronoUnit.HOURS);
        unitMapping.put("часа", ChronoUnit.HOURS);
        unitMapping.put("часов", ChronoUnit.HOURS);
        unitMapping.put("ч", ChronoUnit.HOURS);

        // Minutes
        unitMapping.put("минута", ChronoUnit.MINUTES);
        unitMapping.put("минуты", ChronoUnit.MINUTES);
        unitMapping.put("минут", ChronoUnit.MINUTES);
        unitMapping.put("мин", ChronoUnit.MINUTES);
        unitMapping.put("м", ChronoUnit.MINUTES);

        // Seconds
        unitMapping.put("секунда", ChronoUnit.SECONDS);
        unitMapping.put("секунды", ChronoUnit.SECONDS);
        unitMapping.put("секунд", ChronoUnit.SECONDS);
        unitMapping.put("сек", ChronoUnit.SECONDS);
        unitMapping.put("с", ChronoUnit.SECONDS);

        // Milliseconds
        unitMapping.put("миллисекунда", ChronoUnit.MILLIS);
        unitMapping.put("миллисекунды", ChronoUnit.MILLIS);
        unitMapping.put("миллисекунд", ChronoUnit.MILLIS);
        unitMapping.put("мс", ChronoUnit.MILLIS);

        // Microseconds
        unitMapping.put("микросекунда", ChronoUnit.MICROS);
        unitMapping.put("микросекунды", ChronoUnit.MICROS);
        unitMapping.put("микросекунд", ChronoUnit.MICROS);
        unitMapping.put("мкс", ChronoUnit.MICROS);

        // Nanoseconds
        unitMapping.put("наносекунда", ChronoUnit.NANOS);
        unitMapping.put("наносекунды", ChronoUnit.NANOS);
        unitMapping.put("наносекунд", ChronoUnit.NANOS);
        unitMapping.put("нс", ChronoUnit.NANOS);

        // Decades
        unitMapping.put("десятилетие", ChronoUnit.DECADES);
        unitMapping.put("десятилетия", ChronoUnit.DECADES);
        unitMapping.put("десятилетий", ChronoUnit.DECADES);

        // Centuries
        unitMapping.put("век", ChronoUnit.CENTURIES);
        unitMapping.put("века", ChronoUnit.CENTURIES);
        unitMapping.put("веков", ChronoUnit.CENTURIES);
        unitMapping.put("столетие", ChronoUnit.CENTURIES);
        unitMapping.put("столетия", ChronoUnit.CENTURIES);
        unitMapping.put("столетий", ChronoUnit.CENTURIES);

        // Millennia
        unitMapping.put("тысячелетие", ChronoUnit.MILLENNIA);
        unitMapping.put("тысячелетия", ChronoUnit.MILLENNIA);
        unitMapping.put("тысячелетий", ChronoUnit.MILLENNIA);

        // Eras
        unitMapping.put("эра", ChronoUnit.ERAS);
        unitMapping.put("эры", ChronoUnit.ERAS);
        unitMapping.put("эр", ChronoUnit.ERAS);
    }

    /**
     * Adds a custom set of unit mappings for an additional language
     * or dialect. Existing mappings will not be overridden.
     *
     * @param unitMapping a map of unit strings to {@link ChronoUnit},
     *                    where the key is the string representation
     *                    of a time unit and the value is the
     *                    corresponding {@link ChronoUnit}
     */
    public static void addLanguageSupport(@NonNull Map<String, ChronoUnit> unitMapping) {
        for (Map.Entry<String, ChronoUnit> entry : unitMapping.entrySet()) {
            TimeUnitMapper.unitMapping.putIfAbsent(entry.getKey(), entry.getValue());
        }
    }

    /**
     * Retrieves the {@link ChronoUnit} corresponding to the given unit string.
     * <p>
     * The lookup is case-sensitive, so callers should normalize input
     * (e.g., to lowercase) before calling this method.
     *
     * @param unit the string representation of a time unit
     *             (e.g., {@code "h"}, {@code "hours"}, {@code "секунд"})
     * @return the corresponding {@link ChronoUnit}, or {@code null} if no mapping exists
     */
    @Nullable
    public static ChronoUnit getUnit(@NonNull String unit) {
        return unitMapping.get(unit);
    }
}

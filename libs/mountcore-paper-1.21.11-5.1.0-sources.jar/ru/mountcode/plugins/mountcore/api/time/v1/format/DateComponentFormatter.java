package ru.mountcode.plugins.mountcore.api.time.v1.format;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import net.kyori.adventure.text.Component;

import java.time.LocalDateTime;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import java.util.Map;

/**
 * Utility class for formatting {@link LocalDateTime} values into localized {@link Component}
 * representations based on translatable keys.
 * <p>
 * This class constructs a time-and-date representation by combining several translation keys:
 * <ul>
 *     <li><b>mountcore.date.month.&lt;month&gt;</b> — localized month name</li>
 *     <li><b>mountcore.date.at</b> — localized "at" keyword (e.g., "в" in Russian, "at" in English)</li>
 *     <li><b>mountcore.date.pattern</b> — template pattern determining output order and separators</li>
 * </ul>
 *
 * <p>
 * Example of possible localization templates:
 * <pre>
 * # Russian locale
 * mountcore.date.pattern={day} {month} {year} {at} {time}
 * mountcore.date.month.october=октября
 * mountcore.date.at=в
 *
 * # English locale
 * mountcore.date.pattern={month} {day}, {year} {at} {time}
 * mountcore.date.month.october=October
 * mountcore.date.at=at
 * </pre>
 *
 * Example usage:
 * <pre>{@code
 * LocalDateTime dateTime = LocalDateTime.of(2025, Month.OCTOBER, 23, 14, 30);
 * Component formatted = DateComponentFormatter.format(dateTime);
 * // Produces a localized component based on pattern and translation keys
 * }</pre>
 *
 * @since 5.0.6
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class DateComponentFormatter {

    /** The base translation key prefix for all date-related localization entries. */
    private static final String PREFIX = "mountcore.date.";

    /**
     * Formats a {@link LocalDateTime} into a localized {@link Component}.
     * <p>
     * The formatter builds a composite structure containing day, month, year, and time,
     * using Adventure’s translatable components for month names and localization templates.
     * </p>
     *
     * <p>The method uses the pattern key <code>mountcore.date.pattern</code> to define the structure.</p>
     *
     * @param dateTime the {@link LocalDateTime} to format
     * @return a {@link Component} representing the formatted, localized date and time
     *
     * @since 5.0.6
     */
    public static Component format(LocalDateTime dateTime) {
        int day = dateTime.getDayOfMonth();
        int year = dateTime.getYear();
        Month month = dateTime.getMonth();

        // Месяц (переводится по ключу, например mountcore.date.month.october)
        Component monthComp = Component.translatable(PREFIX + "month." + month.name().toLowerCase());
        // Связка "в" / "at"
        Component atComp = Component.translatable(PREFIX + "at");

        // Время в формате HH:mm
        String time = dateTime.format(DateTimeFormatter.ofPattern("HH:mm"));

        // Собираем подстановочные значения
        Map<String, Component> vars = Map.of(
                "day", Component.text(day),
                "month", monthComp,
                "year", Component.text(year),
                "at", atComp,
                "time", Component.text(time)
        );

        // Основной шаблон — сам определяет порядок и разделители
        // Пример (ru): "{day} {month} {year} {at} {time}"
        // Пример (en): "{month} {day}, {year} {at} {time}"
        // Подставляем вручную (Adventure сам аргументы не заменяет)
        return applyPattern(vars);
    }

    /**
     * Applies the localized date-time pattern by injecting variables
     * ({day}, {month}, {year}, {at}, {time}) as ordered translation arguments.
     *
     * @param vars    the map of placeholders and their corresponding components
     * @return the final formatted {@link Component}
     *
     * @since 5.0.6
     */
    private static Component applyPattern(Map<String, Component> vars) {
        return Component.translatable(PREFIX + "pattern")
                .arguments(
                        vars.get("day"),
                        vars.get("month"),
                        vars.get("year"),
                        vars.get("at"),
                        vars.get("time")
                );
    }
}

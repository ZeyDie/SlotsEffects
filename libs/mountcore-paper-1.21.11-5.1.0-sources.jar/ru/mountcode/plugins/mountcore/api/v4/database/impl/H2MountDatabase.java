package ru.mountcode.plugins.mountcore.api.v4.database.impl;

import ru.mountcode.plugins.mountcore.api.v4.database.DatabaseMeta;
import ru.mountcode.plugins.mountcore.api.v4.database.MountDatabase;

@Deprecated(forRemoval = true, since = "5.0.0")
public class H2MountDatabase extends MountDatabase {

    private static final String URL_TEMPLATE = "jdbc:h2:%s";

    public H2MountDatabase(DatabaseMeta meta) {
        super(meta);
    }

    public String buildJdbcUrl() {
        return String.format(URL_TEMPLATE, this.getMeta().getCredentials().getDatabasePath().toAbsolutePath());
    }

    @Override
    protected String getDriverClass() {
        return "org.h2.Driver";
    }
}

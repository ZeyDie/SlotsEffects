package ru.mountcode.plugins.mountcore.api.v4.database.migration;

import java.sql.Connection;

@Deprecated(forRemoval = true, since = "5.0.0")
public interface Migrator {

    void migrate(Connection connection) throws DatabaseMigrationException;
}

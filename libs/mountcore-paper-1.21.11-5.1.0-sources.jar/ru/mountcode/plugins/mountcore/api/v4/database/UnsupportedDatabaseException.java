package ru.mountcode.plugins.mountcore.api.v4.database;

@Deprecated(forRemoval = true, since = "5.0.0")
public class UnsupportedDatabaseException extends Exception {
    public UnsupportedDatabaseException(String message) {
        super(message);
    }

    public UnsupportedDatabaseException(String message, Throwable cause) {
        super(message, cause);
    }
}

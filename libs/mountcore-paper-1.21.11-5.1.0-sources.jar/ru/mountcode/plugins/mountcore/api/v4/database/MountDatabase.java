package ru.mountcode.plugins.mountcore.api.v4.database;

import com.zaxxer.hikari.HikariDataSource;
import ru.mountcode.plugins.mountcore.api.v4.database.impl.H2MountDatabase;
import ru.mountcode.plugins.mountcore.api.v4.database.impl.MySQLMountDatabase;
import ru.mountcode.plugins.mountcore.api.v4.database.impl.PostgreSQLMountDatabase;
import ru.mountcode.plugins.mountcore.api.v4.database.migration.DatabaseMigrationException;

import java.sql.Connection;
import java.sql.SQLException;

@Deprecated(forRemoval = true, since = "5.0.0")
public abstract class MountDatabase extends HikariDataSource {

    private final DatabaseMeta meta;

    protected MountDatabase(DatabaseMeta meta) {
        super();
        this.meta = meta;
    }

    public static MountDatabase create(DatabaseMeta meta) throws UnsupportedDatabaseException, DatabaseMigrationException {
        MountDatabase database = switch (meta.getCredentials().getType()) {
            case MYSQL -> new MySQLMountDatabase(meta);
            case POSTGRESQL -> new PostgreSQLMountDatabase(meta);
            case H2 -> new H2MountDatabase(meta);
        };

        database.initialize();

        return database;
    }

    protected DatabaseMeta getMeta() {
        return this.meta;
    }

    protected void initialize() throws DatabaseMigrationException, UnsupportedDatabaseException {
        loadDriver();

        this.setJdbcUrl(buildJdbcUrl());
        if (meta.getCredentials().getType().isRemoteDatabase()) {
            this.setPassword(meta.getCredentials().getPassword());
            this.setUsername(meta.getCredentials().getUsername());
        }

        this.addDataSourceProperty("cachePrepStmts", "true");
        this.addDataSourceProperty("prepStmtCacheSize", "250");
        this.addDataSourceProperty("prepStmtCacheSqlLimit", "2048");

        try (Connection connection = this.getConnection()) {
            if (this.meta.getMigrator() != null) {
                this.meta.getMigrator().migrate(connection);
            }
        } catch (DatabaseMigrationException | SQLException e) {
            throw new DatabaseMigrationException("Error on initializing database", e);
        }
    }

    protected abstract String buildJdbcUrl();

    protected abstract String getDriverClass();

    protected void loadDriver() throws UnsupportedDatabaseException {
        try {
            Class.forName(this.getDriverClass(), true, MountDatabase.class.getClassLoader());
        } catch (UnsupportedClassVersionError e) {
            throw new UnsupportedDatabaseException(String.format("Your database driver %s is not compatible with your Java version. " +
                    "You will need to either upgrade your Java version or install a different driver jar file.", this.getDriverClass()), e);
        } catch (Exception e) {
            throw new UnsupportedDatabaseException("Cannot find database driver: " + e.getMessage());
        }
    }
}

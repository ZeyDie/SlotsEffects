package ru.mountcode.plugins.mountcore.api.v4.database;

import lombok.Getter;

@Deprecated(forRemoval = true, since = "5.0.0")
@Getter
public enum DatabaseType {

    MYSQL(true, 3306),
    POSTGRESQL(true, 5432),
    H2(9092);

    private boolean remoteDatabase = false;
    private final int defaultPort;

    DatabaseType(boolean remoteDatabase, int defaultPort) {
        this.remoteDatabase = remoteDatabase;
        this.defaultPort = defaultPort;
    }
    DatabaseType(int defaultPort) {
        this.defaultPort = defaultPort;
    }
}

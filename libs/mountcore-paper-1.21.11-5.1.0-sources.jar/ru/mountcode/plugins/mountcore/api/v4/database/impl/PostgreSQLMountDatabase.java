package ru.mountcode.plugins.mountcore.api.v4.database.impl;

import ru.mountcode.plugins.mountcore.api.v4.database.DatabaseCredentials;
import ru.mountcode.plugins.mountcore.api.v4.database.DatabaseMeta;
import ru.mountcode.plugins.mountcore.api.v4.database.MountDatabase;

@Deprecated(forRemoval = true, since = "5.0.0")
public class PostgreSQLMountDatabase extends MountDatabase {

    private static final String URL_TEMPLATE = "jdbc:postgresql://%s:%d/%s";

    public PostgreSQLMountDatabase(DatabaseMeta meta) {
        super(meta);
    }

    public String buildJdbcUrl() {
        DatabaseCredentials credentials = this.getMeta().getCredentials();
        return String.format(URL_TEMPLATE, credentials.getAddress(), credentials.getPort(), credentials.getDatabase());
    }

    @Override
    protected String getDriverClass() {
        return "org.postgresql.Driver";
    }
}

package ru.mountcode.plugins.mountcore.api.v4;

import lombok.Getter;
import lombok.Setter;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.translation.MiniMessageTranslationStore;
import net.kyori.adventure.translation.GlobalTranslator;
import org.bukkit.plugin.java.JavaPlugin;
import ru.mountcode.plugins.mountcore.MountCore;
import ru.mountcode.plugins.mountcore.PluginSettings;
import ru.mountcode.plugins.mountcore.api.v3.bukkit.Sender;
import ru.mountcode.plugins.mountcore.api.v3.exception.PluginNotTranslatableException;
import ru.mountcode.plugins.mountcore.api.v3.exception.TranslationLoadingException;
import ru.mountcode.plugins.mountcore.api.v3.plugin.ITranslatablePlugin;
import ru.mountcode.plugins.mountcore.api.v3.text.translation.TranslationLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Properties;

@Deprecated(forRemoval = true, since = "5.0.0")
public abstract class MountPlugin extends JavaPlugin {

    // Translation
    private TranslationLoader translationLoader = null;
    private MiniMessageTranslationStore translationStore = null;
    private Key translationStoreKey = null;

    @Getter
    @Setter
    private PluginSettings pluginSettings = null;

    @Override
    public void onEnable() {
        this.pluginSettings = configurePluginSettings();
        sendPluginState(Component.translatable("mountcore.plugin.loading", Component.text(getName())));
        // Translation
        if (this instanceof ITranslatablePlugin) {
            this.translationStore = MiniMessageTranslationStore.create((this.translationStoreKey = Key.key(getName().toLowerCase() + ":automatic")));
            this.translationLoader = new TranslationLoader(getClass(), this.getPluginSettings().getPluginDirectory().resolve("translations"));
            this.loadTranslations();
        }
    }

    @Override
    public void onDisable() {
        if (this instanceof ITranslatablePlugin) {
            GlobalTranslator.translator().removeSource(this.translationStore);
            this.translationStore = null;
        }
        sendPluginState(Component.translatable("mountcore.plugin.unloading", Component.text(getName())));
    }

    public PluginSettings configurePluginSettings() {
        return PluginSettings.builder()
                .pluginDirectory(Path.of("MountCore", getName()))
                .build();
    }

    public final void reloadTranslations() {
        if (this.translationStore == null || this.translationLoader == null) {
            throw new PluginNotTranslatableException("Plugin not supported automatic translations loading");
        }

        GlobalTranslator.translator().removeSource(this.translationStore);
        this.translationStore = MiniMessageTranslationStore.create(this.translationStoreKey);
        this.loadTranslations();
    }

    private void loadTranslations() {
        try {
            String pluginNameLower = getName().toLowerCase();
            Optional<Map<Locale, Properties>> translationBundleOptional = this.translationLoader.getTranslations();
            if (translationBundleOptional.isEmpty()) {
                MountCore.LOGGER.info("Translations for automatic loading not founded");
                return;
            }

            for (Map.Entry<Locale, Properties> entry : translationBundleOptional.get().entrySet()) {
                Locale locale = entry.getKey();
                entry.getValue().forEach((key, value) -> {
                    String translationKey = (String) key;
                    if (!translationKey.startsWith(pluginNameLower)) {
                        translationKey = pluginNameLower + "." + translationKey;
                    }
                    try {
                        this.translationStore.register(translationKey, locale, (String) value);
                    } catch (IllegalArgumentException e) {
                        MountCore.LOGGER.warn("Found duplicate keys {} in {} locale", key, locale.toLanguageTag());
                    }
                });
            }

            GlobalTranslator.translator().addSource(this.translationStore);
        } catch (IOException e) {
            throw new TranslationLoadingException("Exception on automatic loading translations", e);
        }
    }

    public final Path getPluginDirectory() {
        if (Files.exists(this.getPluginSettings().getPluginDirectory())) {
            try {
                Files.createDirectories(this.getPluginSettings().getPluginDirectory());
            } catch (IOException e) {
                MountCore.LOGGER.error("Exception on creating plugin directory", e);
            }
        }

        return this.getPluginSettings().getPluginDirectory();
    }

    private void sendPluginState(Component component) {
        if (!this.getPluginSettings().isEnablePluginStateLogging()) {
            return;
        }
        Sender.sendConsole(component);
    }
}

package ru.mountcode.plugins.mountcore.api.v4.database;

import lombok.Builder;
import lombok.Getter;
import org.bukkit.configuration.ConfigurationSection;

import java.nio.file.Path;

@Deprecated(forRemoval = true, since = "5.0.0")
@Getter
@Builder
public class DatabaseCredentials {

    private DatabaseType type;

    @Builder.Default
    private String database = "database";
    @Builder.Default
    private String username = "root";
    @Builder.Default
    private String password = "root";
    @Builder.Default
    private String address = "localhost";
    @Builder.Default
    private int port = -1;

    private Path databasePath;

    public static DatabaseCredentials parse(ConfigurationSection section, Path databasePath) throws UnsupportedDatabaseException {
        String type = section.getString("type");
        if (type == null) {
            throw new UnsupportedDatabaseException("Database type not specified");
        }

        DatabaseType databaseType;
        try {
            databaseType = DatabaseType.valueOf(type.toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new UnsupportedDatabaseException("Unsupported database type " + section.getString("type"));
        }

        if (databaseType.isRemoteDatabase()) {
            String database = section.getString("database");
            if (database == null) {
                throw new UnsupportedDatabaseException("Database name not specified");
            }

            String username = section.getString("username");
            if (username == null) {
                throw new UnsupportedDatabaseException("Database username not specified");
            }

            String password = section.getString("password");
            if (password == null) {
                throw new UnsupportedDatabaseException("Database password not specified");
            }

            String address = section.getString("address");
            if (address == null) {
                throw new UnsupportedDatabaseException("Database address not specified");
            }

            int port = section.contains("port") ? section.getInt("port") : databaseType.getDefaultPort();

            return DatabaseCredentials.builder()
                    .type(databaseType)
                    .database(database)
                    .username(username)
                    .password(password)
                    .address(address)
                    .port(port)
                    .databasePath(databasePath)
                    .build();
        }

        return DatabaseCredentials.builder()
                .type(databaseType)
                .databasePath(databasePath)
                .build();
    }
}

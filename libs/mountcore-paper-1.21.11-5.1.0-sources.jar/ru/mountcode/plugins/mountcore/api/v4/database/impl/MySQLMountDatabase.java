package ru.mountcode.plugins.mountcore.api.v4.database.impl;

import ru.mountcode.plugins.mountcore.api.v4.database.DatabaseCredentials;
import ru.mountcode.plugins.mountcore.api.v4.database.DatabaseMeta;
import ru.mountcode.plugins.mountcore.api.v4.database.MountDatabase;

@Deprecated(forRemoval = true, since = "5.0.0")
public class MySQLMountDatabase extends MountDatabase {

    private static final String URL_TEMPLATE = "jdbc:MySQL://%s:%d/%s";

    public MySQLMountDatabase(DatabaseMeta meta) {
        super(meta);
    }

    public String buildJdbcUrl() {
        DatabaseCredentials credentials = this.getMeta().getCredentials();
        return String.format(URL_TEMPLATE, credentials.getAddress(), credentials.getPort(), credentials.getDatabase());
    }

    @Override
    protected String getDriverClass() {
        return "com.mysql.cj.jdbc.Driver";
    }
}

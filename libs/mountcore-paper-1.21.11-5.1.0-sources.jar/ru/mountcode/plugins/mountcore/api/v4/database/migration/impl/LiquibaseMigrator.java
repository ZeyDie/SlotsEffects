package ru.mountcode.plugins.mountcore.api.v4.database.migration.impl;

import liquibase.Liquibase;
import liquibase.database.Database;
import liquibase.database.DatabaseFactory;
import liquibase.database.jvm.JdbcConnection;
import liquibase.exception.LiquibaseException;
import liquibase.resource.ClassLoaderResourceAccessor;
import lombok.Builder;
import ru.mountcode.plugins.mountcore.api.v4.database.migration.DatabaseMigrationException;
import ru.mountcode.plugins.mountcore.api.v4.database.migration.Migrator;

import java.sql.Connection;

@Deprecated(forRemoval = true, since = "5.0.0")
@Builder
public class LiquibaseMigrator implements Migrator {

    @Builder.Default
    private String changelogPath = "db/changelog/changelog-master.yml";

    private final String systemTablesPrefix;

    @Override
    public void migrate(Connection connection) throws DatabaseMigrationException {
        try {
            Database database = DatabaseFactory.getInstance().findCorrectDatabaseImplementation(new JdbcConnection(connection));
            database.setDatabaseChangeLogTableName((systemTablesPrefix.endsWith("_") ? systemTablesPrefix : systemTablesPrefix + "_") + "changelog");
            database.setDatabaseChangeLogLockTableName((systemTablesPrefix.endsWith("_") ? systemTablesPrefix : systemTablesPrefix + "_") + "changelog_lock");
            Liquibase liquibase = new Liquibase(changelogPath, new ClassLoaderResourceAccessor(), database);

            liquibase.update();
        } catch (LiquibaseException e) {
            throw new DatabaseMigrationException(e);
        }
    }
}

package ru.mountcode.plugins.mountcore.api.v4.database;

import lombok.Builder;
import lombok.Getter;
import ru.mountcode.plugins.mountcore.api.v4.database.migration.Migrator;

@Deprecated(forRemoval = true, since = "5.0.0")
@Getter
@Builder
public class DatabaseMeta {

    @Builder.Default
    private Migrator migrator = null;

    private DatabaseCredentials credentials;
}

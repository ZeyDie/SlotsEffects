package ru.mountcode.plugins.mountcore.api.v4.database.migration;

@Deprecated(forRemoval = true, since = "5.0.0")
public class DatabaseMigrationException extends Exception {
    public DatabaseMigrationException(String message) {
        super(message);
    }

    public DatabaseMigrationException(String message, Throwable cause) {
        super(message, cause);
    }

    public DatabaseMigrationException(Throwable cause) {
        super(cause);
    }
}

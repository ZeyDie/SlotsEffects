package ru.mountcode.plugins.mountcore;

import lombok.Builder;
import lombok.Getter;

import java.nio.file.Path;

@Builder
@Getter
@Deprecated(forRemoval = true, since = "5.0.0")
public class PluginSettings {

    /**
     * Enable plugin logging on enable/disable states
     * @since 3.0.0
     */
    @Builder.Default
    private boolean enablePluginStateLogging = true;
    /**
     * Plugin directory path, using for automatic translations and other automatic operations
     * @since 3.0.0
     */
    private Path pluginDirectory;
}

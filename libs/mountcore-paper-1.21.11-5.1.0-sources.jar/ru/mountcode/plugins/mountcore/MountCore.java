package ru.mountcode.plugins.mountcore;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Deprecated(forRemoval = true, since = "5.0.0")
public final class MountCore {

    public static final Logger LOGGER = LoggerFactory.getLogger(MountCore.class);
}
